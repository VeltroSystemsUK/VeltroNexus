import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Building2, MapPin, Calendar, Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function CompanySearch() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [shouldSearch, setShouldSearch] = useState(false);

  const utils = trpc.useUtils();
  const { data: searchData, isLoading: isSearching } = trpc.companies.search.useQuery(
    { query: searchTerm },
    { enabled: shouldSearch && searchTerm.trim().length > 0 }
  );
  const addProspectMutation = trpc.prospects.create.useMutation({
    onSuccess: () => {
      toast.success("Company added to prospects!");
      utils.prospects.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to add prospect: " + error.message);
    },
  });

  const upsertCompanyMutation = trpc.companies.upsert.useMutation();

  // Update search results when data changes
  useEffect(() => {
    if (searchData) {
      setSearchResults(searchData.items || []);
      if (searchData.items.length === 0) {
        toast.info("No companies found");
      } else {
        toast.success(`Found ${searchData.items.length} companies`);
      }
    }
  }, [searchData]);

  const handleSearch = () => {
    if (!searchTerm.trim()) {
      toast.error("Please enter a company name or number");
      return;
    }
    setShouldSearch(true);
  };

  const handleAddProspect = async (company: any) => {
    try {
      // First upsert the company to our database
      const savedCompany = await upsertCompanyMutation.mutateAsync({
        companyNumber: company.company_number,
        companyName: company.title,
        companyStatus: company.company_status,
        companyType: company.company_type,
        incorporationDate: company.date_of_creation,
        addressLine1: company.address?.address_line_1,
        addressLine2: company.address?.address_line_2,
        locality: company.address?.locality,
        region: company.address?.region,
        postalCode: company.address?.postal_code,
        country: company.address?.country || "England",
        rawData: JSON.stringify(company),
      });

      // Then create a prospect linked to this company
      await addProspectMutation.mutateAsync({
        companyId: savedCompany.id,
      });
    } catch (error: any) {
      toast.error("Failed to add prospect: " + error.message);
    }
  };

  return (
    <div className="container max-w-7xl py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Company Search</h1>
        <p className="text-muted-foreground">
          Search for UK companies and add them to your prospects
        </p>
      </div>

      {/* Search Bar */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="Enter company name or number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="text-base"
              />
              <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                💡 Tip: You can search by company name, number, or keywords
              </p>
            </div>
            <Button onClick={handleSearch} disabled={isSearching} size="lg" className="px-8">
              {isSearching ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults.length > 0 ? (
        <div className="space-y-3">
          <h2 className="text-xl font-semibold">Search Results ({searchResults.length})</h2>
          {searchResults.map((company) => (
            <Card key={company.company_number} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <Link href={`/company/${company.company_number}`}>
                      <CardTitle className="text-lg flex items-center gap-2 hover:text-primary transition-colors cursor-pointer">
                        <Building2 className="w-5 h-5 text-primary" />
                        {company.title}
                      </CardTitle>
                    </Link>
                    <CardDescription className="mt-1">
                      Company Number: {company.company_number}
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => handleAddProspect(company)}
                    disabled={addProspectMutation.isPending}
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add to Prospects
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium text-muted-foreground mb-1">Status</p>
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        company.company_status === "active"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {company.company_status?.toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-muted-foreground mb-1">Type</p>
                    <p>{company.company_type?.replace(/-/g, " ").toUpperCase()}</p>
                  </div>
                  {company.address_snippet && (
                    <div className="md:col-span-2">
                      <p className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        Address
                      </p>
                      <p className="text-muted-foreground">{company.address_snippet}</p>
                    </div>
                  )}
                  {company.date_of_creation && (
                    <div>
                      <p className="font-medium text-muted-foreground mb-1 flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Incorporated
                      </p>
                      <p>{new Date(company.date_of_creation).toLocaleDateString()}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Search className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No companies found</h3>
            <p className="text-muted-foreground text-center max-w-md">
              Search for UK companies using the search bar above. You can search by company name,
              registration number, or keywords.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

