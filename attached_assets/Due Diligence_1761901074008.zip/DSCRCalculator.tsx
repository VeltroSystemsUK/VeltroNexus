import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, ArrowLeft, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";

export default function DSCRCalculator() {
  const [netOperatingIncome, setNetOperatingIncome] = useState("");
  const [totalDebtService, setTotalDebtService] = useState("");
  const [dscr, setDscr] = useState<number | null>(null);
  const [sensitivityDscr, setSensitivityDscr] = useState<number | null>(null);

  const calculateDSCR = () => {
    const noi = parseFloat(netOperatingIncome);
    const tds = parseFloat(totalDebtService);

    if (isNaN(noi) || isNaN(tds) || tds === 0) {
      setDscr(null);
      setSensitivityDscr(null);
      return;
    }

    const calculatedDscr = noi / tds;
    setDscr(calculatedDscr);

    // Calculate sensitivity with -20% revenue
    const sensitivityNoi = noi * 0.8;
    const sensitivityCalculatedDscr = sensitivityNoi / tds;
    setSensitivityDscr(sensitivityCalculatedDscr);
  };

  const reset = () => {
    setNetOperatingIncome("");
    setTotalDebtService("");
    setDscr(null);
    setSensitivityDscr(null);
  };

  const getDscrStatus = (value: number | null) => {
    if (value === null) return { text: "—", color: "text-muted-foreground" };
    if (value >= 1.5) return { text: "Excellent", color: "text-green-600" };
    if (value >= 1.25) return { text: "Good", color: "text-green-500" };
    if (value >= 1.0) return { text: "Acceptable", color: "text-yellow-600" };
    return { text: "Below Threshold", color: "text-red-600" };
  };

  const baseDscrStatus = getDscrStatus(dscr);
  const sensitivityDscrStatus = getDscrStatus(sensitivityDscr);

  const exportAsText = () => {
    const content = `DSCR CALCULATOR RESULTS\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nINPUT VALUES\n${'-'.repeat(50)}\nNet Operating Income (NOI): £${parseFloat(netOperatingIncome).toLocaleString()}\nTotal Debt Service (TDS): £${parseFloat(totalDebtService).toLocaleString()}\n\nRESULTS\n${'-'.repeat(50)}\nBase DSCR: ${dscr?.toFixed(2)} (${baseDscrStatus.text})\nSensitivity DSCR (-20% revenue): ${sensitivityDscr?.toFixed(2)} (${sensitivityDscrStatus.text})\n\nINTERPRETATION\n${'-'.repeat(50)}\n• DSCR ≥ 1.5: Excellent coverage\n• DSCR 1.25-1.49: Good coverage\n• DSCR 1.0-1.24: Acceptable coverage\n• DSCR < 1.0: Below threshold\n\nThe sensitivity analysis shows DSCR with a 20% reduction in revenue,\nhelping assess the loan's resilience to adverse conditions.\n\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `DSCR-Calculator-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    const content = `<div class="section">\n  <h1>DSCR Calculator Results</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Input Values</h2>\n  <table>\n    <tr>\n      <th>Metric</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Net Operating Income (NOI)</td>\n      <td>£${parseFloat(netOperatingIncome).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Total Debt Service (TDS)</td>\n      <td>£${parseFloat(totalDebtService).toLocaleString()}</td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Results</h2>\n  <div class="result">\n    <h3>Base DSCR</h3>\n    <p><span class="highlight">${dscr?.toFixed(2)}</span> - <span class="${baseDscrStatus.color.includes('green') ? 'success' : baseDscrStatus.color.includes('yellow') ? 'warning' : 'error'}">${baseDscrStatus.text}</span></p>\n  </div>\n  <div class="result">\n    <h3>Sensitivity Analysis (-20% Revenue)</h3>\n    <p><span class="highlight">${sensitivityDscr?.toFixed(2)}</span> - <span class="${sensitivityDscrStatus.color.includes('green') ? 'success' : sensitivityDscrStatus.color.includes('yellow') ? 'warning' : 'error'}">${sensitivityDscrStatus.text}</span></p>\n  </div>\n</div>\n\n<div class="section">\n  <h2>Interpretation</h2>\n  <ul>\n    <li><strong>DSCR ≥ 1.5:</strong> Excellent coverage</li>\n    <li><strong>DSCR 1.25-1.49:</strong> Good coverage</li>\n    <li><strong>DSCR 1.0-1.24:</strong> Acceptable coverage</li>\n    <li><strong>DSCR < 1.0:</strong> Below threshold</li>\n  </ul>\n  <p>The sensitivity analysis shows DSCR with a 20% reduction in revenue, helping assess the loan's resilience to adverse conditions.</p>\n</div>`;
    downloadAsHTML(content, `DSCR-Calculator-${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/due-diligence/checklist">
            <Button variant="ghost" className="gap-2 mb-4">
              <ArrowLeft className="h-4 w-4" />
              Back to Checklist
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-2">DSCR Calculator</h1>
          <p className="text-muted-foreground text-lg">
            Calculate Debt Service Coverage Ratio for loan assessment
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" />
                Input Values
              </CardTitle>
              <CardDescription>Enter the financial data to calculate DSCR</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="noi">Net Operating Income (NOI)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="noi"
                    type="number"
                    placeholder="0.00"
                    value={netOperatingIncome}
                    onChange={(e) => setNetOperatingIncome(e.target.value)}
                    className="pl-7"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Annual net operating income before debt service
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tds">Total Debt Service (TDS)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="tds"
                    type="number"
                    placeholder="0.00"
                    value={totalDebtService}
                    onChange={(e) => setTotalDebtService(e.target.value)}
                    className="pl-7"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Annual total debt service (principal + interest)
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <Button onClick={calculateDSCR} className="flex-1">
                  Calculate DSCR
                </Button>
                <Button onClick={reset} variant="outline">
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Results</CardTitle>
              <CardDescription>DSCR calculation and sensitivity analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-medium">Base DSCR:</span>
                  <div className="text-right">
                    <span className="text-3xl font-bold text-foreground">
                      {dscr !== null ? dscr.toFixed(2) : "—"}
                    </span>
                    <span className="text-sm ml-1">×</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Status:</span>
                  <span className={`text-sm font-medium ${baseDscrStatus.color}`}>
                    {baseDscrStatus.text}
                  </span>
                </div>
              </div>

              <div className="border-t pt-4 space-y-3">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-medium">Sensitivity (-20% Revenue):</span>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-foreground">
                      {sensitivityDscr !== null ? sensitivityDscr.toFixed(2) : "—"}
                    </span>
                    <span className="text-sm ml-1">×</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Status:</span>
                  <span className={`text-sm font-medium ${sensitivityDscrStatus.color}`}>
                    {sensitivityDscrStatus.text}
                  </span>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg space-y-2 text-xs">
                <p className="font-medium">Policy Requirements:</p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Base DSCR ≥ 1.5× required</li>
                  <li>• Sensitivity DSCR ≥ 1.0× required</li>
                  <li>• Formula: DSCR = NOI ÷ Total Debt Service</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {dscr !== null && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Export Results</CardTitle>
              <CardDescription>Download calculation results for your records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  Download as Text
                </Button>
                <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  Download as HTML
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Understanding DSCR</CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <p className="text-sm text-muted-foreground">
              The <strong>Debt Service Coverage Ratio (DSCR)</strong> measures a borrower's ability to service debt
              obligations from operating income. It is calculated by dividing Net Operating Income (NOI) by Total Debt
              Service (TDS). A DSCR of 1.5× means the borrower generates 50% more income than needed to cover debt
              payments, providing a safety margin for lenders.
            </p>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div>
                <p className="text-xs font-medium mb-1">DSCR Interpretation:</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>≥ 1.5× - Excellent coverage</li>
                  <li>1.25× - 1.49× - Good coverage</li>
                  <li>1.0× - 1.24× - Acceptable coverage</li>
                  <li>&lt; 1.0× - Insufficient coverage</li>
                </ul>
              </div>
              <div>
                <p className="text-xs font-medium mb-1">Sensitivity Analysis:</p>
                <p className="text-xs text-muted-foreground">
                  Tests resilience by simulating a 20% revenue decline. Ensures the borrower can still meet debt
                  obligations during economic downturns or operational challenges.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

