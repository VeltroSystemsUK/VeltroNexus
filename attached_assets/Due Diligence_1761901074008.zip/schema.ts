import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /**
   * Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user.
   * This mirrors the Manus account and should be used for authentication lookups.
   */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "manager", "admin"]).default("user").notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Companies table - stores UK company information from Companies House
 */
export const companies = mysqlTable("companies", {
  id: int("id").autoincrement().primaryKey(),
  companyNumber: varchar("companyNumber", { length: 20 }).notNull().unique(),
  companyName: varchar("companyName", { length: 500 }).notNull(),
  companyStatus: varchar("companyStatus", { length: 50 }),
  companyType: varchar("companyType", { length: 100 }),
  incorporationDate: varchar("incorporationDate", { length: 20 }),
  addressLine1: varchar("addressLine1", { length: 500 }),
  addressLine2: varchar("addressLine2", { length: 500 }),
  locality: varchar("locality", { length: 200 }),
  region: varchar("region", { length: 200 }),
  postalCode: varchar("postalCode", { length: 20 }),
  country: varchar("country", { length: 100 }),
  sicCodes: text("sicCodes"), // JSON array of SIC codes
  rawData: text("rawData"), // Full JSON from Companies House API
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Company = typeof companies.$inferSelect;
export type InsertCompany = typeof companies.$inferInsert;

/**
 * Prospects table - companies saved as potential lending opportunities
 */
export const prospects = mysqlTable("prospects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // User who created the prospect
  companyId: int("companyId").notNull(), // Reference to companies table
  stage: mysqlEnum("stage", [
    "lead",
    "contacted",
    "qualified",
    "proposal",
    "due-diligence",
    "approval",
    "approved",
    "declined",
    "withdrawn"
  ]).default("lead").notNull(),
  loanAmount: int("loanAmount"), // Requested loan amount in pence
  loanPurpose: text("loanPurpose"),
  loanTerm: int("loanTerm"), // Term in months
  interestRate: int("interestRate"), // Interest rate in basis points (e.g., 1700 = 17%)
  security: text("security"), // JSON array of security types
  loanNotes: text("loanNotes"),
  priority: mysqlEnum("priority", ["low", "medium", "high"]).default("medium"),
  notes: text("notes"),
  tags: text("tags"), // JSON array of tags
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Prospect = typeof prospects.$inferSelect;
export type InsertProspect = typeof prospects.$inferInsert;

/**
 * Contacts table - people associated with companies
 */
export const contacts = mysqlTable("contacts", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  firstName: varchar("firstName", { length: 200 }).notNull(),
  lastName: varchar("lastName", { length: 200 }).notNull(),
  jobTitle: varchar("jobTitle", { length: 200 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  mobile: varchar("mobile", { length: 50 }),
  isPrimary: boolean("isPrimary").default(false),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;

/**
 * Activities table - track interactions with prospects/companies
 */
export const activities = mysqlTable("activities", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  prospectId: int("prospectId"),
  companyId: int("companyId"),
  contactId: int("contactId"),
  type: mysqlEnum("type", [
    "call",
    "email",
    "meeting",
    "note",
    "task",
    "stage_change",
    "document",
    "other"
  ]).notNull(),
  subject: varchar("subject", { length: 500 }),
  description: text("description"),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

/**
 * Due Diligence Checklists - store checklist progress
 */
export const dueDiligenceChecklists = mysqlTable("dueDiligenceChecklists", {
  id: int("id").autoincrement().primaryKey(),
  prospectId: int("prospectId").notNull(),
  userId: int("userId").notNull(),
  checklistData: text("checklistData").notNull(), // JSON of checklist items with status/notes
  progress: int("progress").default(0), // Percentage complete
  status: mysqlEnum("status", ["in_progress", "completed", "archived"]).default("in_progress"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DueDiligenceChecklist = typeof dueDiligenceChecklists.$inferSelect;
export type InsertDueDiligenceChecklist = typeof dueDiligenceChecklists.$inferInsert;

/**
 * Targets table - sales/lending targets for users
 */
export const targets = mysqlTable("targets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  period: mysqlEnum("period", ["monthly", "quarterly", "yearly"]).notNull(),
  year: int("year").notNull(),
  month: int("month"), // 1-12, null for quarterly/yearly
  quarter: int("quarter"), // 1-4, null for monthly/yearly
  targetAmount: int("targetAmount").notNull(), // Target loan amount in pence
  targetCount: int("targetCount"), // Target number of loans
  actualAmount: int("actualAmount").default(0),
  actualCount: int("actualCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Target = typeof targets.$inferSelect;
export type InsertTarget = typeof targets.$inferInsert;


/**
 * Company Financials - manually entered financial data from accounts
 */
export const companyFinancials = mysqlTable("companyFinancials", {
  id: int("id").autoincrement().primaryKey(),
  companyId: int("companyId").notNull(),
  userId: int("userId").notNull(), // Who entered the data
  accountsYear: varchar("accountsYear", { length: 20 }).notNull(), // e.g., "2024" or "FY2023-24"
  accountsPeriodEnd: varchar("accountsPeriodEnd", { length: 20 }), // Date accounts made up to
  
  // Income Statement
  revenue: int("revenue"), // in pence
  grossProfit: int("grossProfit"),
  operatingProfit: int("operatingProfit"),
  profitBeforeTax: int("profitBeforeTax"),
  profitAfterTax: int("profitAfterTax"),
  
  // Balance Sheet
  totalAssets: int("totalAssets"),
  currentAssets: int("currentAssets"),
  fixedAssets: int("fixedAssets"),
  inventory: int("inventory"),
  cashAndEquivalents: int("cashAndEquivalents"),
  
  totalLiabilities: int("totalLiabilities"),
  currentLiabilities: int("currentLiabilities"),
  longTermDebt: int("longTermDebt"),
  
  shareholderEquity: int("shareholderEquity"),
  
  // Additional metrics
  numberOfEmployees: int("numberOfEmployees"),
  notes: text("notes"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CompanyFinancial = typeof companyFinancials.$inferSelect;
export type InsertCompanyFinancial = typeof companyFinancials.$inferInsert;


/**
 * Calculator Results - store calculation results per prospect
 */
export const calculatorResults = mysqlTable("calculatorResults", {
  id: int("id").autoincrement().primaryKey(),
  prospectId: int("prospectId").notNull(),
  userId: int("userId").notNull(),
  calculatorType: mysqlEnum("calculatorType", [
    "dscr",
    "loan",
    "affordability",
    "financial_ratios",
    "character_assessment",
    "loan_purpose"
  ]).notNull(),
  inputData: text("inputData").notNull(), // JSON of input values
  resultData: text("resultData").notNull(), // JSON of calculation results
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CalculatorResult = typeof calculatorResults.$inferSelect;
export type InsertCalculatorResult = typeof calculatorResults.$inferInsert;

/**
 * Application Summaries - AI-assisted application summaries
 */
export const applicationSummaries = mysqlTable("applicationSummaries", {
  id: int("id").autoincrement().primaryKey(),
  prospectId: int("prospectId").notNull(),
  userId: int("userId").notNull(),
  background: text("background"),
  campari: text("campari"),
  swot: text("swot"),
  recommendation: text("recommendation"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ApplicationSummary = typeof applicationSummaries.$inferSelect;
export type InsertApplicationSummary = typeof applicationSummaries.$inferInsert;


/**
 * User Settings table - stores user-specific application preferences
 */
export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  
  // Appearance settings
  theme: mysqlEnum("theme", ["light", "dark", "system"]).default("system"),
  primaryColor: varchar("primaryColor", { length: 20 }).default("blue"),
  accentColor: varchar("accentColor", { length: 20 }).default("slate"),
  
  // Regional settings
  currency: varchar("currency", { length: 10 }).default("GBP"),
  currencySymbol: varchar("currencySymbol", { length: 10 }).default("£"),
  dateFormat: varchar("dateFormat", { length: 20 }).default("DD/MM/YYYY"),
  numberFormat: varchar("numberFormat", { length: 20 }).default("en-GB"),
  
  // Application settings
  companyName: varchar("companyName", { length: 200 }),
  companyLogo: text("companyLogo"),
  defaultLoanTerm: int("defaultLoanTerm").default(60),
  defaultInterestRate: int("defaultInterestRate").default(1700), // 17.00% stored as basis points
  
  // Pipeline settings (JSON)
  pipelineStages: text("pipelineStages"), // JSON array of custom stages
  
  // Notification settings
  emailNotifications: boolean("emailNotifications").default(true),
  toastNotifications: boolean("toastNotifications").default(true),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;



/**
 * Invitations table - stores user invitation links
 */
export const invitations = mysqlTable("invitations", {
  id: int("id").autoincrement().primaryKey(),
  inviteCode: varchar("inviteCode", { length: 64 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  role: mysqlEnum("role", ["user", "manager", "admin"]).default("user").notNull(),
  invitedBy: int("invitedBy").notNull(), // User ID of the admin who sent the invite
  status: mysqlEnum("status", ["pending", "accepted", "expired"]).default("pending").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  acceptedAt: timestamp("acceptedAt"),
  acceptedBy: int("acceptedBy"), // User ID of the person who accepted
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Invitation = typeof invitations.$inferSelect;
export type InsertInvitation = typeof invitations.$inferInsert;

