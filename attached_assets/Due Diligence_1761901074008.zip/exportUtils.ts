/**
 * Utility functions for exporting calculator and assessment results
 */

export function downloadAsText(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadAsHTML(content: string, filename: string) {
  const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${filename}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      color: #333;
    }
    h1 {
      color: #1e40af;
      border-bottom: 2px solid #1e40af;
      padding-bottom: 10px;
    }
    h2 {
      color: #2563eb;
      margin-top: 30px;
    }
    h3 {
      color: #3b82f6;
      margin-top: 20px;
    }
    .section {
      margin-bottom: 30px;
    }
    .result {
      background: #f3f4f6;
      padding: 15px;
      border-radius: 5px;
      margin: 10px 0;
    }
    .highlight {
      background: #dbeafe;
      padding: 2px 6px;
      border-radius: 3px;
    }
    .success {
      color: #059669;
      font-weight: bold;
    }
    .warning {
      color: #d97706;
      font-weight: bold;
    }
    .error {
      color: #dc2626;
      font-weight: bold;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
    }
    th, td {
      border: 1px solid #d1d5db;
      padding: 10px;
      text-align: left;
    }
    th {
      background: #e5e7eb;
      font-weight: bold;
    }
    .logo {
      text-align: center;
      margin-bottom: 20px;
    }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #d1d5db;
      text-align: center;
      color: #6b7280;
      font-size: 0.9em;
    }
  </style>
</head>
<body>
  <div class="logo">
    <h1>First Enterprise - DueDiligence</h1>
  </div>
  ${content}
  <div class="footer">
    <p>Generated on ${new Date().toLocaleString()}</p>
    <p>First Enterprise Inclusive Lending</p>
  </div>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function copyToClipboard(content: string) {
  navigator.clipboard.writeText(content).then(
    () => {
      // Success - could show a toast notification
      return true;
    },
    (err) => {
      console.error('Failed to copy to clipboard:', err);
      return false;
    }
  );
}

