import { useState } from "react";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building2,
  ArrowLeft,
  Loader2,
  ExternalLink,
  Calendar,
  PoundSterling,
  FileText,
  Users,
  LayoutGrid,
  Target,
} from "lucide-react";
import { toast } from "sonner";
import ProspectContacts from "@/components/ProspectContacts";
import LoanRequirement from "@/components/LoanRequirement";
import SalesActivity from "@/components/SalesActivity";
import ApplicationSummary from "@/components/ApplicationSummary";

export default function ProspectDetail() {
  const [, params] = useRoute("/prospect/:id");
  const prospectId = params?.id ? parseInt(params.id) : null;
  const utils = trpc.useUtils();

  const { data: prospects, isLoading } = trpc.prospects.list.useQuery();
  const prospect = prospects?.find((p: any) => p.id === prospectId);

  const updateProspectMutation = trpc.prospects.update.useMutation({
    onSuccess: () => {
      toast.success("Prospect updated");
      utils.prospects.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to update prospect: " + error.message);
    },
  });

  const deleteProspectMutation = trpc.prospects.delete.useMutation({
    onSuccess: () => {
      toast.success("Prospect deleted");
      utils.prospects.list.invalidate();
      window.location.href = "/prospects";
    },
    onError: (error) => {
      toast.error("Failed to delete prospect: " + error.message);
    },
  });

  const handleStageChange = (stage: string) => {
    if (prospectId) {
      updateProspectMutation.mutate({ id: prospectId, status: stage });
    }
  };

  const handleDeleteProspect = () => {
    if (prospectId && confirm("Are you sure you want to delete this prospect?")) {
      deleteProspectMutation.mutate({ id: prospectId });
    }
  };

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "lead":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
      case "contacted":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "qualified":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "proposal":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "due-diligence":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      case "approval":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200";
      case "approved":
        return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200";
      case "declined":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "withdrawn":
        return "bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount / 100);
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!prospect) {
    return (
      <div className="container mx-auto py-12">
        <Card>
          <CardContent className="text-center py-12">
            <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">Prospect not found</h3>
            <p className="text-muted-foreground mb-4">
              The prospect you're looking for doesn't exist or has been deleted.
            </p>
            <Link href="/prospects">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Prospects
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/prospects">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold">
                {prospect.company?.companyName || "Unknown Company"}
              </h1>
            </div>
            <p className="text-muted-foreground mt-1">
              {prospect.company?.companyNumber || "No company number"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link href={`/company/${prospect.company?.companyNumber}`}>
            <Button variant="outline" size="sm">
              <ExternalLink className="mr-2 h-4 w-4" />
              View in Directory
            </Button>
          </Link>
          <Button variant="outline" size="sm" onClick={handleDeleteProspect}>
            Delete Prospect
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Stage</p>
                <Select
                  value={prospect.stage || "lead"}
                  onValueChange={handleStageChange}
                >
                  <SelectTrigger className="w-full mt-2 border-0 p-0 h-auto focus:ring-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lead">Lead</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="due-diligence">Due Diligence</SelectItem>
                    <SelectItem value="approval">Approval</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                    <SelectItem value="withdrawn">Withdrawn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <LayoutGrid className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Loan Amount</p>
                <p className="text-2xl font-bold mt-1">
                  {prospect.loanAmount ? formatCurrency(prospect.loanAmount) : "Not set"}
                </p>
              </div>
              <PoundSterling className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Date Added</p>
                <p className="text-lg font-semibold mt-1">
                  {formatDate(prospect.createdAt)}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Priority</p>
                <Target className="h-5 w-5 text-muted-foreground" />
              </div>
              <Select
                value={prospect.priority || "medium"}
                onValueChange={(value: "low" | "medium" | "high") => {
                  updateProspectMutation.mutate({
                    id: prospect.id,
                    priority: value,
                  });
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      Low Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="medium">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-amber-500" />
                      Medium Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="high">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500" />
                      High Priority
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Company Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Company Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between py-3 border-b">
                <span className="text-muted-foreground">Company Status</span>
                <Badge className={getStageColor(prospect.company?.companyStatus || "")}>
                  {prospect.company?.companyStatus?.toUpperCase() || "UNKNOWN"}
                </Badge>
              </div>
              <div className="flex justify-between py-3 border-b">
                <span className="text-muted-foreground">Incorporation Date</span>
                <span className="font-medium">
                  {formatDate(prospect.company?.incorporationDate || null)}
                </span>
              </div>
              <div className="flex justify-between py-3 border-b">
                <span className="text-muted-foreground">Company Type</span>
                <span className="font-medium">
                  {prospect.company?.companyType?.replace(/-/g, " ") || "N/A"}
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between py-3 border-b">
                <span className="text-muted-foreground">Registered Address</span>
                <span className="font-medium text-right max-w-md">
                  {[
                    prospect.company?.addressLine1,
                    prospect.company?.addressLine2,
                    prospect.company?.locality,
                    prospect.company?.postalCode,
                    prospect.company?.country,
                  ]
                    .filter(Boolean)
                    .join(", ") || "N/A"}
                </span>
              </div>
              <div className="flex justify-between py-3 border-b">
                <span className="text-muted-foreground">Last Updated</span>
                <span className="font-medium">
                  {formatDate(prospect.updatedAt)}
                </span>
              </div>
            </div>
          </div>

          {prospect.notes && (
            <div className="mt-6 p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">Notes</h4>
              <p className="text-sm">{prospect.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabs for detailed information */}
      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="contacts" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="contacts">Contacts</TabsTrigger>
              <TabsTrigger value="loan">Loan Requirement</TabsTrigger>
              <TabsTrigger value="activity">Sales Activity</TabsTrigger>
              <TabsTrigger value="duediligence">Due Diligence</TabsTrigger>
              <TabsTrigger value="summary">Summary</TabsTrigger>
            </TabsList>

            <TabsContent value="contacts" className="space-y-4 mt-6">
              <ProspectContacts 
                companyId={prospect.companyId} 
                companyNumber={prospect.company?.companyNumber || ""}
              />
            </TabsContent>

            <TabsContent value="loan" className="space-y-4 mt-6">
              <LoanRequirement prospectId={prospect.id} prospect={prospect} />
            </TabsContent>

            <TabsContent value="activity" className="space-y-4 mt-6">
              <SalesActivity prospectId={prospect.id} />
            </TabsContent>

            <TabsContent value="duediligence" className="space-y-4 mt-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Due Diligence Tools</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Access all due diligence tools and assessments for {prospect.company?.companyName}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link href={`/due-diligence/checklist?prospectId=${prospect.id}&companyName=${encodeURIComponent(prospect.company?.companyName || '')}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Due Diligence Checklist</div>
                        <div className="text-xs text-muted-foreground">56-item comprehensive checklist</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/dscr-calculator?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">DSCR Calculator</div>
                        <div className="text-xs text-muted-foreground">Debt Service Coverage Ratio</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/loan-calculator?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Loan Calculator</div>
                        <div className="text-xs text-muted-foreground">Payment calculations</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/affordability?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Affordability Estimator</div>
                        <div className="text-xs text-muted-foreground">Assess repayment capacity</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/financial-ratios?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Financial Ratios</div>
                        <div className="text-xs text-muted-foreground">Key financial metrics</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/character-assessor?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Character Assessor</div>
                        <div className="text-xs text-muted-foreground">Evaluate borrower character</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href={`/due-diligence/loan-purpose?prospectId=${prospect.id}`}>
                    <Button variant="outline" className="w-full justify-start h-auto py-4">
                      <FileText className="w-5 h-5 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Loan Purpose Assessment</div>
                        <div className="text-xs text-muted-foreground">Analyze loan purpose</div>
                      </div>
                    </Button>
                  </Link>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="summary" className="space-y-4 mt-6">
              <ApplicationSummary prospectId={prospect.id} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

