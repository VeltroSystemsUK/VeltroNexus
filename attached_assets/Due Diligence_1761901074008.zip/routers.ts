import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { generateChecklistPDF } from "./pdfGenerator";
import { storagePut } from "./storage";
import * as db from "./db";
import * as companiesHouse from "./companiesHouse";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  checklist: router({
    generatePDF: publicProcedure
      .input(
        z.object({
          responses: z.record(
            z.string(),
            z.object({
              completed: z.enum(["Y", "N", ""]),
              notes: z.string(),
            })
          ),
        })
      )
      .mutation(async ({ input }) => {
        // Convert string keys to numbers
        const responses: Record<number, { completed: "Y" | "N" | ""; notes: string }> = {};
        Object.entries(input.responses).forEach(([key, value]) => {
          responses[parseInt(key)] = value;
        });

        // Generate PDF
        const pdfBuffer = await generateChecklistPDF(responses);

        // Upload to S3
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const { url } = await storagePut(
          `reports/duediligence-${timestamp}.pdf`,
          pdfBuffer,
          "application/pdf"
        );

        return { url };
      }),
  }),

  prospects: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getProspectsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          companyId: z.number(),
          loanAmount: z.number().optional(),
          loanPurpose: z.string().optional(),
          priority: z.enum(["low", "medium", "high"]).optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createProspect({
          userId: ctx.user.id,
          ...input,
        });
      }),

    updateStage: protectedProcedure
      .input(
        z.object({
          prospectId: z.number(),
          stage: z.enum([
            "lead",
            "contacted",
            "qualified",
            "proposal",
            "due-diligence",
            "approval",
            "approved",
            "declined",
            "withdrawn",
          ]),
        })
      )
      .mutation(async ({ input }) => {
        await db.updateProspectStage(input.prospectId, input.stage);
        return { success: true };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.string().optional(),
          loanAmount: z.number().optional(),
          loanPurpose: z.string().optional(),
          loanTerm: z.number().optional(),
          interestRate: z.number().optional(),
          security: z.string().optional(),
          loanNotes: z.string().optional(),
          priority: z.enum(["low", "medium", "high"]).optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateProspect(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteProspect(input.id);
      }),
  }),

  companies: router({
    search: protectedProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.searchCompanies(input.query);
      }),

    getProfile: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyProfile(input.companyNumber);
      }),

    getOfficers: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyOfficers(input.companyNumber);
      }),

    getPSC: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyPSC(input.companyNumber);
      }),

    getCharges: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyCharges(input.companyNumber);
      }),

    getFilingHistory: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyFilingHistory(input.companyNumber);
      }),

    getInsolvency: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await companiesHouse.getCompanyInsolvency(input.companyNumber);
      }),
    upsert: protectedProcedure
      .input(
        z.object({
          companyNumber: z.string(),
          companyName: z.string(),
          companyStatus: z.string().optional(),
          companyType: z.string().optional(),
          incorporationDate: z.string().optional(),
          addressLine1: z.string().optional(),
          addressLine2: z.string().optional(),
          locality: z.string().optional(),
          region: z.string().optional(),
          postalCode: z.string().optional(),
          country: z.string().optional(),
          rawData: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.upsertCompany(input);
      }),

    getByNumber: protectedProcedure
      .input(z.object({ companyNumber: z.string() }))
      .query(async ({ input }) => {
        return await db.getCompanyByNumber(input.companyNumber);
      }),

    // Financial data endpoints
    getFinancials: protectedProcedure
      .input(z.object({ companyId: z.number() }))
      .query(async ({ input }) => {
        return await db.getFinancialsByCompany(input.companyId);
      }),

    createFinancial: protectedProcedure
      .input(
        z.object({
          companyId: z.number(),
          accountsYear: z.string(),
          accountsPeriodEnd: z.string().optional(),
          revenue: z.number().optional(),
          grossProfit: z.number().optional(),
          operatingProfit: z.number().optional(),
          profitBeforeTax: z.number().optional(),
          profitAfterTax: z.number().optional(),
          totalAssets: z.number().optional(),
          currentAssets: z.number().optional(),
          fixedAssets: z.number().optional(),
          inventory: z.number().optional(),
          cashAndEquivalents: z.number().optional(),
          totalLiabilities: z.number().optional(),
          currentLiabilities: z.number().optional(),
          longTermDebt: z.number().optional(),
          shareholderEquity: z.number().optional(),
          numberOfEmployees: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Not authenticated");
        return await db.createCompanyFinancial({
          ...input,
          userId: ctx.user.id,
        });
      }),

    updateFinancial: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          accountsYear: z.string().optional(),
          accountsPeriodEnd: z.string().optional(),
          revenue: z.number().optional(),
          grossProfit: z.number().optional(),
          operatingProfit: z.number().optional(),
          profitBeforeTax: z.number().optional(),
          profitAfterTax: z.number().optional(),
          totalAssets: z.number().optional(),
          currentAssets: z.number().optional(),
          fixedAssets: z.number().optional(),
          inventory: z.number().optional(),
          cashAndEquivalents: z.number().optional(),
          totalLiabilities: z.number().optional(),
          currentLiabilities: z.number().optional(),
          longTermDebt: z.number().optional(),
          shareholderEquity: z.number().optional(),
          numberOfEmployees: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateCompanyFinancial(id, data);
      }),
  }),

  contacts: router({
    list: protectedProcedure
      .input(z.object({ companyId: z.number() }))
      .query(async ({ input }) => {
        return await db.getContactsByCompany(input.companyId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          companyId: z.number(),
          firstName: z.string(),
          lastName: z.string(),
          jobTitle: z.string().optional(),
          email: z.string().optional(),
          phone: z.string().optional(),
          mobile: z.string().optional(),
          isPrimary: z.boolean().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createContact(input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          firstName: z.string().optional(),
          lastName: z.string().optional(),
          jobTitle: z.string().optional(),
          email: z.string().optional(),
          phone: z.string().optional(),
          mobile: z.string().optional(),
          isPrimary: z.boolean().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateContact(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteContact(input.id);
      }),
  }),

  activities: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getActivitiesByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          prospectId: z.number().optional(),
          companyId: z.number().optional(),
          contactId: z.number().optional(),
          type: z.enum(["call", "email", "meeting", "note", "task", "stage_change", "document", "other"]),
          subject: z.string().optional(),
          description: z.string().optional(),
          dueDate: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createActivity({
          userId: ctx.user.id,
          ...input,
        });
      }),
  }),

  targets: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getTargetsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          period: z.enum(["monthly", "quarterly", "yearly"]),
          year: z.number(),
          month: z.number().optional(),
          quarter: z.number().optional(),
          targetAmount: z.number(),
          targetCount: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createTarget({
          userId: ctx.user.id,
          ...input,
        });
      }),
  }),

  dueDiligence: router({
    // Save calculator results
    saveCalculatorResult: protectedProcedure
      .input(
        z.object({
          prospectId: z.number(),
          calculatorType: z.enum([
            "dscr",
            "loan",
            "affordability",
            "financial_ratios",
            "character_assessment",
            "loan_purpose"
          ]),
          inputData: z.string(), // JSON string
          resultData: z.string(), // JSON string
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.saveCalculatorResult({
          userId: ctx.user.id,
          ...input,
        });
      }),

    // Get calculator results for a prospect
    getCalculatorResults: protectedProcedure
      .input(
        z.object({
          prospectId: z.number(),
          calculatorType: z.enum([
            "dscr",
            "loan",
            "affordability",
            "financial_ratios",
            "character_assessment",
            "loan_purpose"
          ]).optional(),
        })
      )
      .query(async ({ input }) => {
        return await db.getCalculatorResultsByProspect(
          input.prospectId,
          input.calculatorType
        );
      }),

    // Save due diligence checklist
    saveChecklist: protectedProcedure
      .input(
        z.object({
          prospectId: z.number(),
          checklistData: z.string(), // JSON string
          progress: z.number(),
          status: z.enum(["in_progress", "completed", "archived"]).optional(),
          completedAt: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.saveDueDiligenceChecklist({
          userId: ctx.user.id,
          status: "in_progress",
          ...input,
        });
      }),

    // Get due diligence checklist for a prospect
    getChecklist: protectedProcedure
      .input(z.object({ prospectId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDueDiligenceChecklistByProspect(input.prospectId);
      }),
  }),

  applicationSummaries: router({
    get: protectedProcedure
      .input(z.object({ prospectId: z.number() }))
      .query(async ({ input }) => {
        return await db.getApplicationSummaryByProspect(input.prospectId);
      }),

    save: protectedProcedure
      .input(
        z.object({
          prospectId: z.number(),
          background: z.string().optional(),
          campari: z.string().optional(),
          swot: z.string().optional(),
          recommendation: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await db.saveApplicationSummary({
          ...input,
          userId: ctx.user.id,
        });
      }),
  }),

  userSettings: router({
    get: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getOrCreateUserSettings(ctx.user.id);
      }),

    update: protectedProcedure
      .input(
        z.object({
          theme: z.enum(["light", "dark", "system"]).optional(),
          primaryColor: z.string().optional(),
          accentColor: z.string().optional(),
          currency: z.string().optional(),
          currencySymbol: z.string().optional(),
          dateFormat: z.string().optional(),
          numberFormat: z.string().optional(),
          companyName: z.string().optional(),
          companyLogo: z.string().optional(),
          defaultLoanTerm: z.number().optional(),
          defaultInterestRate: z.number().optional(),
          pipelineStages: z.string().optional(),
          emailNotifications: z.boolean().optional(),
          toastNotifications: z.boolean().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await db.upsertUserSettings(ctx.user.id, input);
      }),
  }),

  users: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        // Only admins can list users
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        return await db.getAllUsers();
      }),

    updateRole: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
          role: z.enum(["user", "manager", "admin"]),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Only admins can update roles
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        return await db.updateUserRole(input.userId, input.role);
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
          status: z.enum(["active", "inactive"]),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Only admins can update status
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        return await db.updateUserStatus(input.userId, input.status);
      }),
  }),

  invitations: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        // Only admins can list invitations
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        return await db.getAllInvitations();
      }),

    create: protectedProcedure
      .input(
        z.object({
          email: z.string().email().optional(),
          role: z.enum(["user", "manager", "admin"]).default("user"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Only admins can create invitations
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }

        // Generate unique invite code
        const inviteCode = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        
        // Set expiration to 7 days from now
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);

        return await db.createInvitation({
          inviteCode,
          email: input.email,
          role: input.role,
          invitedBy: ctx.user.id,
          expiresAt,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Only admins can delete invitations
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        return await db.deleteInvitation(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;

