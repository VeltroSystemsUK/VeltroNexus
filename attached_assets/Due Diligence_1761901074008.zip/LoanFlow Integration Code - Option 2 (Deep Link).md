# LoanFlow Integration Code - Option 2 (Deep Link)

## Implementation Complete! ✅

The DueDiligence app is now ready to receive company data from LoanFlow via URL parameters. As you can see in the screenshot, it successfully displays:

- 📋 Company from LoanFlow banner
- Company Name: **Acme Ltd**
- Company Number: **09876543**
- Loan Amount: **£150000**

---

## For Your LoanFlow Developers

Here's the code to add to LoanFlow to create deep links to DueDiligence:

### Step 1: Add "Due Diligence" Button to Company View

Add this button wherever you want to launch due diligence (e.g., in company detail page, prospect card, etc.):

```jsx
// In your LoanFlow component (React/Next.js)
import { ExternalLink } from 'lucide-react'; // or your icon library

function CompanyCard({ company }) {
  const openDueDiligence = () => {
    // Build the URL with company parameters
    const baseUrl = 'https://your-duediligence-domain.com'; // Update after publishing
    const params = new URLSearchParams({
      companyId: company.id,
      companyName: company.name,
      companyNumber: company.registrationNumber || '',
      contactName: company.contactName || '',
      contactEmail: company.contactEmail || '',
      loanAmount: company.requestedLoanAmount || '',
      loanPurpose: company.loanPurpose || '',
      source: 'loanflow'
    });
    
    const url = `${baseUrl}?${params.toString()}`;
    window.open(url, '_blank');
  };

  return (
    <div className="company-card">
      <h3>{company.name}</h3>
      {/* Your existing company info */}
      
      <button 
        onClick={openDueDiligence}
        className="btn btn-primary"
      >
        <ExternalLink className="w-4 h-4 mr-2" />
        Start Due Diligence
      </button>
    </div>
  );
}
```

### Step 2: Alternative - Add to Action Menu

If you have an actions dropdown/menu:

```jsx
function CompanyActions({ company }) {
  const actions = [
    {
      label: 'Start Due Diligence',
      icon: FileCheck,
      onClick: () => {
        const url = buildDueDiligenceURL(company);
        window.open(url, '_blank');
      }
    },
    // ... other actions
  ];

  return <ActionsMenu actions={actions} />;
}

// Helper function
function buildDueDiligenceURL(company) {
  const baseUrl = 'https://your-duediligence-domain.com';
  const params = new URLSearchParams({
    companyId: company.id,
    companyName: company.name,
    companyNumber: company.registrationNumber || '',
    loanAmount: company.requestedLoanAmount || '',
    source: 'loanflow'
  });
  return `${baseUrl}?${params.toString()}`;
}
```

### Step 3: Add to Kanban/Pipeline View

For your Kanban board:

```jsx
function ProspectCard({ prospect }) {
  return (
    <div className="prospect-card">
      <h4>{prospect.companyName}</h4>
      <p>Stage: {prospect.stage}</p>
      
      {/* Show button when prospect reaches due diligence stage */}
      {prospect.stage === 'due-diligence' && (
        <a
          href={buildDueDiligenceURL(prospect)}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-sm btn-outline"
        >
          Complete Due Diligence →
        </a>
      )}
    </div>
  );
}
```

---

## URL Parameters Reference

The DueDiligence app accepts these parameters:

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| `companyId` | string | Your internal company ID | `12345` |
| `companyName` | string | Company name | `Acme Ltd` |
| `companyNumber` | string | Companies House number | `09876543` |
| `contactName` | string | Primary contact name | `John Smith` |
| `contactEmail` | string | Contact email | `john@acme.com` |
| `loanAmount` | string | Requested loan amount | `150000` |
| `loanPurpose` | string | Purpose of loan | `Working Capital` |
| `source` | string | Always set to `loanflow` | `loanflow` |

**Important:** All parameters are optional except `source`. The app will display whatever data you provide.

---

## Example URLs

### Minimal (just company name):
```
https://your-duediligence-domain.com?companyName=Acme%20Ltd&source=loanflow
```

### Full data:
```
https://your-duediligence-domain.com?companyId=12345&companyName=Acme%20Ltd&companyNumber=09876543&contactName=John%20Smith&contactEmail=john@acme.com&loanAmount=150000&loanPurpose=Working%20Capital&source=loanflow
```

---

## Testing the Integration

### Test URL (use this to test right now):
```
https://3000-ix9zygj8rgaznvoilaf46-ac6d27e6.manusvm.computer?companyId=TEST123&companyName=Test%20Company&companyNumber=12345678&loanAmount=100000&source=loanflow
```

Try opening this URL in a new tab to see how it works!

---

## After Publishing DueDiligence

Once you publish the DueDiligence app, you'll get a permanent URL like:
- `https://duediligence.manus.space` (Manus subdomain)
- `https://duediligence.yourdomain.com` (custom domain)

**Update the `baseUrl` in your LoanFlow code to this permanent URL.**

---

## Data Persistence

The company data is stored in the browser's `sessionStorage`, so:
- ✅ Data persists as user navigates between pages in DueDiligence
- ✅ Data is cleared when browser tab is closed
- ✅ No data is sent to any server (privacy-friendly)
- ✅ Each new link from LoanFlow starts fresh

---

## Styling Customization

If you want to customize the company info banner to match LoanFlow's branding:

1. The banner is in `/client/src/pages/Home.tsx` (lines 52-63)
2. Current styling: Blue background (`bg-blue-50`)
3. You can change colors, add your logo, or modify the layout

---

## Future Enhancements

Possible future improvements:

1. **Return data to LoanFlow**: When user completes checklist, send results back
2. **Save to LoanFlow database**: Store checklist progress in your system
3. **Single Sign-On (SSO)**: Share authentication between apps
4. **Webhooks**: Notify LoanFlow when due diligence is complete

Let me know if you want to implement any of these!

---

## Support

If your developers have questions about the integration, they can:
1. Test using the current development URL
2. Review the URL parameter handling in `/client/src/lib/urlParams.ts`
3. Check the Home page implementation in `/client/src/pages/Home.tsx`

---

## Next Steps

1. ✅ DueDiligence is ready to receive data
2. ⏳ Add button/link in LoanFlow using code above
3. ⏳ Test with real company data
4. ⏳ Publish DueDiligence to get permanent URL
5. ⏳ Update LoanFlow code with permanent URL
6. ✅ Launch!

