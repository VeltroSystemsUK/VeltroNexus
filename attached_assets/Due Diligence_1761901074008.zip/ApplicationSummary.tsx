import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FileText } from "lucide-react";
import { toast } from "sonner";

interface ApplicationSummaryProps {
  prospectId: number;
}

export default function ApplicationSummary({ prospectId }: ApplicationSummaryProps) {
  const [background, setBackground] = useState("");
  const [campari, setCampari] = useState("");
  const [swot, setSwot] = useState("");
  const [recommendation, setRecommendation] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const { data: summary, isLoading } = trpc.applicationSummaries.get.useQuery({ prospectId });

  useEffect(() => {
    if (summary) {
      setBackground(summary.background || "");
      setCampari(summary.campari || "");
      setSwot(summary.swot || "");
      setRecommendation(summary.recommendation || "");
    }
  }, [summary]);

  const saveSummaryMutation = trpc.applicationSummaries.save.useMutation({
    onSuccess: () => {
      toast.success("Application summary saved successfully");
      setIsSaving(false);
    },
    onError: (error: any) => {
      toast.error(`Failed to save: ${error.message}`);
      setIsSaving(false);
    },
  });

  const handleSave = () => {
    setIsSaving(true);
    saveSummaryMutation.mutate({
      prospectId,
      background,
      campari,
      swot,
      recommendation,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading summary...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-1">AI Assisted Application Summary</h3>
      </div>

      <div className="space-y-2">
        <Label htmlFor="background">Background</Label>
        <Textarea
          id="background"
          value={background}
          onChange={(e) => setBackground(e.target.value)}
          placeholder="Enter background notes..."
          rows={4}
          className="resize-none"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="campari">CAMPARI</Label>
        <Textarea
          id="campari"
          value={campari}
          onChange={(e) => setCampari(e.target.value)}
          placeholder="Enter CAMPARI analysis notes..."
          rows={4}
          className="resize-none"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="swot">SWOT</Label>
        <Textarea
          id="swot"
          value={swot}
          onChange={(e) => setSwot(e.target.value)}
          placeholder="Enter SWOT analysis notes..."
          rows={4}
          className="resize-none"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="recommendation">Recommendation</Label>
        <Textarea
          id="recommendation"
          value={recommendation}
          onChange={(e) => setRecommendation(e.target.value)}
          placeholder="Enter final recommendation..."
          rows={4}
          className="resize-none"
        />
      </div>

      <div className="flex items-center justify-between pt-4">
        <Button variant="outline" disabled>
          <FileText className="mr-2 h-4 w-4" />
          Create Application
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save Summary"}
        </Button>
      </div>
    </div>
  );
}

