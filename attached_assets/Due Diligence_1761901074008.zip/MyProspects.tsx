import { useState, useMemo } from "react";
import { Link } from "wouter";
import ProspectContacts from "@/components/ProspectContacts";
import LoanRequirement from "@/components/LoanRequirement";
import SalesActivity from "@/components/SalesActivity";
import ApplicationSummary from "@/components/ApplicationSummary";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building2,
  Users,
  LayoutGrid,
  Calendar as CalendarIcon,
  Target,
  Trash2,
  ChevronDown,
  ChevronUp,
  Loader2,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function MyProspects() {
  const [expandedProspect, setExpandedProspect] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const utils = trpc.useUtils();

  const { data: prospects, isLoading } = trpc.prospects.list.useQuery();

  const updateProspectMutation = trpc.prospects.update.useMutation({
    onSuccess: () => {
      toast.success("Prospect updated");
      utils.prospects.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to update prospect: " + error.message);
    },
  });

  const deleteProspectMutation = trpc.prospects.delete.useMutation({
    onSuccess: () => {
      toast.success("Prospect deleted");
      utils.prospects.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to delete prospect: " + error.message);
    },
  });

  const handleStatusChange = (prospectId: number, status: string) => {
    updateProspectMutation.mutate({ id: prospectId, status });
  };

  const handleDeleteProspect = (prospectId: number) => {
    if (confirm("Are you sure you want to delete this prospect?")) {
      deleteProspectMutation.mutate({ id: prospectId });
    }
  };

  const toggleExpand = (prospectId: number) => {
    setExpandedProspect(expandedProspect === prospectId ? null : prospectId);
  };

  // Filter prospects based on search query
  const filteredProspects = useMemo(() => {
    if (!prospects) return [];
    if (!searchQuery.trim()) return prospects;

    const query = searchQuery.toLowerCase();
    return prospects.filter((prospect: any) => {
      const companyName = prospect.company?.companyName?.toLowerCase() || "";
      const companyNumber = prospect.company?.companyNumber?.toLowerCase() || "";
      return companyName.includes(query) || companyNumber.includes(query);
    });
  }, [prospects, searchQuery]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "qualified":
        return "bg-green-100 text-green-800";
      case "contacted":
        return "bg-blue-100 text-blue-800";
      case "proposal":
        return "bg-purple-100 text-purple-800";
      case "negotiation":
        return "bg-orange-100 text-orange-800";
      case "won":
        return "bg-emerald-100 text-emerald-800";
      case "lost":
        return "bg-red-100 text-red-800";
      default:
        return "bg-yellow-100 text-yellow-800";
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">My Prospects</h1>
        <p className="text-muted-foreground mt-1">
          Manage your prospect companies and track their progress
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search prospects by company name or number..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
        {searchQuery && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 px-2"
            onClick={() => setSearchQuery("")}
          >
            Clear
          </Button>
        )}
      </div>

      {/* Top Navigation Tabs */}
      <div className="flex items-center gap-2 border-b pb-2">
        <Button variant="ghost" className="gap-2 font-semibold border-b-2 border-primary">
          <Building2 className="w-4 h-4" />
          My Prospects ({filteredProspects.length}{searchQuery && prospects ? ` of ${prospects.length}` : ""})
        </Button>
        <Link href="/contacts">
          <Button variant="ghost" className="gap-2">
            <Users className="w-4 h-4" />
            Contacts
          </Button>
        </Link>
        <Link href="/company-directory">
          <Button variant="ghost" className="gap-2">
            <LayoutGrid className="w-4 h-4" />
            Company Directory
          </Button>
        </Link>
        <Link href="/pipeline">
          <Button variant="ghost" className="gap-2">
            <LayoutGrid className="w-4 h-4" />
            Kanban
          </Button>
        </Link>
        <Link href="/calendar">
          <Button variant="ghost" className="gap-2">
            <CalendarIcon className="w-4 h-4" />
            Calendar
          </Button>
        </Link>
        <Link href="/targets">
          <Button variant="ghost" className="gap-2">
            <Target className="w-4 h-4" />
            Targets
          </Button>
        </Link>
      </div>

      {/* Prospects List */}
      {prospects && prospects.length > 0 ? (
        filteredProspects.length > 0 ? (
          <div className="space-y-4">
            {filteredProspects.map((prospect: any) => (
            <Card key={prospect.id} className="overflow-hidden">
              {/* Company Header */}
              <Link href={`/prospect/${prospect.id}`}>
                <div className="flex items-center justify-between p-4 border-b bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3 flex-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      toggleExpand(prospect.id);
                    }}
                    className="p-0 h-auto"
                  >
                    {expandedProspect === prospect.id ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </Button>
                  <Building2 className="w-5 h-5 text-primary" />
                  <h3 className="text-lg font-semibold">
                    {prospect.company?.companyName || "Unknown Company"}
                  </h3>
                </div>
                <div className="flex items-center gap-3">
                  <Select
                    value={prospect.status || "pending"}
                    onValueChange={(value) => {
                      updateProspectMutation.mutate({
                        id: prospect.id,
                        status: value,
                      });
                    }}
                  >
                    <SelectTrigger className="w-[180px]" onClick={(e) => e.stopPropagation()}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-yellow-500" />
                          Pending
                        </div>
                      </SelectItem>
                      <SelectItem value="qualified">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                          Qualified
                        </div>
                      </SelectItem>
                      <SelectItem value="contacted">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-blue-500" />
                          Contacted
                        </div>
                      </SelectItem>
                      <SelectItem value="proposal">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-purple-500" />
                          Proposal
                        </div>
                      </SelectItem>
                      <SelectItem value="negotiation">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-orange-500" />
                          Negotiation
                        </div>
                      </SelectItem>
                      <SelectItem value="won">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-emerald-500" />
                          Won
                        </div>
                      </SelectItem>
                      <SelectItem value="lost">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-red-500" />
                          Lost
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={prospect.priority || "medium"}
                    onValueChange={(value: "low" | "medium" | "high") => {
                      updateProspectMutation.mutate({
                        id: prospect.id,
                        priority: value,
                      });
                    }}
                  >
                    <SelectTrigger className="w-[160px]" onClick={(e) => e.stopPropagation()}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-blue-500" />
                          Low Priority
                        </div>
                      </SelectItem>
                      <SelectItem value="medium">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-amber-500" />
                          Medium Priority
                        </div>
                      </SelectItem>
                      <SelectItem value="high">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-red-500" />
                          High Priority
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      handleDeleteProspect(prospect.id);
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
              </Link>

              {/* Expanded Content */}
              {expandedProspect === prospect.id && (
                <div className="p-4">
                  <Tabs defaultValue="business" className="w-full">
                    <TabsList>
                      <TabsTrigger value="business">Business</TabsTrigger>
                      <TabsTrigger value="contacts">Contacts</TabsTrigger>
                      <TabsTrigger value="loan">Loan Requirement</TabsTrigger>
                      <TabsTrigger value="duediligence">Due Diligence</TabsTrigger>
                      <TabsTrigger value="activity">Sales Activity</TabsTrigger>
                      <TabsTrigger value="summary">Summary</TabsTrigger>
                    </TabsList>

                    {/* Business Tab */}
                    <TabsContent value="business" className="space-y-4">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-lg font-semibold">Overview</h4>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Users className="w-4 h-4 mr-2" />
                            View All Contacts
                          </Button>
                          <Link href={`/company/${prospect.company?.companyNumber}`}>
                            <Button variant="outline" size="sm">
                              <Building2 className="w-4 h-4 mr-2" />
                              View in Directory
                            </Button>
                          </Link>
                          <Button variant="outline" size="sm">
                            <LayoutGrid className="w-4 h-4 mr-2" />
                            View on Kanban
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Date Added</span>
                            <span className="font-medium">
                              {new Date(prospect.createdAt).toLocaleDateString("en-GB", {
                                day: "numeric",
                                month: "long",
                                year: "numeric",
                              })}
                            </span>
                          </div>
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Status</span>
                            <Badge className={getStatusColor(prospect.company?.companyStatus || "")}>
                              {prospect.company?.companyStatus?.toUpperCase() || "UNKNOWN"}
                            </Badge>
                          </div>
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Incorporation Date</span>
                            <span className="font-medium">
                              {prospect.company?.incorporationDate
                                ? new Date(prospect.company.incorporationDate).toLocaleDateString(
                                    "en-GB",
                                    {
                                      day: "numeric",
                                      month: "long",
                                      year: "numeric",
                                    }
                                  )
                                : "N/A"}
                            </span>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Company Type</span>
                            <span className="font-medium">
                              {prospect.company?.companyType?.replace(/-/g, " ") || "N/A"}
                            </span>
                          </div>
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Registered Address</span>
                            <span className="font-medium text-right max-w-md">
                              {[
                                prospect.company?.addressLine1,
                                prospect.company?.addressLine2,
                                prospect.company?.locality,
                                prospect.company?.postalCode,
                                prospect.company?.country,
                              ]
                                .filter(Boolean)
                                .join(", ") || "N/A"}
                            </span>
                          </div>
                          <div className="flex justify-between py-3 border-b">
                            <span className="text-muted-foreground">Nature of Business (SIC)</span>
                            <span className="font-medium">
                              {/* SIC codes would come from company profile */}
                              N/A
                            </span>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Contacts Tab */}
                    <TabsContent value="contacts" className="space-y-4">
                      <ProspectContacts 
                        companyId={prospect.companyId} 
                        companyNumber={prospect.company?.companyNumber || ""}
                      />
                    </TabsContent>

                    {/* Loan Requirement Tab */}
                    <TabsContent value="loan" className="space-y-4">
                      <LoanRequirement prospectId={prospect.id} prospect={prospect} />
                    </TabsContent>

                    {/* Sales Activity Tab */}
                    <TabsContent value="activity" className="space-y-4">
                      <SalesActivity prospectId={prospect.id} />
                    </TabsContent>

                    {/* Due Diligence Tab */}
                    <TabsContent value="duediligence">
                      <Card>
                        <CardHeader>
                          <CardTitle>Due Diligence Tools</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <p className="text-sm text-muted-foreground mb-4">
                            Access all due diligence tools and assessments for {prospect.company?.companyName}
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Link href={`/due-diligence/checklist?prospectId=${prospect.id}&companyName=${encodeURIComponent(prospect.company?.companyName || '')}`}>
                              <Button variant="outline" className="w-full justify-start">
                                <Building2 className="w-4 h-4 mr-2" />
                                Due Diligence Checklist
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/dscr-calculator?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                DSCR Calculator
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/loan-calculator?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                Loan Calculator
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/affordability?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                Affordability Estimator
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/financial-ratios?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                Financial Ratios
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/character-assessor?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                Character Assessor
                              </Button>
                            </Link>
                            <Link href={`/due-diligence/loan-purpose?prospectId=${prospect.id}`}>
                              <Button variant="outline" className="w-full justify-start">
                                Loan Purpose Assessment
                              </Button>
                            </Link>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    {/* Summary Tab */}
                    <TabsContent value="summary" className="space-y-4">
                      <ApplicationSummary prospectId={prospect.id} />
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-2">No prospects found</p>
            <p className="text-sm text-muted-foreground mb-4">
              No prospects match "{searchQuery}"
            </p>
            <Button onClick={() => setSearchQuery("")} variant="outline">
              Clear Search
            </Button>
          </CardContent>
        </Card>
      )
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Building2 className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No prospects yet</h3>
            <p className="text-muted-foreground mb-4">
              Search for companies and add them to your prospects
            </p>
            <Link href="/">
              <Button>Search Companies</Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
