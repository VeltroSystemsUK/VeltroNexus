import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Mail, Phone, Smartphone, Briefcase, Building2, Star, MoreVertical, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

type ContactFormData = {
  firstName: string;
  lastName: string;
  jobTitle: string;
  email: string;
  phone: string;
  mobile: string;
  isPrimary: boolean;
  notes: string;
};

export default function Contacts() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<number | null>(null);
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);
  const [formData, setFormData] = useState<ContactFormData>({
    firstName: "",
    lastName: "",
    jobTitle: "",
    email: "",
    phone: "",
    mobile: "",
    isPrimary: false,
    notes: "",
  });

  // Get all prospects to show companies
  const { data: prospects = [], isLoading: prospectsLoading } = trpc.prospects.list.useQuery();

  // Get contacts for selected company
  const { data: contacts = [], isLoading: contactsLoading, refetch } = trpc.contacts.list.useQuery(
    { companyId: selectedCompanyId! },
    { enabled: selectedCompanyId !== null }
  );

  const createContactMutation = trpc.contacts.create.useMutation({
    onSuccess: () => {
      toast.success("Contact added successfully");
      refetch();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast.error(`Failed to add contact: ${error.message}`);
    },
  });

  const updateContactMutation = trpc.contacts.update.useMutation({
    onSuccess: () => {
      toast.success("Contact updated successfully");
      refetch();
      setIsDialogOpen(false);
      setEditingContact(null);
      resetForm();
    },
    onError: (error: any) => {
      toast.error(`Failed to update contact: ${error.message}`);
    },
  });

  const deleteContactMutation = trpc.contacts.delete.useMutation({
    onSuccess: () => {
      toast.success("Contact deleted successfully");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Failed to delete contact: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      jobTitle: "",
      email: "",
      phone: "",
      mobile: "",
      isPrimary: false,
      notes: "",
    });
    setEditingContact(null);
  };

  const handleEdit = (contact: any) => {
    setEditingContact(contact.id);
    setFormData({
      firstName: contact.firstName || "",
      lastName: contact.lastName || "",
      jobTitle: contact.jobTitle || "",
      email: contact.email || "",
      phone: contact.phone || "",
      mobile: contact.mobile || "",
      isPrimary: contact.isPrimary || false,
      notes: contact.notes || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (contactId: number) => {
    if (confirm("Are you sure you want to delete this contact?")) {
      deleteContactMutation.mutate({ id: contactId });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCompanyId) {
      toast.error("Please select a company first");
      return;
    }
    if (!formData.firstName || !formData.lastName) {
      toast.error("First name and last name are required");
      return;
    }

    if (editingContact) {
      updateContactMutation.mutate({
        id: editingContact,
        ...formData,
      });
    } else {
      createContactMutation.mutate({
        companyId: selectedCompanyId,
        ...formData,
      });
    }
  };

  if (prospectsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading prospects...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Contacts</h1>
          <p className="text-muted-foreground mt-2">
            Manage contacts at your prospect companies
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            resetForm();
          }
        }}>
          <DialogTrigger asChild>
            <Button disabled={!selectedCompanyId}>
              <Plus className="mr-2 h-4 w-4" />
              Add Contact
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingContact ? "Edit Contact" : "Add New Contact"}</DialogTitle>
              <DialogDescription>
                {editingContact ? "Update contact information" : `Add a contact for ${prospects.find(p => p.company?.id === selectedCompanyId)?.company?.companyName}`}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="jobTitle">Job Title</Label>
                  <Input
                    id="jobTitle"
                    value={formData.jobTitle}
                    onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                    placeholder="e.g., Managing Director, Finance Director"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="contact@company.com"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="020 1234 5678"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mobile">Mobile</Label>
                    <Input
                      id="mobile"
                      value={formData.mobile}
                      onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                      placeholder="07123 456789"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isPrimary"
                    checked={formData.isPrimary}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, isPrimary: checked as boolean })
                    }
                  />
                  <Label htmlFor="isPrimary" className="cursor-pointer">
                    Primary Contact
                  </Label>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Additional notes about this contact..."
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={createContactMutation.isPending || updateContactMutation.isPending}>
                  {editingContact 
                    ? (updateContactMutation.isPending ? "Updating..." : "Update Contact")
                    : (createContactMutation.isPending ? "Adding..." : "Add Contact")
                  }
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Company List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Companies</CardTitle>
            <CardDescription>Select a company to view contacts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {prospects.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No prospects yet. Add companies from the Search page.
                </p>
              ) : (
                prospects.map((prospect) => (
                  <button
                    key={prospect.id}
                    onClick={() => setSelectedCompanyId(prospect.company?.id || null)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedCompanyId === prospect.company?.id
                        ? "bg-primary text-primary-foreground border-primary"
                        : "hover:bg-muted border-border"
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <Building2 className="h-4 w-4 mt-1 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">
                          {prospect.company?.companyName}
                        </p>
                        <p className="text-xs opacity-80 mt-1">
                          {prospect.company?.companyNumber}
                        </p>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Contacts List */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedCompanyId
                ? `Contacts at ${prospects.find(p => p.company?.id === selectedCompanyId)?.company?.companyName}`
                : "Select a Company"}
            </CardTitle>
            <CardDescription>
              {selectedCompanyId
                ? "View and manage contacts for this company"
                : "Choose a company from the list to view its contacts"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!selectedCompanyId ? (
              <div className="text-center py-12">
                <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  Select a company from the list to view contacts
                </p>
              </div>
            ) : contactsLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading contacts...</p>
              </div>
            ) : contacts.length === 0 ? (
              <div className="text-center py-12">
                <Mail className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground mb-4">No contacts yet</p>
                <Button onClick={() => setIsDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add First Contact
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">
                            {contact.firstName} {contact.lastName}
                          </h3>
                          {contact.isPrimary && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                              <Star className="h-3 w-3 fill-current" />
                              Primary
                            </span>
                          )}
                        </div>

                        {contact.jobTitle && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                            <Briefcase className="h-4 w-4" />
                            {contact.jobTitle}
                          </div>
                        )}

                        <div className="space-y-1">
                          {contact.email && (
                            <div className="flex items-center gap-2 text-sm">
                              <Mail className="h-4 w-4 text-muted-foreground" />
                              <a
                                href={`mailto:${contact.email}`}
                                className="text-primary hover:underline"
                              >
                                {contact.email}
                              </a>
                            </div>
                          )}
                          {contact.phone && (
                            <div className="flex items-center gap-2 text-sm">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <a
                                href={`tel:${contact.phone}`}
                                className="text-primary hover:underline"
                              >
                                {contact.phone}
                              </a>
                            </div>
                          )}
                          {contact.mobile && (
                            <div className="flex items-center gap-2 text-sm">
                              <Smartphone className="h-4 w-4 text-muted-foreground" />
                              <a
                                href={`tel:${contact.mobile}`}
                                className="text-primary hover:underline"
                              >
                                {contact.mobile}
                              </a>
                            </div>
                          )}
                        </div>

                        {contact.notes && (
                          <p className="text-sm text-muted-foreground mt-3 p-3 bg-muted rounded">
                            {contact.notes}
                          </p>
                        )}
                      </div>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(contact)}>
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDelete(contact.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

