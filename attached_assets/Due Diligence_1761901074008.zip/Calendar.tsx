import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Phone, 
  Mail, 
  Users, 
  StickyNote, 
  CheckSquare, 
  FileText, 
  Calendar as CalendarIcon,
  Clock,
  Building2
} from "lucide-react";
import { toast } from "sonner";

type ActivityType = "call" | "email" | "meeting" | "note" | "task" | "stage_change" | "document" | "other";

const ACTIVITY_TYPES: { value: ActivityType; label: string; icon: any; color: string }[] = [
  { value: "call", label: "Call", icon: Phone, color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
  { value: "email", label: "Email", icon: Mail, color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200" },
  { value: "meeting", label: "Meeting", icon: Users, color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
  { value: "note", label: "Note", icon: StickyNote, color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
  { value: "task", label: "Task", icon: CheckSquare, color: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200" },
  { value: "document", label: "Document", icon: FileText, color: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200" },
  { value: "other", label: "Other", icon: CalendarIcon, color: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200" },
];

export default function Calendar() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterType, setFilterType] = useState<ActivityType | "all">("all");
  const [formData, setFormData] = useState({
    type: "call" as ActivityType,
    prospectId: "",
    subject: "",
    description: "",
    dueDate: "",
  });

  const { data: activities = [], isLoading, refetch } = trpc.activities.list.useQuery();
  const { data: prospects = [] } = trpc.prospects.list.useQuery();

  const createActivityMutation = trpc.activities.create.useMutation({
    onSuccess: () => {
      toast.success("Activity added successfully");
      refetch();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`Failed to add activity: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      type: "call",
      prospectId: "",
      subject: "",
      description: "",
      dueDate: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject) {
      toast.error("Subject is required");
      return;
    }

    createActivityMutation.mutate({
      type: formData.type,
      prospectId: formData.prospectId ? parseInt(formData.prospectId) : undefined,
      subject: formData.subject,
      description: formData.description || undefined,
      dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
    });
  };

  const getActivityTypeInfo = (type: ActivityType) => {
    return ACTIVITY_TYPES.find(t => t.value === type) || ACTIVITY_TYPES[ACTIVITY_TYPES.length - 1];
  };

  const getProspectName = (prospectId: number | null) => {
    if (!prospectId) return null;
    const prospect = prospects.find(p => p.id === prospectId);
    return prospect?.company?.companyName;
  };

  const formatDate = (date: Date | null) => {
    if (!date) return null;
    return new Date(date).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const isOverdue = (dueDate: Date | null) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date();
  };

  const filteredActivities = filterType === "all" 
    ? activities 
    : activities.filter(a => a.type === filterType);

  const upcomingActivities = activities
    .filter(a => a.dueDate && !a.completedAt && new Date(a.dueDate) >= new Date())
    .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
    .slice(0, 5);

  const overdueActivities = activities
    .filter(a => a.dueDate && !a.completedAt && new Date(a.dueDate) < new Date())
    .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime());

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading activities...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Calendar & Activities</h1>
          <p className="text-muted-foreground mt-2">
            Track interactions and schedule follow-ups
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Activity
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Activity</DialogTitle>
              <DialogDescription>
                Record an interaction or schedule a follow-up
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Activity Type *</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value) => setFormData({ ...formData, type: value as ActivityType })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ACTIVITY_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="prospectId">Related Prospect</Label>
                    <Select
                      value={formData.prospectId}
                      onValueChange={(value) => setFormData({ ...formData, prospectId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select prospect (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">None</SelectItem>
                        {prospects.map((prospect) => (
                          <SelectItem key={prospect.id} value={prospect.id.toString()}>
                            {prospect.company?.companyName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject *</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g., Follow-up call with director"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Additional details..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Date / Time</Label>
                  <Input
                    id="dueDate"
                    type="datetime-local"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={createActivityMutation.isPending}>
                  {createActivityMutation.isPending ? "Adding..." : "Add Activity"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Activities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activities.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Upcoming
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {upcomingActivities.length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Overdue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {overdueActivities.length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming & Overdue */}
        <div className="lg:col-span-1 space-y-6">
          {/* Overdue Activities */}
          {overdueActivities.length > 0 && (
            <Card className="border-red-200 dark:border-red-900">
              <CardHeader>
                <CardTitle className="text-red-600 dark:text-red-400">Overdue</CardTitle>
                <CardDescription>Activities that need attention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {overdueActivities.map((activity) => {
                    const typeInfo = getActivityTypeInfo(activity.type);
                    const Icon = typeInfo.icon;
                    return (
                      <div key={activity.id} className="p-3 border border-red-200 dark:border-red-900 rounded-lg bg-red-50 dark:bg-red-950/20">
                        <div className="flex items-start gap-2 mb-2">
                          <Icon className="h-4 w-4 text-red-600 dark:text-red-400 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm">{activity.subject}</p>
                            {activity.prospectId && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {getProspectName(activity.prospectId)}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
                          <Clock className="h-3 w-3" />
                          {formatDate(activity.dueDate)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upcoming Activities */}
          {upcomingActivities.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Upcoming</CardTitle>
                <CardDescription>Next 5 scheduled activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingActivities.map((activity) => {
                    const typeInfo = getActivityTypeInfo(activity.type);
                    const Icon = typeInfo.icon;
                    return (
                      <div key={activity.id} className="p-3 border rounded-lg">
                        <div className="flex items-start gap-2 mb-2">
                          <Icon className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm">{activity.subject}</p>
                            {activity.prospectId && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {getProspectName(activity.prospectId)}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {formatDate(activity.dueDate)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* All Activities */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>All Activities</CardTitle>
                <CardDescription>Complete activity history</CardDescription>
              </div>
              <Select value={filterType} onValueChange={(value) => setFilterType(value as ActivityType | "all")}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {ACTIVITY_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {filteredActivities.length === 0 ? (
              <div className="text-center py-12">
                <CalendarIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground mb-4">No activities yet</p>
                <Button onClick={() => setIsDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add First Activity
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredActivities.map((activity) => {
                  const typeInfo = getActivityTypeInfo(activity.type);
                  const Icon = typeInfo.icon;
                  const prospectName = getProspectName(activity.prospectId);
                  const overdue = isOverdue(activity.dueDate);

                  return (
                    <div
                      key={activity.id}
                      className={`border rounded-lg p-4 ${
                        overdue && !activity.completedAt
                          ? "border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/20"
                          : activity.completedAt
                          ? "opacity-60"
                          : ""
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded ${typeInfo.color}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h3 className="font-semibold">{activity.subject}</h3>
                              {prospectName && (
                                <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                                  <Building2 className="h-3 w-3" />
                                  {prospectName}
                                </div>
                              )}
                            </div>
                            <Badge variant="outline" className={typeInfo.color}>
                              {typeInfo.label}
                            </Badge>
                          </div>

                          {activity.description && (
                            <p className="text-sm text-muted-foreground mb-2">
                              {activity.description}
                            </p>
                          )}

                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            {activity.dueDate && (
                              <div className={`flex items-center gap-1 ${overdue && !activity.completedAt ? "text-red-600 dark:text-red-400 font-medium" : ""}`}>
                                <Clock className="h-3 w-3" />
                                {formatDate(activity.dueDate)}
                                {overdue && !activity.completedAt && " (Overdue)"}
                              </div>
                            )}
                            {activity.completedAt && (
                              <Badge variant="secondary" className="text-xs">
                                Completed
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

