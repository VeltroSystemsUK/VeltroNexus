import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, TrendingUp, AlertCircle, CheckCircle, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";

export default function FinancialRatios() {
  const [currentAssets, setCurrentAssets] = useState("");
  const [inventory, setInventory] = useState("");
  const [currentLiabilities, setCurrentLiabilities] = useState("");
  const [netIncome, setNetIncome] = useState("");
  const [totalAssets, setTotalAssets] = useState("");
  const [totalDebt, setTotalDebt] = useState("");
  const [netWorth, setNetWorth] = useState("");
  
  const [results, setResults] = useState<{
    acidTestRatio: number;
    returnOnAssets: number;
    debtToNetWorth: number;
  } | null>(null);

  const calculateRatios = () => {
    const ca = parseFloat(currentAssets) || 0;
    const inv = parseFloat(inventory) || 0;
    const cl = parseFloat(currentLiabilities) || 0;
    const ni = parseFloat(netIncome) || 0;
    const ta = parseFloat(totalAssets) || 0;
    const td = parseFloat(totalDebt) || 0;
    const nw = parseFloat(netWorth) || 0;

    // Acid Test Ratio = (Current Assets - Inventory) / Current Liabilities
    const acidTestRatio = cl > 0 ? (ca - inv) / cl : 0;

    // Return on Assets = Net Income / Total Assets × 100
    const returnOnAssets = ta > 0 ? (ni / ta) * 100 : 0;

    // Debt to Net Worth = Total Debt / Net Worth
    const debtToNetWorth = nw > 0 ? td / nw : 0;

    setResults({
      acidTestRatio,
      returnOnAssets,
      debtToNetWorth
    });
  };

  const getAcidTestRating = (ratio: number) => {
    if (ratio >= 1.0) return { label: "Good", color: "text-green-600", bg: "bg-green-50" };
    if (ratio >= 0.5) return { label: "Acceptable", color: "text-yellow-600", bg: "bg-yellow-50" };
    return { label: "Weak", color: "text-red-600", bg: "bg-red-50" };
  };

  const getROARating = (roa: number) => {
    if (roa >= 10) return { label: "Excellent", color: "text-green-600", bg: "bg-green-50" };
    if (roa >= 5) return { label: "Good", color: "text-blue-600", bg: "bg-blue-50" };
    if (roa >= 0) return { label: "Fair", color: "text-yellow-600", bg: "bg-yellow-50" };
    return { label: "Poor", color: "text-red-600", bg: "bg-red-50" };
  };

  const getDebtToNetWorthRating = (ratio: number) => {
    if (ratio <= 1.0) return { label: "Good", color: "text-green-600", bg: "bg-green-50" };
    if (ratio <= 2.0) return { label: "Acceptable", color: "text-yellow-600", bg: "bg-yellow-50" };
    return { label: "High Risk", color: "text-red-600", bg: "bg-red-50" };
  };

  const exportAsText = () => {
    if (!results) return;
    const acidRating = getAcidTestRating(results.acidTestRatio);
    const roaRating = getROARating(results.returnOnAssets);
    const debtRating = getDebtToNetWorthRating(results.debtToNetWorth);
    
    const content = `FINANCIAL RATIOS ANALYSIS\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nINPUT DATA\n${'-'.repeat(50)}\nCurrent Assets: £${parseFloat(currentAssets).toLocaleString()}\nInventory: £${parseFloat(inventory).toLocaleString()}\nCurrent Liabilities: £${parseFloat(currentLiabilities).toLocaleString()}\nNet Income: £${parseFloat(netIncome).toLocaleString()}\nTotal Assets: £${parseFloat(totalAssets).toLocaleString()}\nTotal Debt: £${parseFloat(totalDebt).toLocaleString()}\nNet Worth: £${parseFloat(netWorth).toLocaleString()}\n\nCALCULATED RATIOS\n${'-'.repeat(50)}\n\n1. ACID TEST RATIO (Quick Ratio)\n   Formula: (Current Assets - Inventory) / Current Liabilities\n   Result: ${results.acidTestRatio.toFixed(2)}\n   Rating: ${acidRating.label}\n   Interpretation: Measures immediate liquidity\n\n2. RETURN ON ASSETS (ROA)\n   Formula: Net Income / Total Assets × 100%\n   Result: ${results.returnOnAssets.toFixed(2)}%\n   Rating: ${roaRating.label}\n   Interpretation: Measures profitability efficiency\n\n3. DEBT TO NET WORTH\n   Formula: Total Debt / Net Worth\n   Result: ${results.debtToNetWorth.toFixed(2)}\n   Rating: ${debtRating.label}\n   Interpretation: Measures financial leverage\n\nBENCHMARKS\n${'-'.repeat(50)}\nAcid Test Ratio:\n  • ≥ 1.0: Good liquidity\n  • 0.5-1.0: Acceptable\n  • < 0.5: Weak liquidity\n\nReturn on Assets:\n  • ≥ 10%: Excellent\n  • 5-10%: Good\n  • 0-5%: Fair\n  • < 0%: Poor\n\nDebt to Net Worth:\n  • ≤ 1.0: Good leverage\n  • 1.0-2.0: Acceptable\n  • > 2.0: High risk\n\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `Financial-Ratios-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    if (!results) return;
    const acidRating = getAcidTestRating(results.acidTestRatio);
    const roaRating = getROARating(results.returnOnAssets);
    const debtRating = getDebtToNetWorthRating(results.debtToNetWorth);
    
    const content = `<div class="section">\n  <h1>Financial Ratios Analysis</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Input Data</h2>\n  <table>\n    <tr>\n      <th>Item</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Current Assets</td>\n      <td>£${parseFloat(currentAssets).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Inventory</td>\n      <td>£${parseFloat(inventory).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Current Liabilities</td>\n      <td>£${parseFloat(currentLiabilities).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Net Income</td>\n      <td>£${parseFloat(netIncome).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Total Assets</td>\n      <td>£${parseFloat(totalAssets).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Total Debt</td>\n      <td>£${parseFloat(totalDebt).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Net Worth</td>\n      <td>£${parseFloat(netWorth).toLocaleString()}</td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Calculated Ratios</h2>\n  \n  <div class="result">\n    <h3>1. Acid Test Ratio (Quick Ratio)</h3>\n    <p><strong>Formula:</strong> (Current Assets - Inventory) / Current Liabilities</p>\n    <p><strong>Result:</strong> <span class="highlight">${results.acidTestRatio.toFixed(2)}</span></p>\n    <p><strong>Rating:</strong> <span class="${acidRating.color.replace('text-', '')}">${acidRating.label}</span></p>\n    <p><em>Measures immediate liquidity without relying on inventory sales</em></p>\n  </div>\n  \n  <div class="result">\n    <h3>2. Return on Assets (ROA)</h3>\n    <p><strong>Formula:</strong> Net Income / Total Assets × 100%</p>\n    <p><strong>Result:</strong> <span class="highlight">${results.returnOnAssets.toFixed(2)}%</span></p>\n    <p><strong>Rating:</strong> <span class="${roaRating.color.replace('text-', '')}">${roaRating.label}</span></p>\n    <p><em>Measures how efficiently assets generate profit</em></p>\n  </div>\n  \n  <div class="result">\n    <h3>3. Debt to Net Worth</h3>\n    <p><strong>Formula:</strong> Total Debt / Net Worth</p>\n    <p><strong>Result:</strong> <span class="highlight">${results.debtToNetWorth.toFixed(2)}</span></p>\n    <p><strong>Rating:</strong> <span class="${debtRating.color.replace('text-', '')}">${debtRating.label}</span></p>\n    <p><em>Measures financial leverage and risk exposure</em></p>\n  </div>\n</div>\n\n<div class="section">\n  <h2>Benchmarks</h2>\n  <h3>Acid Test Ratio</h3>\n  <ul>\n    <li>≥ 1.0: Good liquidity</li>\n    <li>0.5-1.0: Acceptable</li>\n    <li>< 0.5: Weak liquidity</li>\n  </ul>\n  \n  <h3>Return on Assets</h3>\n  <ul>\n    <li>≥ 10%: Excellent</li>\n    <li>5-10%: Good</li>\n    <li>0-5%: Fair</li>\n    <li>< 0%: Poor</li>\n  </ul>\n  \n  <h3>Debt to Net Worth</h3>\n  <ul>\n    <li>≤ 1.0: Good leverage</li>\n    <li>1.0-2.0: Acceptable</li>\n    <li>> 2.0: High risk</li>\n  </ul>\n</div>`;
    downloadAsHTML(content, `Financial-Ratios-${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-5xl">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          
          <div className="flex items-center gap-4 mb-4">
            <img src="/first-enterprise-logo.png" alt="First Enterprise" className="h-16" />
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">Financial Ratios Calculator</h1>
              <p className="text-muted-foreground text-base">
                Calculate key financial health indicators
              </p>
            </div>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Acid Test Ratio Inputs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Acid Test Ratio (Quick Ratio)</CardTitle>
              <CardDescription>Measures ability to pay short-term obligations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="currentAssets">Current Assets (£)</Label>
                <Input
                  id="currentAssets"
                  type="number"
                  placeholder="e.g., 150000"
                  value={currentAssets}
                  onChange={(e) => setCurrentAssets(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="inventory">Inventory (£)</Label>
                <Input
                  id="inventory"
                  type="number"
                  placeholder="e.g., 30000"
                  value={inventory}
                  onChange={(e) => setInventory(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="currentLiabilities">Current Liabilities (£)</Label>
                <Input
                  id="currentLiabilities"
                  type="number"
                  placeholder="e.g., 80000"
                  value={currentLiabilities}
                  onChange={(e) => setCurrentLiabilities(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Return on Assets Inputs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Return on Assets (ROA)</CardTitle>
              <CardDescription>Measures profitability relative to total assets</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="netIncome">Net Income (£)</Label>
                <Input
                  id="netIncome"
                  type="number"
                  placeholder="e.g., 45000"
                  value={netIncome}
                  onChange={(e) => setNetIncome(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="totalAssets">Total Assets (£)</Label>
                <Input
                  id="totalAssets"
                  type="number"
                  placeholder="e.g., 500000"
                  value={totalAssets}
                  onChange={(e) => setTotalAssets(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Debt to Net Worth Inputs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Debt to Net Worth</CardTitle>
              <CardDescription>Measures financial leverage and solvency</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="totalDebt">Total Debt (£)</Label>
                <Input
                  id="totalDebt"
                  type="number"
                  placeholder="e.g., 200000"
                  value={totalDebt}
                  onChange={(e) => setTotalDebt(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="netWorth">Net Worth / Equity (£)</Label>
                <Input
                  id="netWorth"
                  type="number"
                  placeholder="e.g., 300000"
                  value={netWorth}
                  onChange={(e) => setNetWorth(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6">
          <Button onClick={calculateRatios} size="lg" className="w-full">
            <TrendingUp className="h-5 w-5 mr-2" />
            Calculate Financial Ratios
          </Button>
        </div>

        {results && (
          <div className="mt-6 space-y-4">
            <h2 className="text-2xl font-bold">Results</h2>

            {/* Acid Test Ratio Result */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Acid Test Ratio</span>
                  <span className={`text-2xl ${getAcidTestRating(results.acidTestRatio).color}`}>
                    {results.acidTestRatio.toFixed(2)}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Alert className={getAcidTestRating(results.acidTestRatio).bg}>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>{getAcidTestRating(results.acidTestRatio).label}:</strong> Formula: (Current Assets - Inventory) / Current Liabilities
                    <br />
                    {results.acidTestRatio >= 1.0 
                      ? "Company can cover short-term obligations without selling inventory."
                      : results.acidTestRatio >= 0.5
                      ? "Company has moderate liquidity. Monitor cash flow closely."
                      : "Company may struggle to meet short-term obligations."}
                  </AlertDescription>
                </Alert>
                <div className="mt-4 text-sm text-muted-foreground">
                  <p><strong>Interpretation:</strong></p>
                  <ul className="list-disc list-inside space-y-1 mt-2">
                    <li>≥ 1.0: Good liquidity position</li>
                    <li>0.5 - 1.0: Acceptable, but monitor closely</li>
                    <li>&lt; 0.5: Weak liquidity, potential cash flow issues</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Return on Assets Result */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Return on Assets (ROA)</span>
                  <span className={`text-2xl ${getROARating(results.returnOnAssets).color}`}>
                    {results.returnOnAssets.toFixed(2)}%
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Alert className={getROARating(results.returnOnAssets).bg}>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>{getROARating(results.returnOnAssets).label}:</strong> Formula: (Net Income / Total Assets) × 100
                    <br />
                    {results.returnOnAssets >= 10
                      ? "Excellent asset utilization and profitability."
                      : results.returnOnAssets >= 5
                      ? "Good profitability relative to assets employed."
                      : results.returnOnAssets >= 0
                      ? "Fair performance. Consider improving asset efficiency."
                      : "Negative returns indicate losses."}
                  </AlertDescription>
                </Alert>
                <div className="mt-4 text-sm text-muted-foreground">
                  <p><strong>Interpretation:</strong></p>
                  <ul className="list-disc list-inside space-y-1 mt-2">
                    <li>≥ 10%: Excellent asset efficiency</li>
                    <li>5% - 10%: Good performance</li>
                    <li>0% - 5%: Fair, room for improvement</li>
                    <li>&lt; 0%: Operating at a loss</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Debt to Net Worth Result */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Debt to Net Worth</span>
                  <span className={`text-2xl ${getDebtToNetWorthRating(results.debtToNetWorth).color}`}>
                    {results.debtToNetWorth.toFixed(2)}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Alert className={getDebtToNetWorthRating(results.debtToNetWorth).bg}>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>{getDebtToNetWorthRating(results.debtToNetWorth).label}:</strong> Formula: Total Debt / Net Worth
                    <br />
                    {results.debtToNetWorth <= 1.0
                      ? "Conservative leverage. Equity exceeds debt."
                      : results.debtToNetWorth <= 2.0
                      ? "Moderate leverage. Acceptable for most businesses."
                      : "High leverage. Significant financial risk."}
                  </AlertDescription>
                </Alert>
                <div className="mt-4 text-sm text-muted-foreground">
                  <p><strong>Interpretation:</strong></p>
                  <ul className="list-disc list-inside space-y-1 mt-2">
                    <li>≤ 1.0: Good - More equity than debt</li>
                    <li>1.0 - 2.0: Acceptable - Moderate leverage</li>
                    <li>&gt; 2.0: High Risk - Debt exceeds equity significantly</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Export Section */}
            <Card>
              <CardHeader>
                <CardTitle>Export Results</CardTitle>
                <CardDescription>Download analysis results for your records</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as Text
                  </Button>
                  <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as HTML
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

