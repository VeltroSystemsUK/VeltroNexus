/**
 * URL Parameter Handler for Deep Link Integration
 * Extracts company/prospect data from URL parameters passed from LoanFlow
 */

export interface CompanyData {
  companyId?: string;
  companyName?: string;
  companyNumber?: string;
  contactName?: string;
  contactEmail?: string;
  loanAmount?: string;
  loanPurpose?: string;
  source?: string; // e.g., 'loanflow'
}

/**
 * Extract company data from URL parameters
 */
export function getCompanyDataFromURL(): CompanyData | null {
  if (typeof window === 'undefined') return null;
  
  const urlParams = new URLSearchParams(window.location.search);
  
  // Check if any company parameters exist
  const hasParams = urlParams.has('companyId') || 
                    urlParams.has('companyName') || 
                    urlParams.has('source');
  
  if (!hasParams) return null;
  
  return {
    companyId: urlParams.get('companyId') || undefined,
    companyName: urlParams.get('companyName') || undefined,
    companyNumber: urlParams.get('companyNumber') || undefined,
    contactName: urlParams.get('contactName') || undefined,
    contactEmail: urlParams.get('contactEmail') || undefined,
    loanAmount: urlParams.get('loanAmount') || undefined,
    loanPurpose: urlParams.get('loanPurpose') || undefined,
    source: urlParams.get('source') || undefined,
  };
}

/**
 * Store company data in sessionStorage for use across pages
 */
export function storeCompanyData(data: CompanyData): void {
  if (typeof window === 'undefined') return;
  sessionStorage.setItem('loanflow_company_data', JSON.stringify(data));
}

/**
 * Retrieve stored company data from sessionStorage
 */
export function getStoredCompanyData(): CompanyData | null {
  if (typeof window === 'undefined') return null;
  
  const stored = sessionStorage.getItem('loanflow_company_data');
  if (!stored) return null;
  
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

/**
 * Clear stored company data
 */
export function clearStoredCompanyData(): void {
  if (typeof window === 'undefined') return;
  sessionStorage.removeItem('loanflow_company_data');
}

/**
 * Generate DueDiligence URL with company parameters
 * This function is for LoanFlow to use when creating deep links
 */
export function generateDueDiligenceURL(
  baseUrl: string,
  companyData: CompanyData
): string {
  const params = new URLSearchParams();
  
  if (companyData.companyId) params.set('companyId', companyData.companyId);
  if (companyData.companyName) params.set('companyName', companyData.companyName);
  if (companyData.companyNumber) params.set('companyNumber', companyData.companyNumber);
  if (companyData.contactName) params.set('contactName', companyData.contactName);
  if (companyData.contactEmail) params.set('contactEmail', companyData.contactEmail);
  if (companyData.loanAmount) params.set('loanAmount', companyData.loanAmount);
  if (companyData.loanPurpose) params.set('loanPurpose', companyData.loanPurpose);
  
  // Always set source to identify traffic from LoanFlow
  params.set('source', 'loanflow');
  
  return `${baseUrl}?${params.toString()}`;
}

