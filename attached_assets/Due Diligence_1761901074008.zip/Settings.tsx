import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Palette, Globe, Bell, Building2, Save } from "lucide-react";
import { toast } from "sonner";

const THEME_OPTIONS = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "system", label: "System" },
];

const COLOR_OPTIONS = [
  { value: "blue", label: "Blue", color: "bg-blue-500" },
  { value: "green", label: "Green", color: "bg-green-500" },
  { value: "purple", label: "Purple", color: "bg-purple-500" },
  { value: "red", label: "Red", color: "bg-red-500" },
  { value: "orange", label: "Orange", color: "bg-orange-500" },
  { value: "pink", label: "Pink", color: "bg-pink-500" },
  { value: "slate", label: "Slate", color: "bg-slate-500" },
];

const CURRENCY_OPTIONS = [
  { value: "GBP", label: "British Pound (£)", symbol: "£" },
  { value: "USD", label: "US Dollar ($)", symbol: "$" },
  { value: "EUR", label: "Euro (€)", symbol: "€" },
  { value: "CAD", label: "Canadian Dollar ($)", symbol: "$" },
  { value: "AUD", label: "Australian Dollar ($)", symbol: "$" },
];

const DATE_FORMAT_OPTIONS = [
  { value: "DD/MM/YYYY", label: "DD/MM/YYYY (31/12/2024)" },
  { value: "MM/DD/YYYY", label: "MM/DD/YYYY (12/31/2024)" },
  { value: "YYYY-MM-DD", label: "YYYY-MM-DD (2024-12-31)" },
];

export default function Settings() {
  const { data: settings, isLoading, refetch } = trpc.userSettings.get.useQuery();
  const [isSaving, setIsSaving] = useState(false);

  // Appearance settings
  const [theme, setTheme] = useState<"light" | "dark" | "system">("system");
  const [primaryColor, setPrimaryColor] = useState("blue");
  const [accentColor, setAccentColor] = useState("slate");

  // Regional settings
  const [currency, setCurrency] = useState("GBP");
  const [currencySymbol, setCurrencySymbol] = useState("£");
  const [dateFormat, setDateFormat] = useState("DD/MM/YYYY");
  const [numberFormat, setNumberFormat] = useState("en-GB");

  // Application settings
  const [companyName, setCompanyName] = useState("");
  const [defaultLoanTerm, setDefaultLoanTerm] = useState(60);
  const [defaultInterestRate, setDefaultInterestRate] = useState(17.0);

  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [toastNotifications, setToastNotifications] = useState(true);

  useEffect(() => {
    if (settings) {
      setTheme(settings.theme || "system");
      setPrimaryColor(settings.primaryColor || "blue");
      setAccentColor(settings.accentColor || "slate");
      setCurrency(settings.currency || "GBP");
      setCurrencySymbol(settings.currencySymbol || "£");
      setDateFormat(settings.dateFormat || "DD/MM/YYYY");
      setNumberFormat(settings.numberFormat || "en-GB");
      setCompanyName(settings.companyName || "");
      setDefaultLoanTerm(settings.defaultLoanTerm || 60);
      setDefaultInterestRate((settings.defaultInterestRate || 1700) / 100);
      setEmailNotifications(settings.emailNotifications ?? true);
      setToastNotifications(settings.toastNotifications ?? true);
    }
  }, [settings]);

  const updateSettingsMutation = trpc.userSettings.update.useMutation({
    onSuccess: () => {
      toast.success("Settings saved successfully");
      setIsSaving(false);
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to save settings: ${error.message}`);
      setIsSaving(false);
    },
  });

  const handleSave = () => {
    setIsSaving(true);
    updateSettingsMutation.mutate({
      theme,
      primaryColor,
      accentColor,
      currency,
      currencySymbol,
      dateFormat,
      numberFormat,
      companyName,
      defaultLoanTerm,
      defaultInterestRate: Math.round(defaultInterestRate * 100),
      emailNotifications,
      toastNotifications,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 max-w-5xl">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <SettingsIcon className="h-8 w-8" />
            Settings
          </h1>
          <p className="text-muted-foreground mt-2">
            Customize your application preferences
          </p>
        </div>
        <Button onClick={handleSave} disabled={isSaving}>
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Saving..." : "Save All Changes"}
        </Button>
      </div>

      <Tabs defaultValue="appearance" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appearance">
            <Palette className="h-4 w-4 mr-2" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="regional">
            <Globe className="h-4 w-4 mr-2" />
            Regional
          </TabsTrigger>
          <TabsTrigger value="application">
            <Building2 className="h-4 w-4 mr-2" />
            Application
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
        </TabsList>

        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Theme</CardTitle>
              <CardDescription>
                Choose your preferred color theme
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="theme">Theme Mode</Label>
                <Select value={theme} onValueChange={(value: any) => setTheme(value)}>
                  <SelectTrigger id="theme">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {THEME_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Colors</CardTitle>
              <CardDescription>
                Customize the color scheme of your application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Primary Color</Label>
                <div className="grid grid-cols-4 gap-3">
                  {COLOR_OPTIONS.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setPrimaryColor(color.value)}
                      className={`flex items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                        primaryColor === color.value
                          ? "border-primary bg-primary/5"
                          : "border-transparent hover:border-muted-foreground/20"
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full ${color.color}`} />
                      <span className="text-sm font-medium">{color.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Accent Color</Label>
                <div className="grid grid-cols-4 gap-3">
                  {COLOR_OPTIONS.map((color) => (
                    <button
                      key={color.value}
                      onClick={() => setAccentColor(color.value)}
                      className={`flex items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                        accentColor === color.value
                          ? "border-primary bg-primary/5"
                          : "border-transparent hover:border-muted-foreground/20"
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full ${color.color}`} />
                      <span className="text-sm font-medium">{color.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Regional Tab */}
        <TabsContent value="regional" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Currency</CardTitle>
              <CardDescription>
                Set your preferred currency for financial displays
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currency">Currency</Label>
                <Select
                  value={currency}
                  onValueChange={(value) => {
                    setCurrency(value);
                    const selected = CURRENCY_OPTIONS.find((c) => c.value === value);
                    if (selected) setCurrencySymbol(selected.symbol);
                  }}
                >
                  <SelectTrigger id="currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCY_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Date & Number Formats</CardTitle>
              <CardDescription>
                Customize how dates and numbers are displayed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dateFormat">Date Format</Label>
                <Select value={dateFormat} onValueChange={setDateFormat}>
                  <SelectTrigger id="dateFormat">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DATE_FORMAT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="numberFormat">Number Format</Label>
                <Select value={numberFormat} onValueChange={setNumberFormat}>
                  <SelectTrigger id="numberFormat">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en-GB">English (UK) - 1,234.56</SelectItem>
                    <SelectItem value="en-US">English (US) - 1,234.56</SelectItem>
                    <SelectItem value="de-DE">German - 1.234,56</SelectItem>
                    <SelectItem value="fr-FR">French - 1 234,56</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Application Tab */}
        <TabsContent value="application" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>
                Set your company details for reports and documents
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name</Label>
                <Input
                  id="companyName"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Your Company Name"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Default Loan Settings</CardTitle>
              <CardDescription>
                Set default values for new loan calculations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="defaultLoanTerm">Default Loan Term (months)</Label>
                <Input
                  id="defaultLoanTerm"
                  type="number"
                  value={defaultLoanTerm}
                  onChange={(e) => setDefaultLoanTerm(parseInt(e.target.value) || 60)}
                  min={1}
                  max={360}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultInterestRate">Default Interest Rate (%)</Label>
                <Input
                  id="defaultInterestRate"
                  type="number"
                  step="0.01"
                  value={defaultInterestRate}
                  onChange={(e) => setDefaultInterestRate(parseFloat(e.target.value) || 17.0)}
                  min={0}
                  max={100}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>
                Manage how you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotifications">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive updates and alerts via email
                  </p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={emailNotifications}
                  onCheckedChange={setEmailNotifications}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="toastNotifications">Toast Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Show popup notifications in the app
                  </p>
                </div>
                <Switch
                  id="toastNotifications"
                  checked={toastNotifications}
                  onCheckedChange={setToastNotifications}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 flex justify-end">
        <Button onClick={handleSave} disabled={isSaving} size="lg">
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Saving..." : "Save All Changes"}
        </Button>
      </div>
    </div>
  );
}

