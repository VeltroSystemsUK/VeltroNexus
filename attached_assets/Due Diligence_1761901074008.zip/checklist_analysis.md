# Checklist Analysis

## Current Checklist (35 items)
Organized into 10 sections with focus on commercial lending

## New Checklist (30 items)
More detailed MEIF/RGF focused checklist

## Mapping & Deduplication

### Items to Keep from Current (Already covered or more general):
1. SOAR linked. Openbanking, Soft Credit Search & KYC - KEEP (more modern)
2. Applicant(s) aged 18+, business domiciled in England - MERGE with new #2
3. Loan < 90% of total project cost, contribution > 10% - UPDATE with new #4
4. Purpose not excluded - KEEP (covered by new #5)
5. Full loan application and Adviser Summary completed - KEEP (new #6, #27)
6. 6 months bank statements reviewed - KEEP (new #23)
7. Photographic ID and proof of address - KEEP (new #24, #26)
8. Credit search (3 years) authorised and reviewed - KEEP (new #7)
9. Adverse data or voter-roll absence commented - KEEP (new #8)
10. Financial Accounts Reviewed - KEEP (new #21)
11. Management accounts (YTD) reviewed - KEEP (new #21)
12. Cashflow forecast includes VAT, PAYE, CT, and loan repayments - KEEP (new #20)
13-20. Various financial/capacity items - KEEP (unique to current)
21-35. Various structure/security/compliance items - KEEP (unique to current)

### New Items to ADD:
- Evidence of bank decline held (new #9)
- Customer Charter given out (new #11)
- Client Perception form given out (new #12)
- Client details entered on database (new #13)
- Client Contact Form signed (new #14)
- Action plan completed (new #15)
- Company search from Companies House (new #16)
- Business plan (new #17)
- Personal Statement of Assets & Liabilities (new #18)
- CV for each director (new #19)
- Business Liabilities Form (new #20)
- Tax returns if no accounts (new #22)
- Non-EU passport leave to remain check (new #25)
- Location Questionnaire and RLS Assessment (new #27)
- Eligibility confirmed (new #28)
- Secured lending equity check (new #29)
- Due diligence undertaken (new #30)

### Items to UPDATE:
- #2: Add MEIF LEP area requirement
- #3: Update to 15% minimum contribution for existing businesses
- #21: Update fund types to include RLS

## Recommendation:
Merge both lists into comprehensive checklist organized by workflow stages.

