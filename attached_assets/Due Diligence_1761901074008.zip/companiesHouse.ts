/**
 * Companies House API Integration
 * Documentation: https://developer-specs.company-information.service.gov.uk/
 */

const COMPANIES_HOUSE_API_BASE = "https://api.company-information.service.gov.uk";

interface CompaniesHouseSearchResult {
  items: CompanySearchItem[];
  total_results: number;
  items_per_page: number;
}

interface CompanySearchItem {
  company_number: string;
  title: string;
  company_status: string;
  company_type: string;
  date_of_creation?: string;
  address_snippet?: string;
  address?: {
    address_line_1?: string;
    address_line_2?: string;
    locality?: string;
    region?: string;
    postal_code?: string;
    country?: string;
  };
  sic_codes?: string[];
}

interface CompanyProfile {
  company_number: string;
  company_name: string;
  company_status: string;
  company_type: string;
  date_of_creation?: string;
  registered_office_address?: {
    address_line_1?: string;
    address_line_2?: string;
    locality?: string;
    region?: string;
    postal_code?: string;
    country?: string;
  };
  sic_codes?: string[];
  accounts?: any;
  confirmation_statement?: any;
}

/**
 * Search for companies by name or number
 */
export async function searchCompanies(query: string, itemsPerPage: number = 20): Promise<CompaniesHouseSearchResult> {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const url = new URL(`${COMPANIES_HOUSE_API_BASE}/search/companies`);
  url.searchParams.set("q", query);
  url.searchParams.set("items_per_page", itemsPerPage.toString());

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");
  
  const response = await fetch(url.toString(), {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get detailed company profile by company number
 */
export async function getCompanyProfile(companyNumber: string): Promise<CompanyProfile> {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get company officers (directors, secretaries, etc.)
 */
export async function getCompanyOfficers(companyNumber: string) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}/officers`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get persons with significant control (PSC)
 */
export async function getCompanyPSC(companyNumber: string) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}/persons-with-significant-control`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get company charges (mortgages and charges)
 */
export async function getCompanyCharges(companyNumber: string) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}/charges`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get company insolvency information
 */
export async function getCompanyInsolvency(companyNumber: string) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}/insolvency`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    // 404 is expected for companies with no insolvency history
    if (response.status === 404) {
      return null;
    }
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

/**
 * Get company filing history
 */
export async function getCompanyFilingHistory(companyNumber: string) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY?.trim();
  
  if (!apiKey) {
    throw new Error("COMPANIES_HOUSE_API_KEY not configured");
  }

  const authString = `${apiKey}:`;
  const base64Auth = Buffer.from(authString).toString("base64");

  const url = `${COMPANIES_HOUSE_API_BASE}/company/${companyNumber}/filing-history`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `Basic ${base64Auth}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Companies House API error: ${response.status} - ${errorText}`);
  }

  return await response.json();
}

