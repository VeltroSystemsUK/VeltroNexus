import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";

// LoanFlow pages
import CompanySearch from "./pages/CompanySearch";
import CompanyDetail from "./pages/CompanyDetail";
import MyProspects from "./pages/MyProspects";
import Contacts from "./pages/Contacts";
import Pipeline from "./pages/Pipeline";
import Calendar from "./pages/Calendar";
import Targets from "./pages/Targets";
import ProspectDetail from "./pages/ProspectDetail";
import Settings from "./pages/Settings";

// DueDiligence pages
import Checklist from "./pages/Checklist";
import DSCRCalculator from "./pages/DSCRCalculator";
import LoanCalculator from "./pages/LoanCalculator";
import AffordabilityEstimator from "./pages/AffordabilityEstimator";
import FinancialRatios from "./pages/FinancialRatios";
import CharacterAssessor from "./pages/CharacterAssessor";
import LoanPurpose from "./pages/LoanPurpose";
import Help from "./pages/Help";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        {/* LoanFlow Routes */}
        <Route path={"/"} component={CompanySearch} />
        <Route path={"/company/:companyNumber"} component={CompanyDetail} />
        <Route path={"/prospects"} component={MyProspects} />
        <Route path={"/prospect/:id"} component={ProspectDetail} />
        <Route path={"/contacts"} component={Contacts} />
        <Route path={"/pipeline"} component={Pipeline} />
        <Route path={"/calendar"} component={Calendar} />
        <Route path={"/targets"} component={Targets} />
        <Route path={"/settings"} component={Settings} />
        
        {/* DueDiligence Routes */}
        <Route path={"/due-diligence"} component={Checklist} />
        <Route path={"/due-diligence/checklist"} component={Checklist} />
        <Route path={"/due-diligence/dscr-calculator"} component={DSCRCalculator} />
        <Route path={"/due-diligence/loan-calculator"} component={LoanCalculator} />
        <Route path={"/due-diligence/affordability"} component={AffordabilityEstimator} />
        <Route path={"/due-diligence/financial-ratios"} component={FinancialRatios} />
        <Route path={"/due-diligence/character-assessor"} component={CharacterAssessor} />
        <Route path={"/due-diligence/loan-purpose"} component={LoanPurpose} />
        
        {/* Help */}
        <Route path={"/help"} component={Help} />
        
        {/* 404 */}
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

