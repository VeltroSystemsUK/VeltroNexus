import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect, useState } from "react";
import { getCompanyDataFromURL, storeCompanyData, getStoredCompanyData, type CompanyData } from "@/lib/urlParams";
import { Button } from "@/components/ui/button";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Link } from "wouter";
import { FileCheck, ArrowRight, Calculator, PiggyBank, TrendingUp, CheckCircle2, Target, HelpCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

/**
 * All content in this page are only for example, delete if unneeded
 * When building pages, remember your instructions in Frontend Workflow, Frontend Best Practices, Design Guide and Common Pitfalls
 */
export default function Home() {
  const [companyData, setCompanyData] = useState<CompanyData | null>(null);
  
  // Check for company data from URL parameters (LoanFlow integration)
  useEffect(() => {
    const urlData = getCompanyDataFromURL();
    if (urlData) {
      storeCompanyData(urlData);
      setCompanyData(urlData);
    } else {
      const storedData = getStoredCompanyData();
      if (storedData) {
        setCompanyData(storedData);
      }
    }
  }, []);
  
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  // If theme is switchable in App.tsx, we can implement theme toggling like this:
  // const { theme, toggleTheme } = useTheme();

  // Use APP_LOGO (as image src) and APP_TITLE if needed

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <main className="flex-1">
        <div className="container py-8 max-w-7xl">
        <div className="flex justify-end mb-4">
          <Link href="/help">
            <Button variant="outline" className="gap-2">
              <HelpCircle className="h-4 w-4" />
              User Guide
            </Button>
          </Link>
        </div>
        {companyData && companyData.source === 'loanflow' && (
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm font-semibold text-blue-900 mb-1">📋 Company from LoanFlow</p>
            <p className="text-lg font-bold text-blue-700">{companyData.companyName}</p>
            {companyData.companyNumber && (
              <p className="text-xs text-blue-600">Company Number: {companyData.companyNumber}</p>
            )}
            {companyData.loanAmount && (
              <p className="text-xs text-blue-600">Loan Amount: £{companyData.loanAmount}</p>
            )}
          </div>
        )}
        <div className="mb-8 text-center">
            <div className="flex justify-center mb-6">
              <img src="/first-enterprise-logo.png" alt="First Enterprise" className="h-20" />
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-3">DueDiligence</h1>
            <p className="text-lg text-muted-foreground">
              Comprehensive due diligence checklist management and reporting
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCheck className="h-6 w-6 text-primary" />
                Complete Your Due Diligence
              </CardTitle>
              <CardDescription>
                Track your progress through 56 essential checklist items across 11 key sections
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-1.5" />
                    <div>
                      <p className="font-medium">Application Validation</p>
                      <p className="text-muted-foreground">Verify applicant eligibility and loan terms</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-1.5" />
                    <div>
                      <p className="font-medium">Documentation & KYC</p>
                      <p className="text-muted-foreground">Complete identity and financial verification</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-1.5" />
                    <div>
                      <p className="font-medium">Financial Review</p>
                      <p className="text-muted-foreground">Analyze accounts and cashflow forecasts</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-1.5" />
                    <div>
                      <p className="font-medium">Credit & Governance</p>
                      <p className="text-muted-foreground">Review credit ratings and director checks</p>
                    </div>
                  </div>
                </div>
                <Link href="/due-diligence/checklist">
                  <Button size="lg" className="w-full gap-2">
                    Start Checklist
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-accent" />
                  DSCR Calculator
                </CardTitle>
                <CardDescription>
                  Debt Service Coverage Ratio analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Calculate DSCR with automatic sensitivity testing for -20% revenue scenarios.
                </p>
                <Link href="/dscr-calculator">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5 text-accent" />
                  Loan Calculator
                </CardTitle>
                <CardDescription>
                  Monthly payment and interest calculator
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Calculate monthly payments, total interest, and payment breakdown for any loan.
                </p>
                <Link href="/loan-calculator">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-accent" />
                  Affordability Estimator
                </CardTitle>
                <CardDescription>
                  Maximum loan amount calculator
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4">
                  Assess loan affordability using DSCR based on business income, costs, and proposed debt service.
                </p>
                <Link href="/affordability-estimator">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12 mt-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-purple-600" />
                  Financial Ratios
                </CardTitle>
                <CardDescription>
                  Key financial health indicators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4">
                  Calculate Acid Test Ratio, Return on Assets, and Debt to Net Worth for financial analysis.
                </p>
                <Link href="/financial-ratios">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-indigo-600" />
                  Character Assessor
                </CardTitle>
                <CardDescription>
                  Business owner evaluation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4">
                  Comprehensive character and integrity assessment covering business history, financial conduct, reputation, and commitment.
                </p>
                <Link href="/character-assessor">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-emerald-600" />
                  Loan Purpose
                </CardTitle>
                <CardDescription>
                  Purpose assessment & business case
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-4">
                  Comprehensive loan purpose documentation with business case, financial justification, ROI analysis, and risk assessment.
                </p>
                <Link href="/loan-purpose">
                  <Button variant="outline" className="w-full gap-2">
                    Open
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">56</div>
              <div className="text-sm text-muted-foreground">Checklist Items</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">11</div>
              <p className="text-sm text-muted-foreground">Key Sections</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">PDF</div>
              <p className="text-sm text-muted-foreground">Report Generation</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
