import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, ArrowLeft, Info, AlertTriangle, CheckCircle2, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AffordabilityEstimator() {
  const [annualRevenue, setAnnualRevenue] = useState("");
  const [annualCosts, setAnnualCosts] = useState("");
  const [proposedMonthlyPayment, setProposedMonthlyPayment] = useState("");
  const [isRefinancing, setIsRefinancing] = useState(false);
  const [existingLoanPayment, setExistingLoanPayment] = useState("");
  
  const [netOperatingIncome, setNetOperatingIncome] = useState<number | null>(null);
  const [adjustedNOI, setAdjustedNOI] = useState<number | null>(null);
  const [dscr, setDSCR] = useState<number | null>(null);
  const [isAffordable, setIsAffordable] = useState<boolean | null>(null);
  const [affordabilityLevel, setAffordabilityLevel] = useState<string>("");

  const calculateAffordability = () => {
    const revenue = parseFloat(annualRevenue);
    const costs = parseFloat(annualCosts);
    const monthlyPayment = parseFloat(proposedMonthlyPayment);
    const existingPayment = isRefinancing ? parseFloat(existingLoanPayment) : 0;

    if (isNaN(revenue) || isNaN(costs) || isNaN(monthlyPayment) || 
        revenue <= 0 || costs < 0 || monthlyPayment <= 0) {
      resetResults();
      return;
    }

    if (isRefinancing && (isNaN(existingPayment) || existingPayment < 0)) {
      resetResults();
      return;
    }

    // Calculate Net Operating Income
    const noi = revenue - costs;
    
    // For refinancing, add back the existing payment to NOI
    const adjustedNOIValue = isRefinancing ? noi + (existingPayment * 12) : noi;
    
    // Calculate annual debt service (new loan payment)
    const annualDebtService = monthlyPayment * 12;
    
    // Calculate DSCR
    const dscrValue = annualDebtService > 0 ? adjustedNOIValue / annualDebtService : 0;
    
    // Determine affordability
    let affordable = false;
    let level = "";
    
    if (dscrValue >= 1.5) {
      affordable = true;
      level = "Excellent";
    } else if (dscrValue >= 1.25) {
      affordable = true;
      level = "Good";
    } else if (dscrValue >= 1.0) {
      affordable = true;
      level = "Marginal";
    } else {
      affordable = false;
      level = "Insufficient";
    }

    setNetOperatingIncome(noi);
    setAdjustedNOI(adjustedNOIValue);
    setDSCR(dscrValue);
    setIsAffordable(affordable);
    setAffordabilityLevel(level);
  };

  const exportAsText = () => {
    const content = `BUSINESS AFFORDABILITY ASSESSMENT\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nBUSINESS FINANCIALS\n${'-'.repeat(50)}\nAnnual Revenue: £${parseFloat(annualRevenue).toLocaleString()}\nAnnual Operating Costs: £${parseFloat(annualCosts).toLocaleString()}\nNet Operating Income: £${netOperatingIncome?.toLocaleString()}\n${isRefinancing ? `\nREFINANCING SCENARIO\n${'-'.repeat(50)}\nExisting Monthly Payment: £${parseFloat(existingLoanPayment).toLocaleString()}\nExisting Annual Payment: £${(parseFloat(existingLoanPayment) * 12).toLocaleString()}\nAdjusted NOI (with refinancing): £${adjustedNOI?.toLocaleString()}\n` : ''}\nPROPOSED LOAN\n${'-'.repeat(50)}\nProposed Monthly Payment: £${parseFloat(proposedMonthlyPayment).toLocaleString()}\nProposed Annual Debt Service: £${(parseFloat(proposedMonthlyPayment) * 12).toLocaleString()}\n\nAFFORDABILITY ANALYSIS\n${'-'.repeat(50)}\nDebt Service Coverage Ratio (DSCR): ${dscr?.toFixed(2)}\nAffordability Level: ${affordabilityLevel}\nRecommendation: ${isAffordable ? 'AFFORDABLE - Loan can be serviced' : 'NOT AFFORDABLE - Insufficient coverage'}\n\nINTERPRETATION\n${'-'.repeat(50)}\n• DSCR ≥ 1.5: Excellent coverage\n• DSCR 1.25-1.49: Good coverage\n• DSCR 1.0-1.24: Marginal coverage\n• DSCR < 1.0: Insufficient coverage\n\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `Affordability-Assessment-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    const content = `<div class="section">\n  <h1>Business Affordability Assessment</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Business Financials</h2>\n  <table>\n    <tr>\n      <th>Metric</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Annual Revenue</td>\n      <td>£${parseFloat(annualRevenue).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Annual Operating Costs</td>\n      <td>£${parseFloat(annualCosts).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Net Operating Income</td>\n      <td>£${netOperatingIncome?.toLocaleString()}</td>\n    </tr>\n  </table>\n</div>\n${isRefinancing ? `<div class="section">\n  <h2>Refinancing Scenario</h2>\n  <table>\n    <tr>\n      <th>Item</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Existing Monthly Payment</td>\n      <td>£${parseFloat(existingLoanPayment).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Existing Annual Payment</td>\n      <td>£${(parseFloat(existingLoanPayment) * 12).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Adjusted NOI (with refinancing)</td>\n      <td>£${adjustedNOI?.toLocaleString()}</td>\n    </tr>\n  </table>\n</div>` : ''}\n\n<div class="section">\n  <h2>Proposed Loan</h2>\n  <table>\n    <tr>\n      <th>Parameter</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Proposed Monthly Payment</td>\n      <td>£${parseFloat(proposedMonthlyPayment).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Proposed Annual Debt Service</td>\n      <td>£${(parseFloat(proposedMonthlyPayment) * 12).toLocaleString()}</td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Affordability Analysis</h2>\n  <div class="result">\n    <h3>Debt Service Coverage Ratio (DSCR)</h3>\n    <p><span class="highlight">${dscr?.toFixed(2)}</span></p>\n  </div>\n  <div class="result">\n    <h3>Affordability Level</h3>\n    <p><span class="${isAffordable ? 'success' : 'error'}">${affordabilityLevel}</span></p>\n  </div>\n  <div class="result">\n    <h3>Recommendation</h3>\n    <p><span class="${isAffordable ? 'success' : 'error'}">${isAffordable ? 'AFFORDABLE - Loan can be serviced' : 'NOT AFFORDABLE - Insufficient coverage'}</span></p>\n  </div>\n</div>\n\n<div class="section">\n  <h2>Interpretation</h2>\n  <ul>\n    <li><strong>DSCR ≥ 1.5:</strong> Excellent coverage</li>\n    <li><strong>DSCR 1.25-1.49:</strong> Good coverage</li>\n    <li><strong>DSCR 1.0-1.24:</strong> Marginal coverage</li>\n    <li><strong>DSCR < 1.0:</strong> Insufficient coverage</li>\n  </ul>\n</div>`;
    downloadAsHTML(content, `Affordability-Assessment-${new Date().toISOString().split('T')[0]}`);
  };

  const resetResults = () => {
    setNetOperatingIncome(null);
    setAdjustedNOI(null);
    setDSCR(null);
    setIsAffordable(null);
    setAffordabilityLevel("");
  };

  const reset = () => {
    setAnnualRevenue("");
    setAnnualCosts("");
    setProposedMonthlyPayment("");
    setExistingLoanPayment("");
    setIsRefinancing(false);
    resetResults();
  };

  const getDSCRColor = (dscr: number) => {
    if (dscr >= 1.5) return "text-green-600";
    if (dscr >= 1.25) return "text-blue-600";
    if (dscr >= 1.0) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/due-diligence/checklist">
            <Button variant="outline" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4" />
              Back to Checklist
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-2">Business Affordability Estimator</h1>
          <p className="text-muted-foreground text-lg">
            Assess loan affordability based on business income, costs, and proposed debt service
          </p>
        </div>

        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertDescription>
            This calculator uses DSCR (Debt Service Coverage Ratio) to assess affordability. A DSCR of 1.25 or higher is typically required for loan approval.
            {isRefinancing && " For refinancing, existing loan payments are added back to available income."}
          </AlertDescription>
        </Alert>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Business Financials
              </CardTitle>
              <CardDescription>Enter your business income and expenses</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="annualRevenue">Annual Revenue / Gross Profit</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="annualRevenue"
                    type="number"
                    placeholder="0.00"
                    value={annualRevenue}
                    onChange={(e) => setAnnualRevenue(e.target.value)}
                    className="pl-7"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Total annual business income before expenses
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="annualCosts">Annual Operating Costs</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="annualCosts"
                    type="number"
                    placeholder="0.00"
                    value={annualCosts}
                    onChange={(e) => setAnnualCosts(e.target.value)}
                    className="pl-7"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Total annual business expenses and overheads
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="proposedMonthlyPayment">Proposed Monthly Loan Payment</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="proposedMonthlyPayment"
                    type="number"
                    placeholder="0.00"
                    value={proposedMonthlyPayment}
                    onChange={(e) => setProposedMonthlyPayment(e.target.value)}
                    className="pl-7"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Estimated monthly payment for the new loan
                </p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="space-y-0.5">
                  <Label htmlFor="refinancing">Refinancing Scenario</Label>
                  <p className="text-xs text-muted-foreground">
                    Enable if replacing an existing loan
                  </p>
                </div>
                <Switch
                  id="refinancing"
                  checked={isRefinancing}
                  onCheckedChange={setIsRefinancing}
                />
              </div>

              {isRefinancing && (
                <div className="space-y-2">
                  <Label htmlFor="existingLoanPayment">Existing Monthly Loan Payment</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                    <Input
                      id="existingLoanPayment"
                      type="number"
                      placeholder="0.00"
                      value={existingLoanPayment}
                      onChange={(e) => setExistingLoanPayment(e.target.value)}
                      className="pl-7"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    This amount will be added back to your available income
                  </p>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button onClick={calculateAffordability} className="flex-1">
                  Calculate
                </Button>
                <Button onClick={reset} variant="outline">
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Affordability Assessment</CardTitle>
              <CardDescription>Debt service coverage analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Net Operating Income:</span>
                  <span className="font-semibold">
                    {netOperatingIncome !== null ? `£${netOperatingIncome.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                  </span>
                </div>

                {isRefinancing && adjustedNOI !== null && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Adjusted NOI (with existing loan):</span>
                    <span className="font-semibold text-green-600">
                      £{adjustedNOI.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Annual Debt Service:</span>
                  <span className="font-semibold">
                    {proposedMonthlyPayment ? `£${(parseFloat(proposedMonthlyPayment) * 12).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                  </span>
                </div>

                <div className="border-t pt-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">DSCR:</span>
                    <span className={`text-2xl font-bold ${dscr !== null ? getDSCRColor(dscr) : ''}`}>
                      {dscr !== null ? dscr.toFixed(2) : '—'}
                    </span>
                  </div>
                  
                  {affordabilityLevel && (
                    <div className="flex items-center gap-2 justify-center p-3 rounded-md bg-muted">
                      {isAffordable ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-red-600" />
                      )}
                      <span className={`font-semibold ${isAffordable ? 'text-green-600' : 'text-red-600'}`}>
                        {affordabilityLevel}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-muted p-4 rounded-md space-y-2 text-sm">
                <p className="font-medium">DSCR Guidelines:</p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• <span className="text-green-600 font-medium">≥ 1.5</span>: Excellent coverage</li>
                  <li>• <span className="text-blue-600 font-medium">1.25 - 1.49</span>: Good coverage (typically acceptable)</li>
                  <li>• <span className="text-yellow-600 font-medium">1.0 - 1.24</span>: Marginal coverage (risky)</li>
                  <li>• <span className="text-red-600 font-medium">&lt; 1.0</span>: Insufficient coverage (not affordable)</li>
                  {isRefinancing && (
                    <li className="pt-2 border-t">• Refinancing adds existing payment back to income</li>
                  )}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {dscr !== null && (
          <>
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Export Results</CardTitle>
                <CardDescription>Download assessment results for your records</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as Text
                  </Button>
                  <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as HTML
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Calculation Breakdown</CardTitle>
              </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Income & Expenses</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Annual Revenue:</span>
                      <span>£{parseFloat(annualRevenue).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Annual Costs:</span>
                      <span>£{parseFloat(annualCosts).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between font-semibold border-t pt-2">
                      <span>Net Operating Income:</span>
                      <span>£{netOperatingIncome?.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                    </div>
                    {isRefinancing && existingLoanPayment && (
                      <>
                        <div className="flex justify-between text-green-600">
                          <span>Add back existing payment:</span>
                          <span>£{(parseFloat(existingLoanPayment) * 12).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                        </div>
                        <div className="flex justify-between font-semibold border-t pt-2">
                          <span>Adjusted NOI:</span>
                          <span className="text-green-600">£{adjustedNOI?.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">DSCR Calculation</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Proposed Monthly Payment:</span>
                      <span>£{parseFloat(proposedMonthlyPayment).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Annual Debt Service:</span>
                      <span>£{(parseFloat(proposedMonthlyPayment) * 12).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between font-semibold border-t pt-2">
                      <span>DSCR Formula:</span>
                      <span className="text-xs">NOI ÷ Annual Debt Service</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Calculation:</span>
                      <span className="text-xs">
                        £{(isRefinancing ? adjustedNOI : netOperatingIncome)?.toLocaleString('en-GB', { minimumFractionDigits: 2 })} ÷ £{(parseFloat(proposedMonthlyPayment) * 12).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className={`flex justify-between font-bold text-lg border-t pt-2 ${getDSCRColor(dscr)}`}>
                      <span>DSCR:</span>
                      <span>{dscr.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

