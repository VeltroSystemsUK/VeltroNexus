import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CHECKLIST_ITEMS, CHECKLIST_SECTIONS } from "@shared/checklistData";
import { FileDown, CheckCircle2, Calculator, PiggyBank, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Link } from "wouter";

interface ChecklistResponse {
  [itemId: number]: {
    completed: "Y" | "N" | "";
    notes: string;
  };
}

export default function Checklist() {
  const [responses, setResponses] = useState<ChecklistResponse>({});
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePDF = trpc.checklist.generatePDF.useMutation({
    onSuccess: (data: { url: string }) => {
      setIsGenerating(false);
      // Create a download link
      const link = document.createElement("a");
      link.href = data.url;
      link.download = `DueDiligence_Report_${new Date().toISOString().split("T")[0]}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success("PDF report generated successfully!");
    },
    onError: (error) => {
      setIsGenerating(false);
      toast.error(`Failed to generate PDF: ${error.message}`);
    },
  });

  const updateResponse = (itemId: number, field: "completed" | "notes", value: string) => {
    setResponses((prev) => ({
      ...prev,
      [itemId]: {
        completed: prev[itemId]?.completed || "",
        notes: prev[itemId]?.notes || "",
        [field]: value,
      },
    }));
  };

  const progress = useMemo(() => {
    const completedCount = Object.values(responses).filter((r) => r.completed === "Y").length;
    return Math.round((completedCount / CHECKLIST_ITEMS.length) * 100);
  }, [responses]);

  const handleGeneratePDF = () => {
    setIsGenerating(true);
    // Convert number keys to string keys for API
    const stringKeyResponses: Record<string, { completed: "Y" | "N" | ""; notes: string }> = {};
    Object.entries(responses).forEach(([key, value]) => {
      stringKeyResponses[key] = value;
    });
    generatePDF.mutate({ responses: stringKeyResponses });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-7xl">
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <img src="/first-enterprise-logo.png" alt="First Enterprise" className="h-16" />
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">Due Diligence Checklist</h1>
              <p className="text-muted-foreground text-base">
                Complete all checklist items and generate a comprehensive PDF report
              </p>
            </div>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-accent" />
              Progress Overview
            </CardTitle>
            <CardDescription>
              {Object.values(responses).filter((r) => r.completed === "Y").length} of {CHECKLIST_ITEMS.length} items
              completed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="h-3" />
            <p className="text-sm text-muted-foreground mt-2 text-right">{progress}% Complete</p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-4 gap-4 mb-6">
          <Link href="/dscr-calculator">
            <Button variant="outline" className="w-full gap-2 h-auto py-4">
              <Calculator className="h-5 w-5" />
              <div className="text-left">
                <div className="font-semibold">DSCR Calculator</div>
                <div className="text-xs text-muted-foreground">Debt service coverage</div>
              </div>
            </Button>
          </Link>
          <Link href="/loan-calculator">
            <Button variant="outline" className="w-full gap-2 h-auto py-4">
              <PiggyBank className="h-5 w-5" />
              <div className="text-left">
                <div className="font-semibold">Loan Calculator</div>
                <div className="text-xs text-muted-foreground">Payment estimator</div>
              </div>
            </Button>
          </Link>
          <Link href="/affordability-estimator">
            <Button variant="outline" className="w-full gap-2 h-auto py-4">
              <TrendingUp className="h-5 w-5" />
              <div className="text-left">
                <div className="font-semibold">Affordability</div>
                <div className="text-xs text-muted-foreground">Business assessment</div>
              </div>
            </Button>
          </Link>
          <Link href="/financial-ratios">
            <Button variant="outline" className="w-full gap-2 h-auto py-4">
              <TrendingUp className="h-5 w-5" />
              <div className="text-left">
                <div className="font-semibold">Financial Ratios</div>
                <div className="text-xs text-muted-foreground">Key indicators</div>
              </div>
            </Button>
          </Link>
        </div>

        <div className="space-y-8">
          {CHECKLIST_SECTIONS.map((section) => {
            const sectionItems = CHECKLIST_ITEMS.filter((item) => item.section === section);
            return (
              <Card key={section}>
                <CardHeader>
                  <CardTitle>{section}</CardTitle>
                  <CardDescription>
                    {sectionItems.filter((item) => responses[item.id]?.completed === "Y").length} of {sectionItems.length} completed
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[50px]">#</TableHead>
                        <TableHead>Checklist Item</TableHead>
                        <TableHead className="w-[120px]">Status</TableHead>
                        <TableHead className="w-[300px]">Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sectionItems.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium text-muted-foreground">{item.id}</TableCell>
                          <TableCell className="text-sm">{item.item}</TableCell>
                          <TableCell>
                            <Select
                              value={responses[item.id]?.completed || ""}
                              onValueChange={(value) => updateResponse(item.id, "completed", value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Y">Yes</SelectItem>
                                <SelectItem value="N">No</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <Textarea
                              placeholder="Add notes..."
                              value={responses[item.id]?.notes || ""}
                              onChange={(e) => updateResponse(item.id, "notes", e.target.value)}
                              className="min-h-[60px] resize-none text-sm"
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card className="mt-8">
          <CardContent className="pt-6">
            <Button onClick={handleGeneratePDF} disabled={isGenerating} className="w-full" size="lg">
              <FileDown className="mr-2 h-5 w-5" />
              {isGenerating ? "Generating PDF..." : "Generate PDF Report"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

