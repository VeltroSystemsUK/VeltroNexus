import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, ArrowLeft, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";

export default function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [loanTerm, setLoanTerm] = useState("");
  const [monthlyPayment, setMonthlyPayment] = useState<number | null>(null);
  const [totalInterest, setTotalInterest] = useState<number | null>(null);
  const [totalPayment, setTotalPayment] = useState<number | null>(null);

  const calculateLoan = () => {
    const principal = parseFloat(loanAmount);
    const annualRate = parseFloat(interestRate);
    const years = parseFloat(loanTerm);

    if (isNaN(principal) || isNaN(annualRate) || isNaN(years) || principal <= 0 || annualRate < 0 || years <= 0) {
      setMonthlyPayment(null);
      setTotalInterest(null);
      setTotalPayment(null);
      return;
    }

    const monthlyRate = annualRate / 100 / 12;
    const numberOfPayments = years * 12;

    let monthly: number;
    if (monthlyRate === 0) {
      monthly = principal / numberOfPayments;
    } else {
      monthly = (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
                (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    }

    const total = monthly * numberOfPayments;
    const interest = total - principal;

    setMonthlyPayment(monthly);
    setTotalPayment(total);
    setTotalInterest(interest);
  };

  const reset = () => {
    setLoanAmount("");
    setInterestRate("");
    setLoanTerm("");
    setMonthlyPayment(null);
    setTotalInterest(null);
    setTotalPayment(null);
  };

  const exportAsText = () => {
    const content = `LOAN CALCULATOR RESULTS\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nLOAN DETAILS\n${'-'.repeat(50)}\nLoan Amount: £${parseFloat(loanAmount).toLocaleString()}\nInterest Rate: ${interestRate}% per annum\nLoan Term: ${loanTerm} years\n\nCALCULATION RESULTS\n${'-'.repeat(50)}\nMonthly Payment: £${monthlyPayment?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}\nTotal Payment: £${totalPayment?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}\nTotal Interest: £${totalInterest?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}\n\nPAYMENT BREAKDOWN\n${'-'.repeat(50)}\nPrincipal: £${parseFloat(loanAmount).toLocaleString()}\nInterest: £${totalInterest?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}\nTotal Payments: ${parseFloat(loanTerm) * 12} monthly payments\n\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `Loan-Calculator-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    const content = `<div class="section">\n  <h1>Loan Calculator Results</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Loan Details</h2>\n  <table>\n    <tr>\n      <th>Parameter</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Loan Amount</td>\n      <td>£${parseFloat(loanAmount).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Interest Rate</td>\n      <td>${interestRate}% per annum</td>\n    </tr>\n    <tr>\n      <td>Loan Term</td>\n      <td>${loanTerm} years</td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Calculation Results</h2>\n  <div class="result">\n    <h3>Monthly Payment</h3>\n    <p><span class="highlight">£${monthlyPayment?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span></p>\n  </div>\n  <div class="result">\n    <h3>Total Payment</h3>\n    <p><span class="highlight">£${totalPayment?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span></p>\n  </div>\n  <div class="result">\n    <h3>Total Interest</h3>\n    <p><span class="highlight">£${totalInterest?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span></p>\n  </div>\n</div>\n\n<div class="section">\n  <h2>Payment Breakdown</h2>\n  <table>\n    <tr>\n      <th>Component</th>\n      <th>Amount</th>\n    </tr>\n    <tr>\n      <td>Principal</td>\n      <td>£${parseFloat(loanAmount).toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Interest</td>\n      <td>£${totalInterest?.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>\n    </tr>\n    <tr>\n      <td>Total Payments</td>\n      <td>${parseFloat(loanTerm) * 12} monthly payments</td>\n    </tr>\n  </table>\n</div>`;
    downloadAsHTML(content, `Loan-Calculator-${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/due-diligence/checklist">
            <Button variant="ghost" className="gap-2 mb-4">
              <ArrowLeft className="h-4 w-4" />
              Back to Checklist
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-2">Loan Calculator</h1>
          <p className="text-muted-foreground text-lg">
            Calculate monthly payments and total interest (Commercial loans: typically 1-5 years)
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" />
                Loan Details
              </CardTitle>
              <CardDescription>Enter the loan parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="loanAmount">Loan Amount</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">£</span>
                  <Input
                    id="loanAmount"
                    type="number"
                    placeholder="0.00"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    className="pl-7"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="interestRate">Annual Interest Rate</Label>
                <div className="relative">
                  <Input
                    id="interestRate"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    className="pr-7"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Current BoE base rate + margin
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="loanTerm">Loan Term</Label>
                <div className="relative">
                  <Input
                    id="loanTerm"
                    type="number"
                    placeholder="0"
                    min="0.5"
                    step="0.5"
                    value={loanTerm}
                    onChange={(e) => setLoanTerm(e.target.value)}
                    className="pr-16"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">years</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Commercial loans typically 1-5 years; mortgages up to 25-30 years
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <Button onClick={calculateLoan} className="flex-1">
                  Calculate
                </Button>
                <Button onClick={reset} variant="outline">
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Results</CardTitle>
              <CardDescription>Loan payment breakdown</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex justify-between items-baseline border-b pb-3">
                  <span className="text-sm font-medium">Monthly Payment:</span>
                  <div className="text-right">
                    <span className="text-3xl font-bold text-foreground">
                      {monthlyPayment !== null ? `£${monthlyPayment.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—"}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Total Interest:</span>
                    <span className="text-lg font-semibold text-foreground">
                      {totalInterest !== null ? `£${totalInterest.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—"}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Total Payment:</span>
                    <span className="text-lg font-semibold text-foreground">
                      {totalPayment !== null ? `£${totalPayment.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—"}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Principal:</span>
                    <span className="text-lg font-semibold text-foreground">
                      {loanAmount ? `£${parseFloat(loanAmount).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—"}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg space-y-2 text-xs">
                <p className="font-medium">Calculation Formula:</p>
                <p className="text-muted-foreground">
                  M = P × [r(1 + r)^n] / [(1 + r)^n - 1]
                </p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• M = Monthly payment</li>
                  <li>• P = Principal loan amount</li>
                  <li>• r = Monthly interest rate</li>
                  <li>• n = Number of payments</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {monthlyPayment !== null && totalInterest !== null && (
          <>
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Export Results</CardTitle>
                <CardDescription>Download calculation results for your records</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as Text
                  </Button>
                  <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as HTML
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Payment Summary</CardTitle>
              </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Interest as % of principal:</span>
                  <span className="font-medium">
                    {((totalInterest / parseFloat(loanAmount)) * 100).toFixed(2)}%
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total number of payments:</span>
                  <span className="font-medium">{parseFloat(loanTerm) * 12}</span>
                </div>
              </div>
            </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

