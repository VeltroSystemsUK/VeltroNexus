import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Plus, Target, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { toast } from "sonner";

type Period = "monthly" | "quarterly" | "yearly";

export default function Targets() {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  const currentQuarter = Math.ceil(currentMonth / 3);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    period: "monthly" as Period,
    year: currentYear,
    month: currentMonth,
    quarter: currentQuarter,
    targetAmount: "",
    targetCount: "",
  });

  const { data: targets = [], isLoading, refetch } = trpc.targets.list.useQuery();
  const { data: prospects = [] } = trpc.prospects.list.useQuery();

  const createTargetMutation = trpc.targets.create.useMutation({
    onSuccess: () => {
      toast.success("Target created successfully");
      refetch();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`Failed to create target: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      period: "monthly",
      year: currentYear,
      month: currentMonth,
      quarter: currentQuarter,
      targetAmount: "",
      targetCount: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.targetAmount) {
      toast.error("Target amount is required");
      return;
    }

    createTargetMutation.mutate({
      period: formData.period,
      year: formData.year,
      month: formData.period === "monthly" ? formData.month : undefined,
      quarter: formData.period === "quarterly" ? formData.quarter : undefined,
      targetAmount: Math.round(parseFloat(formData.targetAmount) * 100), // Convert to pence
      targetCount: formData.targetCount ? parseInt(formData.targetCount) : undefined,
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount / 100);
  };

  const getPeriodLabel = (target: any) => {
    if (target.period === "monthly") {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      return `${monthNames[target.month! - 1]} ${target.year}`;
    } else if (target.period === "quarterly") {
      return `Q${target.quarter} ${target.year}`;
    } else {
      return `${target.year}`;
    }
  };

  const calculateProgress = (actual: number, target: number) => {
    if (target === 0) return 0;
    return Math.min(Math.round((actual / target) * 100), 100);
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 100) return "text-green-600 dark:text-green-400";
    if (progress >= 75) return "text-blue-600 dark:text-blue-400";
    if (progress >= 50) return "text-amber-600 dark:text-amber-400";
    return "text-red-600 dark:text-red-400";
  };

  // Calculate current period actuals from approved prospects
  const approvedProspects = prospects.filter(p => p.stage === "approved");
  const currentMonthApproved = approvedProspects.filter(p => {
    const date = new Date(p.createdAt);
    return date.getMonth() + 1 === currentMonth && date.getFullYear() === currentYear;
  });
  const currentQuarterApproved = approvedProspects.filter(p => {
    const date = new Date(p.createdAt);
    const quarter = Math.ceil((date.getMonth() + 1) / 3);
    return quarter === currentQuarter && date.getFullYear() === currentYear;
  });
  const currentYearApproved = approvedProspects.filter(p => {
    const date = new Date(p.createdAt);
    return date.getFullYear() === currentYear;
  });

  const currentMonthAmount = currentMonthApproved.reduce((sum, p) => sum + (p.loanAmount || 0), 0);
  const currentQuarterAmount = currentQuarterApproved.reduce((sum, p) => sum + (p.loanAmount || 0), 0);
  const currentYearAmount = currentYearApproved.reduce((sum, p) => sum + (p.loanAmount || 0), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading targets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Targets</h1>
          <p className="text-muted-foreground mt-2">
            Set and track your lending goals
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Set Target
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set New Target</DialogTitle>
              <DialogDescription>
                Define your lending goals for a specific period
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="period">Period *</Label>
                  <Select
                    value={formData.period}
                    onValueChange={(value) => setFormData({ ...formData, period: value as Period })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="year">Year *</Label>
                    <Input
                      id="year"
                      type="number"
                      value={formData.year}
                      onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                      min={2020}
                      max={2050}
                      required
                    />
                  </div>

                  {formData.period === "monthly" && (
                    <div className="space-y-2">
                      <Label htmlFor="month">Month *</Label>
                      <Select
                        value={formData.month.toString()}
                        onValueChange={(value) => setFormData({ ...formData, month: parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 12 }, (_, i) => i + 1).map((month) => (
                            <SelectItem key={month} value={month.toString()}>
                              {new Date(2024, month - 1).toLocaleString("en-GB", { month: "long" })}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {formData.period === "quarterly" && (
                    <div className="space-y-2">
                      <Label htmlFor="quarter">Quarter *</Label>
                      <Select
                        value={formData.quarter.toString()}
                        onValueChange={(value) => setFormData({ ...formData, quarter: parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Q1 (Jan-Mar)</SelectItem>
                          <SelectItem value="2">Q2 (Apr-Jun)</SelectItem>
                          <SelectItem value="3">Q3 (Jul-Sep)</SelectItem>
                          <SelectItem value="4">Q4 (Oct-Dec)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="targetAmount">Target Amount (£) *</Label>
                  <Input
                    id="targetAmount"
                    type="number"
                    value={formData.targetAmount}
                    onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                    placeholder="e.g., 500000"
                    min={0}
                    step={1000}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="targetCount">Target Number of Loans</Label>
                  <Input
                    id="targetCount"
                    type="number"
                    value={formData.targetCount}
                    onChange={(e) => setFormData({ ...formData, targetCount: e.target.value })}
                    placeholder="e.g., 10"
                    min={0}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={createTargetMutation.isPending}>
                  {createTargetMutation.isPending ? "Creating..." : "Create Target"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Current Period Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(currentMonthAmount)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {currentMonthApproved.length} loan{currentMonthApproved.length !== 1 ? "s" : ""} approved
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Quarter (Q{currentQuarter})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(currentQuarterAmount)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {currentQuarterApproved.length} loan{currentQuarterApproved.length !== 1 ? "s" : ""} approved
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Year ({currentYear})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(currentYearAmount)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {currentYearApproved.length} loan{currentYearApproved.length !== 1 ? "s" : ""} approved
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Targets List */}
      {targets.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Target className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">No targets set yet</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Set Your First Target
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Your Targets</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {targets.map((target) => {
              const amountProgress = calculateProgress(target.actualAmount || 0, target.targetAmount);
              const countProgress = target.targetCount 
                ? calculateProgress(target.actualCount || 0, target.targetCount)
                : null;

              return (
                <Card key={target.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{getPeriodLabel(target)}</CardTitle>
                      <Badge variant="outline" className="capitalize">
                        {target.period}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Amount Target */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Loan Amount</span>
                        <span className={`text-sm font-bold ${getProgressColor(amountProgress)}`}>
                          {amountProgress}%
                        </span>
                      </div>
                      <Progress value={amountProgress} className="h-2 mb-2" />
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{formatCurrency(target.actualAmount || 0)}</span>
                        <span>of {formatCurrency(target.targetAmount)}</span>
                      </div>
                      <div className="flex items-center gap-1 text-xs mt-1">
                        {amountProgress >= 100 ? (
                          <>
                            <TrendingUp className="h-3 w-3 text-green-600" />
                            <span className="text-green-600 dark:text-green-400">Target achieved!</span>
                          </>
                        ) : amountProgress >= 75 ? (
                          <>
                            <TrendingUp className="h-3 w-3 text-blue-600" />
                            <span className="text-blue-600 dark:text-blue-400">On track</span>
                          </>
                        ) : amountProgress >= 50 ? (
                          <>
                            <Minus className="h-3 w-3 text-amber-600" />
                            <span className="text-amber-600 dark:text-amber-400">Needs attention</span>
                          </>
                        ) : (
                          <>
                            <TrendingDown className="h-3 w-3 text-red-600" />
                            <span className="text-red-600 dark:text-red-400">Behind target</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Count Target */}
                    {target.targetCount && countProgress !== null && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">Number of Loans</span>
                          <span className={`text-sm font-bold ${getProgressColor(countProgress)}`}>
                            {countProgress}%
                          </span>
                        </div>
                        <Progress value={countProgress} className="h-2 mb-2" />
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <span>{target.actualCount || 0} loans</span>
                          <span>of {target.targetCount} target</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

