import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, Mail, Phone, Smartphone, Briefcase, Star, Download, MoreVertical, Pencil, Trash2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

interface ProspectContactsProps {
  companyId: number;
  companyNumber: string;
}

export default function ProspectContacts({ companyId, companyNumber }: ProspectContactsProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<number | null>(null);
  const [isMigrating, setIsMigrating] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    jobTitle: "",
    email: "",
    phone: "",
    mobile: "",
    isPrimary: false,
    notes: "",
  });

  const { data: contacts = [], isLoading, refetch } = trpc.contacts.list.useQuery({ companyId });
  const { data: officers, isLoading: officersLoading } = trpc.companies.getOfficers.useQuery({ companyNumber });

  const createContactMutation = trpc.contacts.create.useMutation({
    onSuccess: () => {
      toast.success("Contact added successfully");
      refetch();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast.error(`Failed to add contact: ${error.message}`);
    },
  });

  const updateContactMutation = trpc.contacts.update.useMutation({
    onSuccess: () => {
      toast.success("Contact updated successfully");
      refetch();
      setIsDialogOpen(false);
      setEditingContact(null);
      resetForm();
    },
    onError: (error: any) => {
      toast.error(`Failed to update contact: ${error.message}`);
    },
  });

  const deleteContactMutation = trpc.contacts.delete.useMutation({
    onSuccess: () => {
      toast.success("Contact deleted successfully");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Failed to delete contact: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      jobTitle: "",
      email: "",
      phone: "",
      mobile: "",
      isPrimary: false,
      notes: "",
    });
    setEditingContact(null);
  };

  const handleEdit = (contact: any) => {
    setEditingContact(contact.id);
    setFormData({
      firstName: contact.firstName || "",
      lastName: contact.lastName || "",
      jobTitle: contact.jobTitle || "",
      email: contact.email || "",
      phone: contact.phone || "",
      mobile: contact.mobile || "",
      isPrimary: contact.isPrimary || false,
      notes: contact.notes || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (contactId: number) => {
    if (confirm("Are you sure you want to delete this contact?")) {
      deleteContactMutation.mutate({ id: contactId });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.lastName) {
      toast.error("First name and last name are required");
      return;
    }

    if (editingContact) {
      updateContactMutation.mutate({
        id: editingContact,
        ...formData,
      });
    } else {
      createContactMutation.mutate({
        companyId,
        ...formData,
      });
    }
  };

  const migrateOfficers = async () => {
    if (!officers?.items || officers.items.length === 0) {
      toast.error("No officers found to migrate");
      return;
    }

    setIsMigrating(true);
    let successCount = 0;
    let errorCount = 0;

    for (const officer of officers.items) {
      try {
        // Parse officer name
        const nameParts = officer.name.split(",").map((p: string) => p.trim());
        let firstName = "";
        let lastName = "";

        if (nameParts.length === 2) {
          lastName = nameParts[0];
          firstName = nameParts[1];
        } else {
          const fullName = officer.name.split(" ");
          firstName = fullName[0] || "";
          lastName = fullName.slice(1).join(" ") || "";
        }

        await createContactMutation.mutateAsync({
          companyId,
          firstName,
          lastName,
          jobTitle: officer.officer_role || "",
          email: "",
          phone: "",
          mobile: "",
          isPrimary: false,
          notes: `Migrated from Companies House. Appointed: ${officer.appointed_on || "Unknown"}`,
        });
        successCount++;
      } catch (error) {
        errorCount++;
      }
    }

    setIsMigrating(false);
    refetch();
    toast.success(`Migrated ${successCount} officer${successCount !== 1 ? "s" : ""} to contacts${errorCount > 0 ? ` (${errorCount} failed)` : ""}`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading contacts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Contacts</h3>
          <p className="text-sm text-muted-foreground">
            Manage contacts at this company
          </p>
        </div>
        <div className="flex gap-2">
          {contacts.length === 0 && officers?.items && officers.items.length > 0 && (
            <Button
              variant="outline"
              onClick={migrateOfficers}
              disabled={isMigrating || officersLoading}
            >
              <Download className="mr-2 h-4 w-4" />
              {isMigrating ? "Migrating..." : "Import Officers"}
            </Button>
          )}
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) {
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
              <DialogTitle>{editingContact ? "Edit Contact" : "Add New Contact"}</DialogTitle>
              <DialogDescription>
                {editingContact ? "Update contact information" : "Add a contact for this prospect company"}
              </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="jobTitle">Job Title</Label>
                    <Input
                      id="jobTitle"
                      value={formData.jobTitle}
                      onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
                      placeholder="e.g., Managing Director, Finance Director"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="contact@company.com"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="020 1234 5678"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mobile">Mobile</Label>
                      <Input
                        id="mobile"
                        value={formData.mobile}
                        onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                        placeholder="07123 456789"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="isPrimary"
                      checked={formData.isPrimary}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, isPrimary: checked as boolean })
                      }
                    />
                    <Label htmlFor="isPrimary" className="cursor-pointer">
                      Primary Contact
                    </Label>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Additional notes about this contact..."
                      rows={3}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      resetForm();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createContactMutation.isPending || updateContactMutation.isPending}>
                    {editingContact 
                      ? (updateContactMutation.isPending ? "Updating..." : "Update Contact")
                      : (createContactMutation.isPending ? "Adding..." : "Add Contact")
                    }
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {contacts.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Mail className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">No contacts yet</p>
            {officers?.items && officers.items.length > 0 ? (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Found {officers.items.length} officer{officers.items.length !== 1 ? "s" : ""} from Companies House
                </p>
                <Button onClick={migrateOfficers} disabled={isMigrating || officersLoading}>
                  <Download className="mr-2 h-4 w-4" />
                  {isMigrating ? "Importing..." : "Import Officers as Contacts"}
                </Button>
              </div>
            ) : (
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add First Contact
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {contacts.map((contact) => (
            <Card key={contact.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg">
                        {contact.firstName} {contact.lastName}
                      </h3>
                      {contact.isPrimary && (
                        <Badge variant="secondary" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                          <Star className="h-3 w-3 mr-1 fill-current" />
                          Primary
                        </Badge>
                      )}
                    </div>

                    {contact.jobTitle && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <Briefcase className="h-4 w-4" />
                        {contact.jobTitle}
                      </div>
                    )}

                    <div className="space-y-1">
                      {contact.email && (
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <a
                            href={`mailto:${contact.email}`}
                            className="text-primary hover:underline"
                          >
                            {contact.email}
                          </a>
                        </div>
                      )}
                      {contact.phone && (
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <a
                            href={`tel:${contact.phone}`}
                            className="text-primary hover:underline"
                          >
                            {contact.phone}
                          </a>
                        </div>
                      )}
                      {contact.mobile && (
                        <div className="flex items-center gap-2 text-sm">
                          <Smartphone className="h-4 w-4 text-muted-foreground" />
                          <a
                            href={`tel:${contact.mobile}`}
                            className="text-primary hover:underline"
                          >
                            {contact.mobile}
                          </a>
                        </div>
                      )}
                    </div>

                    {contact.notes && (
                      <div className="mt-3 p-2 bg-muted rounded text-sm">
                        <p className="text-muted-foreground">{contact.notes}</p>
                      </div>
                    )}
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEdit(contact)}>
                        <Pencil className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(contact.id)}
                        className="text-destructive"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

