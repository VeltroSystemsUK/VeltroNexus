import { useState } from "react";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Building2,
  MapPin,
  Calendar,
  FileText,
  Users,
  Shield,
  TrendingUp,
  AlertTriangle,
  ArrowLeft,
  Loader2,
  Plus,
  Download,
  Save,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function CompanyDetail() {
  const params = useParams();
  const companyNumber = params.companyNumber as string;

  const utils = trpc.useUtils();
  const [showFinancialForm, setShowFinancialForm] = useState(false);
  const [financialData, setFinancialData] = useState({
    accountsYear: "",
    accountsPeriodEnd: "",
    revenue: "",
    grossProfit: "",
    operatingProfit: "",
    profitBeforeTax: "",
    profitAfterTax: "",
    totalAssets: "",
    currentAssets: "",
    fixedAssets: "",
    inventory: "",
    cashAndEquivalents: "",
    totalLiabilities: "",
    currentLiabilities: "",
    longTermDebt: "",
    shareholderEquity: "",
    numberOfEmployees: "",
    notes: "",
  });

  // Fetch all company data
  const { data: profile, isLoading: profileLoading } = trpc.companies.getProfile.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: officers } = trpc.companies.getOfficers.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: psc } = trpc.companies.getPSC.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: charges } = trpc.companies.getCharges.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: filingHistory } = trpc.companies.getFilingHistory.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: insolvency } = trpc.companies.getInsolvency.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: savedCompany } = trpc.companies.getByNumber.useQuery(
    { companyNumber },
    { enabled: !!companyNumber }
  );

  const { data: savedFinancials } = trpc.companies.getFinancials.useQuery(
    { companyId: savedCompany?.id || 0 },
    { enabled: !!savedCompany?.id }
  );

  const upsertCompanyMutation = trpc.companies.upsert.useMutation();
  const addProspectMutation = trpc.prospects.create.useMutation({
    onSuccess: () => {
      toast.success("Company added to prospects!");
      utils.prospects.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to add prospect: " + error.message);
    },
  });

  const createFinancialMutation = trpc.companies.createFinancial.useMutation({
    onSuccess: () => {
      toast.success("Financial data saved!");
      utils.companies.getFinancials.invalidate();
      setShowFinancialForm(false);
      setFinancialData({
        accountsYear: "",
        accountsPeriodEnd: "",
        revenue: "",
        grossProfit: "",
        operatingProfit: "",
        profitBeforeTax: "",
        profitAfterTax: "",
        totalAssets: "",
        currentAssets: "",
        fixedAssets: "",
        inventory: "",
        cashAndEquivalents: "",
        totalLiabilities: "",
        currentLiabilities: "",
        longTermDebt: "",
        shareholderEquity: "",
        numberOfEmployees: "",
        notes: "",
      });
    },
    onError: (error) => {
      toast.error("Failed to save financial data: " + error.message);
    },
  });

  const handleAddProspect = async () => {
    if (!profile) return;

    try {
      // First upsert the company to our database
      const savedCompany = await upsertCompanyMutation.mutateAsync({
        companyNumber: profile.company_number,
        companyName: profile.company_name,
        companyStatus: profile.company_status,
        companyType: profile.company_type,
        incorporationDate: profile.date_of_creation,
        addressLine1: profile.registered_office_address?.address_line_1,
        addressLine2: profile.registered_office_address?.address_line_2,
        locality: profile.registered_office_address?.locality,
        region: profile.registered_office_address?.region,
        postalCode: profile.registered_office_address?.postal_code,
        country: profile.registered_office_address?.country || "England",
        rawData: JSON.stringify(profile),
      });

      // Then create a prospect linked to this company
      await addProspectMutation.mutateAsync({
        companyId: savedCompany.id,
      });
    } catch (error: any) {
      toast.error("Failed to add prospect: " + error.message);
    }
  };

  const handleSaveFinancials = async () => {
    if (!savedCompany) {
      toast.error("Please add company to prospects first");
      return;
    }

    if (!financialData.accountsYear) {
      toast.error("Please enter the accounts year");
      return;
    }

    // Convert string values to numbers (in pence)
    const financialPayload: any = {
      companyId: savedCompany.id,
      accountsYear: financialData.accountsYear,
      accountsPeriodEnd: financialData.accountsPeriodEnd || undefined,
      notes: financialData.notes || undefined,
    };

    // Convert monetary values to pence
    const monetaryFields = [
      "revenue",
      "grossProfit",
      "operatingProfit",
      "profitBeforeTax",
      "profitAfterTax",
      "totalAssets",
      "currentAssets",
      "fixedAssets",
      "inventory",
      "cashAndEquivalents",
      "totalLiabilities",
      "currentLiabilities",
      "longTermDebt",
      "shareholderEquity",
    ];

    monetaryFields.forEach((field) => {
      const value = financialData[field as keyof typeof financialData];
      if (value && value !== "") {
        financialPayload[field] = Math.round(parseFloat(value) * 100); // Convert to pence
      }
    });

    if (financialData.numberOfEmployees) {
      financialPayload.numberOfEmployees = parseInt(financialData.numberOfEmployees);
    }

    await createFinancialMutation.mutateAsync(financialPayload);
  };

  // Helper to get document download URL
  const getDocumentUrl = (transactionId: string) => {
    return `https://find-and-update.company-information.service.gov.uk/company/${companyNumber}/filing-history/${transactionId}/document?format=pdf&download=0`;
  };

  // Filter filing history for key documents
  const accountsFilings = filingHistory?.items?.filter((f: any) =>
    f.category?.includes("accounts")
  ) || [];

  const confirmationStatements = filingHistory?.items?.filter((f: any) =>
    f.category?.includes("confirmation-statement") || f.category?.includes("annual-return")
  ) || [];

  if (profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertTriangle className="w-12 h-12 text-destructive mb-4" />
            <p className="text-lg font-medium">Company not found</p>
            <Link href="/">
              <Button className="mt-4">Back to Search</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const formatCurrency = (pence: number) => {
    return `£${(pence / 100).toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Search
            </Button>
          </Link>
        </div>
        <Button onClick={handleAddProspect} disabled={addProspectMutation.isPending}>
          <Plus className="w-4 h-4 mr-2" />
          Add to Prospects
        </Button>
      </div>

      {/* Company Title */}
      <div className="flex items-start gap-4">
        <Building2 className="w-8 h-8 text-primary mt-1" />
        <div className="flex-1">
          <h1 className="text-3xl font-bold">{profile.company_name}</h1>
          <p className="text-muted-foreground">Company Number: {profile.company_number}</p>
          <Badge
            variant={profile.company_status === "active" ? "default" : "secondary"}
            className="mt-2"
          >
            {profile.company_status?.toUpperCase()}
          </Badge>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="officers">
            Officers
            {officers?.items && <span className="ml-1">({officers.items.length})</span>}
          </TabsTrigger>
          <TabsTrigger value="psc">
            PSC
            {psc?.items && <span className="ml-1">({psc.items.length})</span>}
          </TabsTrigger>
          <TabsTrigger value="shareholding">Shareholding</TabsTrigger>
          <TabsTrigger value="filing">
            Filing History
            {filingHistory?.items && <span className="ml-1">({filingHistory.items.length})</span>}
          </TabsTrigger>
          <TabsTrigger value="charges">
            Charges
            {charges?.items && <span className="ml-1">({charges.items.length})</span>}
          </TabsTrigger>
          <TabsTrigger value="financials">Financials</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Company Name</p>
                <p className="font-medium">{profile.company_name}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Company Number</p>
                <p className="font-mono">{profile.company_number}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Status</p>
                <Badge variant={profile.company_status === "active" ? "default" : "secondary"}>
                  {profile.company_status?.toUpperCase()}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Company Type</p>
                <p>{profile.company_type?.replace(/-/g, " ")}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">
                  Incorporated On
                </p>
                <p>{profile.date_of_creation ? new Date(profile.date_of_creation).toLocaleDateString() : 'N/A'}</p>
              </div>

            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Registered Office Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              {profile.registered_office_address && (
                <div className="space-y-1">
                  {profile.registered_office_address.address_line_1 && (
                    <p>{profile.registered_office_address.address_line_1}</p>
                  )}
                  {profile.registered_office_address.address_line_2 && (
                    <p>{profile.registered_office_address.address_line_2}</p>
                  )}
                  {profile.registered_office_address.locality && (
                    <p>{profile.registered_office_address.locality}</p>
                  )}
                  {profile.registered_office_address.region && (
                    <p>{profile.registered_office_address.region}</p>
                  )}
                  {profile.registered_office_address.postal_code && (
                    <p className="font-medium">{profile.registered_office_address.postal_code}</p>
                  )}
                  {profile.registered_office_address.country && (
                    <p>{profile.registered_office_address.country}</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {profile.sic_codes && profile.sic_codes.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>SIC Codes</CardTitle>
                <CardDescription>Standard Industrial Classification</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {profile.sic_codes.map((code: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {code}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {profile.accounts && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Accounts Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {profile.accounts.next_due && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      Next Accounts Due
                    </p>
                    <p>{new Date(profile.accounts.next_due).toLocaleDateString()}</p>
                  </div>
                )}
                {profile.accounts.last_accounts && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      Last Accounts Made Up To
                    </p>
                    <p>
                      {new Date(profile.accounts.last_accounts.made_up_to).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Officers Tab */}
        <TabsContent value="officers" className="space-y-4">
          {officers?.items && officers.items.length > 0 ? (
            officers.items.map((officer: any, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{officer.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {officer.officer_role?.replace(/_/g, " ")}
                      </CardDescription>
                    </div>
                    <Badge
                      variant={officer.resigned_on ? "secondary" : "default"}
                      className={officer.resigned_on ? "" : "bg-green-100 text-green-800"}
                    >
                      {officer.resigned_on ? "RESIGNED" : "ACTIVE"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  {officer.appointed_on && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Appointed On</p>
                      <p>{new Date(officer.appointed_on).toLocaleDateString()}</p>
                    </div>
                  )}
                  {officer.resigned_on && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Resigned On</p>
                      <p>{new Date(officer.resigned_on).toLocaleDateString()}</p>
                    </div>
                  )}
                  {officer.nationality && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Nationality</p>
                      <p>{officer.nationality}</p>
                    </div>
                  )}
                  {officer.occupation && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Occupation</p>
                      <p>{officer.occupation}</p>
                    </div>
                  )}
                  {officer.date_of_birth && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Date of Birth</p>
                      <p>
                        {officer.date_of_birth.month}/{officer.date_of_birth.year}
                      </p>
                    </div>
                  )}
                  {officer.address && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Address</p>
                      <div className="text-sm">
                        {officer.address.address_line_1 && <p>{officer.address.address_line_1}</p>}
                        {officer.address.locality && <p>{officer.address.locality}</p>}
                        {officer.address.postal_code && <p>{officer.address.postal_code}</p>}
                        {officer.address.country && <p>{officer.address.country}</p>}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No officers found</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* PSC Tab */}
        <TabsContent value="psc" className="space-y-4">
          {psc?.items && psc.items.length > 0 ? (
            psc.items.map((person: any, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle>{person.name}</CardTitle>
                  <CardDescription>
                    {person.kind?.replace(/-/g, " ").replace("psc", "PSC")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {person.notified_on && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Notified On</p>
                      <p>{new Date(person.notified_on).toLocaleDateString()}</p>
                    </div>
                  )}
                  {person.nationality && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Nationality</p>
                      <p>{person.nationality}</p>
                    </div>
                  )}
                  {person.natures_of_control && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        Nature of Control
                      </p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {person.natures_of_control.map((nature: string, i: number) => (
                          <Badge key={i} variant="outline">
                            {nature.replace(/-/g, " ")}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Shield className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No PSC records found</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Shareholding Tab */}
        <TabsContent value="shareholding" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Share Capital & Confirmation Statements</CardTitle>
              <CardDescription>
                Detailed shareholding information from confirmation statements
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {confirmationStatements.length > 0 ? (
                <>
                  <p className="text-sm text-muted-foreground">
                    Download confirmation statements to view detailed shareholding information:
                  </p>
                  <div className="space-y-2">
                    {confirmationStatements.slice(0, 5).map((filing: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div>
                          <p className="font-medium">{filing.description}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(filing.date).toLocaleDateString()}
                          </p>
                        </div>
                        {filing.links?.document_metadata && (
                          <a
                            href={getDocumentUrl(filing.transaction_id)}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4 mr-2" />
                              Download PDF
                            </Button>
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground text-sm">
                  No confirmation statements available. Detailed shareholding information requires
                  manual review of company documents.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Filing History Tab */}
        <TabsContent value="filing" className="space-y-4">
          {filingHistory?.items && filingHistory.items.length > 0 ? (
            filingHistory.items.slice(0, 20).map((filing: any, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{filing.description}</CardTitle>
                      <CardDescription className="mt-1">
                        {filing.category?.replace(/-/g, " ").toUpperCase()}
                      </CardDescription>
                    </div>
                    <div className="text-right flex items-center gap-2">
                      <div>
                        <p className="text-sm font-medium">
                          {new Date(filing.date).toLocaleDateString()}
                        </p>
                        {filing.action_date && (
                          <p className="text-xs text-muted-foreground">
                            Action: {new Date(filing.action_date).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      {filing.links?.document_metadata && (
                        <a
                          href={getDocumentUrl(filing.transaction_id)}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No filing history found</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Charges Tab */}
        <TabsContent value="charges" className="space-y-4">
          {charges?.items && charges.items.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Total Charges</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">{charges.total_count || 0}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Outstanding</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-amber-600">
                      {charges.unfiltered_count || 0}
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Satisfied</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-green-600">
                      {charges.satisfied_count || 0}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {charges.items.map((charge: any, index: number) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <CardTitle className="text-lg">
                            {charge.classification?.description || "Charge"}
                          </CardTitle>
                          <Badge
                            variant={charge.status === "outstanding" ? "destructive" : "default"}
                            className={
                              charge.status === "satisfied"
                                ? "bg-green-100 text-green-800"
                                : ""
                            }
                          >
                            {charge.status?.toUpperCase()}
                          </Badge>
                        </div>
                        <CardDescription>
                          {charge.persons_entitled?.map((p: any) => p.name).join(", ")}
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          Created: {new Date(charge.created_on).toLocaleDateString()}
                        </p>
                        {charge.delivered_on && (
                          <p className="text-xs text-muted-foreground">
                            Delivered: {new Date(charge.delivered_on).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {charge.charge_number && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Charge Number</p>
                        <p className="font-mono">{charge.charge_number}</p>
                      </div>
                    )}
                    {charge.particulars?.description && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Description</p>
                        <p className="text-sm">{charge.particulars.description}</p>
                      </div>
                    )}
                    {charge.satisfied_on && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Satisfied On</p>
                        <p>{new Date(charge.satisfied_on).toLocaleDateString()}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Shield className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No charges found</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Financials Tab */}
        <TabsContent value="financials" className="space-y-4">
          {/* Accounts Documents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Filed Accounts</span>
                {!showFinancialForm && savedCompany && (
                  <Button onClick={() => setShowFinancialForm(true)} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Financial Data
                  </Button>
                )}
              </CardTitle>
              <CardDescription>Download accounts to view full financial statements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {accountsFilings.length > 0 ? (
                <div className="space-y-2">
                  {accountsFilings.slice(0, 5).map((filing: any, index: number) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <p className="font-medium">{filing.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(filing.date).toLocaleDateString()}
                        </p>
                      </div>
                      {filing.links?.document_metadata && (
                        <a
                          href={getDocumentUrl(filing.transaction_id)}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Download PDF
                          </Button>
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No accounts filed yet</p>
              )}

              {profile.accounts?.last_accounts && (
                <div className="pt-4 border-t">
                  <h3 className="font-semibold mb-2">Last Accounts Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">
                        Made Up To Date
                      </p>
                      <p>
                        {new Date(
                          profile.accounts.last_accounts.made_up_to
                        ).toLocaleDateString()}
                      </p>
                    </div>
                    {profile.accounts.last_accounts.type && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground mb-1">Type</p>
                        <p>{profile.accounts.last_accounts.type.replace(/-/g, " ")}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Manual Financial Data Entry Form */}
          {showFinancialForm && savedCompany && (
            <Card>
              <CardHeader>
                <CardTitle>Enter Financial Data</CardTitle>
                <CardDescription>
                  Manually input key financial metrics from downloaded accounts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="accountsYear">Accounts Year *</Label>
                    <Input
                      id="accountsYear"
                      placeholder="e.g., 2024 or FY2023-24"
                      value={financialData.accountsYear}
                      onChange={(e) =>
                        setFinancialData({ ...financialData, accountsYear: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="accountsPeriodEnd">Period End Date</Label>
                    <Input
                      id="accountsPeriodEnd"
                      type="date"
                      value={financialData.accountsPeriodEnd}
                      onChange={(e) =>
                        setFinancialData({ ...financialData, accountsPeriodEnd: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Income Statement (£)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="revenue">Revenue</Label>
                      <Input
                        id="revenue"
                        type="number"
                        placeholder="0.00"
                        value={financialData.revenue}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, revenue: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="grossProfit">Gross Profit</Label>
                      <Input
                        id="grossProfit"
                        type="number"
                        placeholder="0.00"
                        value={financialData.grossProfit}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, grossProfit: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="operatingProfit">Operating Profit</Label>
                      <Input
                        id="operatingProfit"
                        type="number"
                        placeholder="0.00"
                        value={financialData.operatingProfit}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, operatingProfit: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="profitBeforeTax">Profit Before Tax</Label>
                      <Input
                        id="profitBeforeTax"
                        type="number"
                        placeholder="0.00"
                        value={financialData.profitBeforeTax}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, profitBeforeTax: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="profitAfterTax">Profit After Tax</Label>
                      <Input
                        id="profitAfterTax"
                        type="number"
                        placeholder="0.00"
                        value={financialData.profitAfterTax}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, profitAfterTax: e.target.value })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Balance Sheet (£)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="totalAssets">Total Assets</Label>
                      <Input
                        id="totalAssets"
                        type="number"
                        placeholder="0.00"
                        value={financialData.totalAssets}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, totalAssets: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="currentAssets">Current Assets</Label>
                      <Input
                        id="currentAssets"
                        type="number"
                        placeholder="0.00"
                        value={financialData.currentAssets}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, currentAssets: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="fixedAssets">Fixed Assets</Label>
                      <Input
                        id="fixedAssets"
                        type="number"
                        placeholder="0.00"
                        value={financialData.fixedAssets}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, fixedAssets: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="inventory">Inventory</Label>
                      <Input
                        id="inventory"
                        type="number"
                        placeholder="0.00"
                        value={financialData.inventory}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, inventory: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="cashAndEquivalents">Cash & Equivalents</Label>
                      <Input
                        id="cashAndEquivalents"
                        type="number"
                        placeholder="0.00"
                        value={financialData.cashAndEquivalents}
                        onChange={(e) =>
                          setFinancialData({
                            ...financialData,
                            cashAndEquivalents: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="totalLiabilities">Total Liabilities</Label>
                      <Input
                        id="totalLiabilities"
                        type="number"
                        placeholder="0.00"
                        value={financialData.totalLiabilities}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, totalLiabilities: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="currentLiabilities">Current Liabilities</Label>
                      <Input
                        id="currentLiabilities"
                        type="number"
                        placeholder="0.00"
                        value={financialData.currentLiabilities}
                        onChange={(e) =>
                          setFinancialData({
                            ...financialData,
                            currentLiabilities: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="longTermDebt">Long Term Debt</Label>
                      <Input
                        id="longTermDebt"
                        type="number"
                        placeholder="0.00"
                        value={financialData.longTermDebt}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, longTermDebt: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="shareholderEquity">Shareholder Equity</Label>
                      <Input
                        id="shareholderEquity"
                        type="number"
                        placeholder="0.00"
                        value={financialData.shareholderEquity}
                        onChange={(e) =>
                          setFinancialData({
                            ...financialData,
                            shareholderEquity: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Additional Information</h4>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="numberOfEmployees">Number of Employees</Label>
                      <Input
                        id="numberOfEmployees"
                        type="number"
                        placeholder="0"
                        value={financialData.numberOfEmployees}
                        onChange={(e) =>
                          setFinancialData({
                            ...financialData,
                            numberOfEmployees: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea
                        id="notes"
                        placeholder="Add any additional notes about these financials..."
                        value={financialData.notes}
                        onChange={(e) =>
                          setFinancialData({ ...financialData, notes: e.target.value })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={handleSaveFinancials}
                    disabled={createFinancialMutation.isPending}
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Financial Data
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowFinancialForm(false)}
                    disabled={createFinancialMutation.isPending}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Saved Financial Data */}
          {savedFinancials && savedFinancials.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Saved Financial Data</CardTitle>
                <CardDescription>Manually entered financial information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {savedFinancials.map((financial: any) => (
                  <div key={financial.id} className="border-b last:border-b-0 pb-6 last:pb-0">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-lg">{financial.accountsYear}</h4>
                      {financial.accountsPeriodEnd && (
                        <p className="text-sm text-muted-foreground">
                          Period End: {new Date(financial.accountsPeriodEnd).toLocaleDateString()}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {financial.revenue && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Revenue</p>
                          <p className="text-lg font-semibold">
                            {formatCurrency(financial.revenue)}
                          </p>
                        </div>
                      )}
                      {financial.profitAfterTax && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">
                            Profit After Tax
                          </p>
                          <p className="text-lg font-semibold">
                            {formatCurrency(financial.profitAfterTax)}
                          </p>
                        </div>
                      )}
                      {financial.totalAssets && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Total Assets</p>
                          <p className="text-lg font-semibold">
                            {formatCurrency(financial.totalAssets)}
                          </p>
                        </div>
                      )}
                      {financial.totalLiabilities && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">
                            Total Liabilities
                          </p>
                          <p className="text-lg font-semibold">
                            {formatCurrency(financial.totalLiabilities)}
                          </p>
                        </div>
                      )}
                      {financial.shareholderEquity && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">
                            Shareholder Equity
                          </p>
                          <p className="text-lg font-semibold">
                            {formatCurrency(financial.shareholderEquity)}
                          </p>
                        </div>
                      )}
                      {financial.numberOfEmployees && (
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Employees</p>
                          <p className="text-lg font-semibold">{financial.numberOfEmployees}</p>
                        </div>
                      )}
                    </div>

                    {financial.notes && (
                      <div className="mt-4 p-3 bg-muted rounded-lg">
                        <p className="text-sm font-medium text-muted-foreground mb-1">Notes</p>
                        <p className="text-sm">{financial.notes}</p>
                      </div>
                    )}

                    <p className="text-xs text-muted-foreground mt-4">
                      Added on {new Date(financial.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

