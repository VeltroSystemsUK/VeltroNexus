# DueDiligence Platform User Guide

**First Enterprise Inclusive Lending**

---

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Due Diligence Checklist](#due-diligence-checklist)
4. [Calculator Tools](#calculator-tools)
   - [DSCR Calculator](#dscr-calculator)
   - [Loan Calculator](#loan-calculator)
   - [Affordability Estimator](#affordability-estimator)
   - [Financial Ratios Calculator](#financial-ratios-calculator)
5. [Assessment Tools](#assessment-tools)
   - [Character Assessor](#character-assessor)
   - [Loan Purpose Assessment](#loan-purpose-assessment)
6. [Exporting Results](#exporting-results)
7. [Best Practices](#best-practices)

---

## Introduction

The DueDiligence platform is a comprehensive loan assessment and management system designed for First Enterprise Inclusive Lending. It provides a structured approach to evaluating loan applications through integrated checklists, financial calculators, and assessment tools.

### Key Features

- **56-item Due Diligence Checklist** across 11 key sections
- **6 Specialized Calculator and Assessment Tools**
- **PDF Report Generation** for checklist completion
- **Export Functionality** for all calculations and assessments (Text and HTML formats)
- **Real-time Progress Tracking** and validation

---

## Getting Started

### Accessing the Platform

1. Navigate to the DueDiligence homepage
2. You'll see the First Enterprise logo and platform overview
3. Choose from the available tools based on your assessment needs

### Navigation

- **Home Button**: Returns you to the main dashboard
- **Tool Cards**: Click "Open" or "Start Checklist" to access each tool
- **Back Arrows**: Return to the previous page within each tool

---

## Due Diligence Checklist

The checklist is the core of the platform, covering 56 essential items across 11 sections.

### Checklist Sections

1. **Application Validation** - Verify applicant eligibility and loan terms
2. **Documentation & KYC** - Complete identity and financial verification
3. **Financial Review** - Analyze accounts and cashflow forecasts
4. **Credit & Governance** - Review credit ratings and director checks
5. **Capacity Assessment** - Evaluate repayment ability and DSCR
6. **Loan Structure** - Confirm loan-to-cost ratios and contributions
7. **Repayment Analysis** - Assess payment schedules and stress testing
8. **Insurance & Compliance** - Verify insurance coverage and regulatory compliance
9. **Recommendation Integrity** - Ensure proper documentation and approvals
10. **Administrative Requirements** - Complete database entries and forms
11. **Supporting Documentation** - Gather business plans, CVs, and company searches

### How to Use the Checklist

1. Click **"Start Checklist"** from the homepage
2. Review each section in the tabulated format
3. For each item:
   - Select **Status** (Yes/No/N/A) from the dropdown
   - Add **Notes** in the text field for additional context
4. Track your progress with the real-time completion percentage at the top
5. Complete all required items
6. Click **"Generate PDF Report"** to download a comprehensive summary

### Checklist Best Practices

- Complete items in order for a logical flow
- Use the Notes field to document evidence sources (e.g., "Verified via SOAR ref #12345")
- Mark items as "N/A" only when genuinely not applicable
- Generate the PDF report before closing to preserve your work
- Review the PDF for completeness before submitting for approval

---

## Calculator Tools

### DSCR Calculator

**Purpose**: Calculate Debt Service Coverage Ratio to assess loan repayment capacity.

#### How to Use

1. Navigate to **DSCR Calculator** from the homepage
2. Enter **Net Operating Income (NOI)** - Annual business income after operating expenses
3. Enter **Total Debt Service** - Annual loan payments (principal + interest)
4. Click **"Calculate DSCR"**

#### Understanding Results

- **DSCR = NOI ÷ Total Debt Service**
- **Excellent** (≥ 1.5): Strong repayment capacity
- **Good** (1.25-1.49): Acceptable repayment capacity
- **Acceptable** (1.0-1.24): Minimum acceptable level
- **Below Threshold** (< 1.0): Insufficient income to cover debt

#### Sensitivity Analysis

The calculator automatically performs a -20% revenue stress test to assess resilience under adverse conditions.

#### Export Options

- **Text Format**: Plain text for easy copy-paste
- **HTML Format**: Formatted document with color-coded results

---

### Loan Calculator

**Purpose**: Calculate monthly payments, total interest, and payment breakdown for any loan.

#### How to Use

1. Navigate to **Loan Calculator**
2. Enter **Loan Amount** (£)
3. Enter **Annual Interest Rate** (%)
   - Note: Typically BoE base rate + margin (2-8% total)
4. Enter **Loan Term** (years, maximum 5 years for commercial loans)
5. Click **"Calculate"**

#### Understanding Results

- **Monthly Payment**: Fixed amount due each month
- **Total Interest**: Total interest paid over loan term
- **Total Repayment**: Loan amount + total interest
- **Payment Breakdown**: Principal vs. interest components

#### Use Cases

- Quote monthly payments to applicants
- Compare different loan structures
- Calculate total cost of borrowing
- Assess affordability against business income

---

### Affordability Estimator

**Purpose**: Assess whether a business can afford proposed loan payments based on income and costs.

#### How to Use

1. Navigate to **Affordability Estimator**
2. Enter **Annual Business Revenue** (£)
3. Enter **Annual Operating Costs** (£)
4. Enter **Proposed Monthly Loan Payment** (£)
5. For refinancing scenarios:
   - Toggle **"Refinancing Scenario"** switch
   - Enter **Existing Monthly Loan Payment** (£) being refinanced
6. Click **"Calculate Affordability"**

#### Understanding Results

- **Net Operating Income (NOI)**: Revenue - Operating Costs
- **Annual Debt Service**: Monthly payment × 12
- **DSCR**: NOI ÷ Annual Debt Service
- **Affordability Rating**: Based on DSCR thresholds

#### Refinancing Logic

When refinancing is enabled, the existing loan payment is added back to NOI because that payment will cease once refinanced. This shows the true capacity to service the new loan.

**Example**:
- Base NOI: £70,000
- Existing payment: £1,800/month (£21,600/year)
- Adjusted NOI: £91,600
- This increases DSCR and borrowing capacity

---

### Financial Ratios Calculator

**Purpose**: Calculate three key financial health indicators.

#### How to Use

1. Navigate to **Financial Ratios**
2. Enter the following from the business's financial statements:
   - **Current Assets** (£)
   - **Inventory** (£)
   - **Current Liabilities** (£)
   - **Net Income** (£)
   - **Total Assets** (£)
   - **Total Debt** (£)
   - **Net Worth** (£)
3. Click **"Calculate Financial Ratios"**

#### Understanding Results

**1. Acid Test Ratio (Quick Ratio)**
- Formula: (Current Assets - Inventory) ÷ Current Liabilities
- Measures immediate liquidity without selling inventory
- **Good**: ≥ 1.0
- **Acceptable**: 0.5-1.0
- **Weak**: < 0.5

**2. Return on Assets (ROA)**
- Formula: Net Income ÷ Total Assets × 100%
- Measures how efficiently assets generate profit
- **Excellent**: ≥ 10%
- **Good**: 5-10%
- **Fair**: 0-5%
- **Poor**: < 0%

**3. Debt to Net Worth**
- Formula: Total Debt ÷ Net Worth
- Measures financial leverage and risk exposure
- **Good**: ≤ 1.0 (more equity than debt)
- **Acceptable**: 1.0-2.0 (moderate leverage)
- **High Risk**: > 2.0 (debt exceeds equity significantly)

#### Use Cases

- Assess overall financial health
- Identify liquidity concerns
- Evaluate profitability efficiency
- Determine appropriate leverage levels

---

## Assessment Tools

### Character Assessor

**Purpose**: Evaluate the character and integrity of business owners across 24 criteria.

#### How to Use

1. Navigate to **Character Assessor**
2. Work through 5 categories of questions:
   - **Business History & Track Record** (4 questions)
   - **Financial Conduct** (5 questions)
   - **Professional Reputation** (5 questions)
   - **Personal Integrity** (5 questions)
   - **Commitment & Stability** (5 questions)
3. For each question:
   - Select a **Rating**: Excellent, Good, Satisfactory, Concerning, or Poor
   - Add **Comments** to document evidence and observations
4. Track progress at the top of the page

#### Understanding Results

The assessment calculates an overall score (0-100) based on all ratings:

- **80-100: STRONG** - Excellent character, recommend approval
- **65-79: ACCEPTABLE** - Generally positive, minor concerns
- **50-64: MARGINAL** - Moderate concerns, additional due diligence needed
- **Below 50: WEAK** - Significant concerns, recommend decline

Category scores are also displayed to identify specific strengths or weaknesses.

#### Best Practices

- Document all sources of information in comments
- Be objective and evidence-based in ratings
- Consider both positive and negative indicators
- Use "Concerning" or "Poor" ratings when red flags exist
- Complete all questions for accurate scoring

---

### Loan Purpose Assessment

**Purpose**: Comprehensively evaluate and document the intended use of loan funds.

#### How to Use

1. Navigate to **Loan Purpose**
2. Complete 6 sections:

**Section 1: Basic Information**
- Select **Purpose Category** (Working Capital, Equipment, Expansion, etc.)
- Describe **Specific Purpose**
- Enter **Loan Amount** (£)

**Section 2: Business Case**
- Describe **Current Situation**
- Explain **Problem/Opportunity**
- Detail **Proposed Solution**

**Section 3: Financial Justification**
- Enter **Expected Revenue/Benefit** (£)
- Enter **Expected Costs** (£)
- Specify **Payback Period**

**Section 4: Implementation Plan**
- Outline **Timeline**
- List **Key Milestones**
- Identify **Suppliers/Partners**

**Section 5: Risk Assessment**
- Identify **Potential Risks**
- Describe **Mitigation Strategies**
- Outline **Alternative Plans**

**Section 6: Supporting Evidence**
- Summarize **Market Research**
- Attach **Quotes/Estimates**
- Provide **Competitor Analysis**

3. Track completion percentage at the top
4. Review the assessment summary (appears at 80% completion)

#### Understanding Results

**ROI Calculation**: (Expected Revenue - Expected Costs) ÷ Loan Amount × 100%

**Viability Ratings**:
- **Strong Viability** (Score ≥ 75): Well-justified, recommend approval
- **Acceptable Viability** (Score 50-74): Adequately justified, proceed with standard due diligence
- **Moderate Concerns** (Score 25-49): Gaps identified, request additional information
- **Weak Viability** (Score < 25): Insufficient justification, recommend decline

#### Best Practices

- Be specific and detailed in all responses
- Provide quantitative data where possible
- Address potential concerns proactively
- Include realistic timelines and milestones
- Document all assumptions clearly

---

## Exporting Results

All calculator and assessment tools support exporting results in two formats.

### Export Formats

**1. Text Format (.txt)**
- Plain text document
- Easy to copy and paste into any application
- Preserves all data and calculations
- Professional formatting with headers and sections

**2. HTML Format (.html)**
- Formatted document with styling
- Color-coded results and ratings
- Tables for structured data
- Can be opened in Word or any web browser
- Maintains formatting when pasted into Word

### How to Export

1. Complete your calculation or assessment
2. Scroll to the **"Export Results"** or **"Export Assessment"** section
3. Click either:
   - **"Download as Text"** for plain text format
   - **"Download as HTML"** for formatted document
4. File will download with date stamp in filename
5. Open in your preferred application

### Export Best Practices

- Export immediately after completing assessments
- Use HTML format for formal reports and presentations
- Use Text format for quick reference or email
- Include exports in loan application documentation
- Archive exports for audit trail and compliance

---

## Best Practices

### Workflow Recommendations

**1. Start with the Checklist**
- Begin every loan assessment with the due diligence checklist
- Use it as a roadmap for gathering required information
- Mark items as complete as you progress

**2. Use Calculators for Validation**
- Run DSCR and Affordability calculations early
- Use Financial Ratios to assess overall health
- Compare Loan Calculator results with applicant expectations

**3. Complete Assessments Thoroughly**
- Character Assessor should be completed after initial meetings
- Loan Purpose Assessment should be done before credit committee
- Export all results for committee review

**4. Document Everything**
- Use Notes fields extensively
- Export all calculations and assessments
- Generate PDF reports for permanent records

### Quality Assurance

- **Double-check all numerical inputs** for accuracy
- **Review exported documents** before submitting
- **Cross-reference** checklist items with calculator results
- **Validate** DSCR calculations against financial statements
- **Ensure** all sections are complete before generating final reports

### Compliance and Audit

- **Maintain** complete audit trail through exports
- **Archive** all PDF reports and exported assessments
- **Document** decision rationale in Notes fields
- **Review** checklist completion before loan approval
- **Store** all exports with loan application files

---

## Support and Feedback

For technical support, feature requests, or feedback about the DueDiligence platform, please contact First Enterprise Inclusive Lending.

---

**Document Version**: 1.0  
**Last Updated**: October 2025  
**Platform**: DueDiligence by First Enterprise Inclusive Lending

