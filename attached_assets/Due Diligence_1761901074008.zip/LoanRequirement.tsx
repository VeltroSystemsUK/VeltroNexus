import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

interface LoanRequirementProps {
  prospectId: number;
  prospect: any;
}

const SECURITY_OPTIONS = [
  { id: "directors_guarantee", label: "Director's Guarantee" },
  { id: "debenture", label: "Debenture" },
  { id: "commercial_property", label: "Commercial Property" },
  { id: "parent_company_guarantee", label: "Parent Company Guarantee" },
  { id: "home_equity", label: "Home Equity" },
  { id: "collateral", label: "Collateral" },
  { id: "property_other", label: "Property (Other)" },
  { id: "cross_company_guarantee", label: "Cross Company Guarantee" },
];

export default function LoanRequirement({ prospectId, prospect }: LoanRequirementProps) {
  const [loanAmount, setLoanAmount] = useState(prospect.loanAmount ? (prospect.loanAmount / 100).toString() : "");
  const [loanTerm, setLoanTerm] = useState(prospect.loanTerm?.toString() || "60");
  const [interestRate, setInterestRate] = useState(prospect.interestRate ? (prospect.interestRate / 100).toString() : "17");
  const [security, setSecurity] = useState<string[]>(
    prospect.security ? JSON.parse(prospect.security) : []
  );
  const [loanNotes, setLoanNotes] = useState(prospect.loanNotes || "");
  const [isSaving, setIsSaving] = useState(false);

  const updateProspectMutation = trpc.prospects.update.useMutation({
    onSuccess: () => {
      toast.success("Loan requirement saved successfully");
      setIsSaving(false);
    },
    onError: (error) => {
      toast.error(`Failed to save: ${error.message}`);
      setIsSaving(false);
    },
  });

  const handleSecurityToggle = (securityId: string) => {
    setSecurity((prev) =>
      prev.includes(securityId)
        ? prev.filter((id) => id !== securityId)
        : [...prev, securityId]
    );
  };

  const handleSave = () => {
    if (!loanAmount || parseFloat(loanAmount) <= 0) {
      toast.error("Please enter a valid loan amount");
      return;
    }

    setIsSaving(true);
    updateProspectMutation.mutate({
      id: prospectId,
      loanAmount: Math.round(parseFloat(loanAmount) * 100), // Convert to pence
      loanPurpose: prospect.loanPurpose,
      loanTerm: parseInt(loanTerm),
      interestRate: Math.round(parseFloat(interestRate) * 100), // Convert to basis points
      security: JSON.stringify(security),
      loanNotes,
    });
  };

  // Calculate facility fee (3.5% of loan amount)
  const facilityFee = loanAmount ? Math.round(parseFloat(loanAmount) * 0.035) : 0;

  // Calculate monthly payment
  const calculateMonthlyPayment = () => {
    if (!loanAmount || !loanTerm || !interestRate) return 0;

    const principal = parseFloat(loanAmount);
    const months = parseInt(loanTerm);
    const monthlyRate = parseFloat(interestRate) / 100 / 12;

    if (monthlyRate === 0) return principal / months;

    const monthlyPayment =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
      (Math.pow(1 + monthlyRate, months) - 1);

    return Math.round(monthlyPayment * 100) / 100;
  };

  const monthlyPayment = calculateMonthlyPayment();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-1">Loan Requirement</h3>
        <p className="text-sm text-muted-foreground">
          Specify the loan details for this prospect.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="loanAmount">Loan Amount (£)</Label>
          <Input
            id="loanAmount"
            type="number"
            value={loanAmount}
            onChange={(e) => setLoanAmount(e.target.value)}
            placeholder="150000"
            min={0}
            step={1000}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="loanTerm">Term (Months)</Label>
          <Input
            id="loanTerm"
            type="number"
            value={loanTerm}
            onChange={(e) => setLoanTerm(e.target.value)}
            placeholder="60"
            min={1}
            max={60}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="interestRate">Interest Rate (APR %)</Label>
          <Input
            id="interestRate"
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            placeholder="17"
            min={0}
            max={100}
            step={0.1}
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label>Security</Label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SECURITY_OPTIONS.map((option) => (
            <div key={option.id} className="flex items-center space-x-2">
              <Checkbox
                id={option.id}
                checked={security.includes(option.id)}
                onCheckedChange={() => handleSecurityToggle(option.id)}
              />
              <Label htmlFor={option.id} className="cursor-pointer font-normal">
                {option.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="loanNotes">Notes</Label>
        <Textarea
          id="loanNotes"
          value={loanNotes}
          onChange={(e) => setLoanNotes(e.target.value)}
          placeholder="e.g., Looking to Refinance £E120,000 with GOT Capital & Capify"
          rows={4}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Calculated Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Facility Fee (3.5%):</span>
            <span className="font-semibold">
              {new Intl.NumberFormat("en-GB", {
                style: "currency",
                currency: "GBP",
                minimumFractionDigits: 2,
              }).format(facilityFee)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Estimated Monthly Payment:</span>
            <span className="font-semibold">
              {new Intl.NumberFormat("en-GB", {
                style: "currency",
                currency: "GBP",
                minimumFractionDigits: 2,
              }).format(monthlyPayment)}
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save Loan Requirement"}
        </Button>
      </div>
    </div>
  );
}

