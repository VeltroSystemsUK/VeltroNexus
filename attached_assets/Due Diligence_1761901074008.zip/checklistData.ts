export interface ChecklistItem {
  id: number;
  section: string;
  item: string;
}

export const CHECKLIST_SECTIONS = [
  "Application Validation",
  "Documentation & KYC",
  "Financial Review",
  "Credit & Governance",
  "Business Planning & Capacity",
  "Administrative Requirements",
  "Loan Structure & Security",
  "Repayment & Affordability",
  "Insurance & Compliance",
  "Bank Statement Analysis",
  "Final Review & Recommendation"
] as const;

export const CHECKLIST_ITEMS: ChecklistItem[] = [
  // Application Validation
  { id: 1, section: "Application Validation", item: "SOAR linked. Openbanking, Soft Credit Search & KYC" },
  { id: 2, section: "Application Validation", item: "Applicant(s) aged 18+, business domiciled in England or MEIF LEP areas (E Mids min 18 months)" },
  { id: 3, section: "Application Validation", item: "Loan amount criteria and security requirements met per latest Loan Fund Update Document" },
  { id: 4, section: "Application Validation", item: "Loan < 90% of total project cost, contribution > 10% (15% for existing businesses)" },
  { id: 5, section: "Application Validation", item: "Purpose not excluded (no property development, crypto, gambling, or lending activity)" },
  { id: 6, section: "Application Validation", item: "Evidence of bank decline held" },
  
  // Documentation & KYC
  { id: 7, section: "Documentation & KYC", item: "Signed and fully completed application form with wet signature" },
  { id: 8, section: "Documentation & KYC", item: "Full loan application and Adviser Summary completed" },
  { id: 9, section: "Documentation & KYC", item: "6 months bank statements (business/personal) reviewed with conduct commentary" },
  { id: 10, section: "Documentation & KYC", item: "Photographic ID (passport or certified UK citizen ID) and proof of address (utility bill)" },
  { id: 11, section: "Documentation & KYC", item: "Non-EU passport must show leave to remain in UK for at least loan term" },
  { id: 12, section: "Documentation & KYC", item: "Credit search (3 years, all addresses, max 1 month old) authorised and reviewed" },
  { id: 13, section: "Documentation & KYC", item: "Adverse data or voter-roll absence commented with mitigation" },
  { id: 14, section: "Documentation & KYC", item: "If Limited Co – Companies House search obtained and commented" },
  
  // Financial Review
  { id: 15, section: "Financial Review", item: "Financial Accounts Reviewed and checked for Notes to Accounts" },
  { id: 16, section: "Financial Review", item: "3 years trading accounts (or management accounts if not traded that long)" },
  { id: 17, section: "Financial Review", item: "If no accounts available – recent tax returns held to evidence turnover/drawings" },
  { id: 18, section: "Financial Review", item: "Management accounts (YTD) reviewed" },
  { id: 19, section: "Financial Review", item: "1 year cashflow forecast and Business Liabilities Form completed" },
  { id: 20, section: "Financial Review", item: "Cashflow forecast includes VAT, PAYE, CT, and loan repayments" },
  { id: 21, section: "Financial Review", item: "Debtor book ageing < 90 days (or mitigation explained)" },
  { id: 22, section: "Financial Review", item: "Associate balances explained and recoverable" },
  { id: 23, section: "Financial Review", item: "Personal Statement of Assets & Liabilities for each Director" },
  
  // Credit & Governance
  { id: 24, section: "Credit & Governance", item: "D&B / Experian corporate rating and PAYDEX obtained" },
  { id: 25, section: "Credit & Governance", item: "Director(s) – no CCJs, verified via CRA" },
  { id: 26, section: "Credit & Governance", item: "Bank conduct acceptable (no unpaid items, excesses, or persistent overdrafts)" },
  
  // Business Planning & Capacity
  { id: 27, section: "Business Planning & Capacity", item: "Business plan held" },
  { id: 28, section: "Business Planning & Capacity", item: "CV for each director (if not included in Business plan)" },
  { id: 29, section: "Business Planning & Capacity", item: "Management experience documented (role & tenure)" },
  { id: 30, section: "Business Planning & Capacity", item: "Active contracts tabled (Client | Value | Start | End | Status)" },
  { id: 31, section: "Business Planning & Capacity", item: "Renewals evidenced as scope expansions, not new clients" },
  
  // Administrative Requirements
  { id: 32, section: "Administrative Requirements", item: "Customer Charter given out" },
  { id: 33, section: "Administrative Requirements", item: "Client Perception form given out" },
  { id: 34, section: "Administrative Requirements", item: "Client details fully entered on database (inc Action Plan, notes, timesheet)" },
  { id: 35, section: "Administrative Requirements", item: "Client Contact Form signed and completed (or signed Action Plan, or email chains)" },
  { id: 36, section: "Administrative Requirements", item: "Action plan completed and signed by client" },
  
  // Loan Structure & Security
  { id: 37, section: "Loan Structure & Security", item: "Loan fund type (RGF, ELEM 2, MEIF II, RLS) confirmed" },
  { id: 38, section: "Loan Structure & Security", item: "If RLS facility – Location Questionnaire and RLS Provisional Eligibility Assessment attached" },
  { id: 39, section: "Loan Structure & Security", item: "Personal Guarantee % within policy (35–100%)" },
  { id: 40, section: "Loan Structure & Security", item: "If secured lending – mortgage statement confirms borrowings against property offered" },
  { id: 41, section: "Loan Structure & Security", item: "If secured lending – sufficient equity (min 80% of available equity per Zoopla valuation)" },
  { id: 42, section: "Loan Structure & Security", item: "Debenture or security justified if taken" },
  { id: 43, section: "Loan Structure & Security", item: "Legal advice/waiver obtained from guarantor(s)" },
  
  // Repayment & Affordability
  { id: 44, section: "Repayment & Affordability", item: "Forecast CFF reconciles to accounts and bank statements" },
  { id: 45, section: "Repayment & Affordability", item: "DSCR ≥ 1.5× base; sensitivity –20% revenue ≥ 1.0×" },
  { id: 46, section: "Repayment & Affordability", item: "Director personal income vs. commitments ratio ≥ 1.25×" },
  
  // Insurance & Compliance
  { id: 47, section: "Insurance & Compliance", item: "Public Liability £10m, Employer £10m, PI £2m, renewal date verified" },
  { id: 48, section: "Insurance & Compliance", item: "VAT registration confirmed" },
  { id: 49, section: "Insurance & Compliance", item: "Licence or certification (e.g., CAA) valid for loan term" },
  
  // Bank Statement Analysis
  { id: 50, section: "Bank Statement Analysis", item: "Three-month bank narrative log completed" },
  { id: 51, section: "Bank Statement Analysis", item: "All recurring credits/debits categorised" },
  { id: 52, section: "Bank Statement Analysis", item: "Internal Bank Transfers identified/flagged" },
  
  // Final Review & Recommendation
  { id: 53, section: "Final Review & Recommendation", item: "Eligibility confirmed and all required documents present" },
  { id: 54, section: "Final Review & Recommendation", item: "Due diligence undertaken and relevant section on adviser summary completed" },
  { id: 55, section: "Final Review & Recommendation", item: "Adviser conclusion signed and dated" },
  { id: 56, section: "Final Review & Recommendation", item: "Loan amount, term, and interest rate consistent with fund terms" }
];

