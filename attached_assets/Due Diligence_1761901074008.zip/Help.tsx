import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, BookOpen, Calculator, CheckSquare, FileText, TrendingUp, Users, Search, ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQ_ITEMS = [
  {
    question: "How do I start a due diligence assessment?",
    answer: "Click 'Start Checklist' from the homepage to begin the 56-item due diligence checklist. Work through each section, marking items as Yes/No/N/A and adding notes. Your progress is tracked in real-time at the top of the page."
  },
  {
    question: "What is DSCR and how is it calculated?",
    answer: "DSCR (Debt Service Coverage Ratio) measures a business's ability to service debt. It's calculated as: Net Operating Income ÷ Total Debt Service. A DSCR of 1.5+ is excellent, 1.25-1.49 is good, 1.0-1.24 is acceptable, and below 1.0 indicates insufficient income to cover debt payments."
  },
  {
    question: "How does the refinancing scenario work in the Affordability Estimator?",
    answer: "When refinancing is enabled, the existing monthly loan payment is added back to your Net Operating Income. This is because that payment will cease once refinanced, showing your true capacity to service the new loan. For example, if NOI is £70,000 and existing payments are £21,600/year, adjusted NOI becomes £91,600."
  },
  {
    question: "Can I export my calculations and assessments?",
    answer: "Yes! All calculator and assessment tools have export functionality. After completing a calculation or assessment, scroll to the 'Export Results' section and choose either 'Download as Text' (plain text) or 'Download as HTML' (formatted document). Both formats are suitable for pasting into Word documents."
  },
  {
    question: "What's the difference between the Character Assessor and Loan Purpose Assessment?",
    answer: "The Character Assessor evaluates the business owner's integrity, track record, and reliability across 24 questions in 5 categories. The Loan Purpose Assessment evaluates the business case for the loan itself—why the funds are needed, expected ROI, implementation plan, and risks."
  },
  {
    question: "How do I generate a PDF report from the checklist?",
    answer: "Complete all required items in the checklist (or as many as possible), then click the 'Generate PDF Report' button at the bottom of the checklist page. The PDF will include all completed items, your notes, and completion statistics."
  },
  {
    question: "What are the three financial ratios calculated?",
    answer: "1) Acid Test Ratio (liquidity): (Current Assets - Inventory) ÷ Current Liabilities. 2) Return on Assets (profitability): Net Income ÷ Total Assets × 100%. 3) Debt to Net Worth (leverage): Total Debt ÷ Net Worth. Each ratio has specific benchmarks for good, acceptable, and concerning levels."
  },
  {
    question: "What loan term should I use for commercial loans?",
    answer: "The calculators are configured for commercial loans with a maximum term of 5 years. Interest rates typically range from 2-8% (BoE base rate + margin). Always verify current rates and terms with your lending policy."
  },
  {
    question: "How is the Character Assessment score calculated?",
    answer: "Each rating has a point value: Excellent (5), Good (4), Satisfactory (3), Concerning (2), Poor (1). The overall score is calculated as (Total Points ÷ Maximum Possible Points) × 100. Scores: 80-100 = Strong, 65-79 = Acceptable, 50-64 = Marginal, Below 50 = Weak."
  },
  {
    question: "What should I do if I need to pause my assessment?",
    answer: "Unfortunately, the current version doesn't save progress automatically. We recommend exporting your results frequently or completing assessments in one session. For the checklist, generate a PDF report before closing to preserve your work."
  }
];

const QUICK_LINKS = [
  { title: "Due Diligence Checklist", href: "#checklist", icon: CheckSquare },
  { title: "Calculator Tools", href: "#calculators", icon: Calculator },
  { title: "Assessment Tools", href: "#assessments", icon: Users },
  { title: "Exporting Results", href: "#exporting", icon: TrendingUp },
  { title: "Best Practices", href: "#best-practices", icon: FileText }
];

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const filteredFAQs = FAQ_ITEMS.filter(faq =>
    searchQuery === "" ||
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-6xl">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="mb-8 text-center">
          <div className="flex justify-center mb-4">
            <BookOpen className="h-16 w-16 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-2">User Guide</h1>
          <p className="text-xl text-muted-foreground">
            Comprehensive guide to using the DueDiligence platform
          </p>
        </div>

        {/* Search Bar */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search help topics, FAQs, and guides..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Quick Navigation</CardTitle>
            <CardDescription>Jump to specific sections</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {QUICK_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="flex flex-col items-center gap-2 p-4 rounded-lg border hover:bg-accent hover:border-primary transition-colors"
                >
                  <link.icon className="h-5 w-5 text-primary" />
                  <span className="text-xs text-center font-medium">{link.title}</span>
                </a>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription>
              {searchQuery ? `${filteredFAQs.length} results found` : "Common questions and answers"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="multiple" className="w-full">
              {filteredFAQs.map((faq, index) => (
                <AccordionItem key={index} value={`faq-${index}`}>
                  <AccordionTrigger className="text-left">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">{faq.answer}</p>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            {filteredFAQs.length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No results found for "{searchQuery}". Try different keywords.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {/* Introduction */}
          <Card id="introduction">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Introduction
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <p>
                The DueDiligence platform is a comprehensive loan assessment and management system designed for 
                First Enterprise Inclusive Lending. It provides a structured approach to evaluating loan applications 
                through integrated checklists, financial calculators, and assessment tools.
              </p>
              <h3 className="font-semibold mt-4 mb-2">Key Features</h3>
              <ul className="list-disc list-inside space-y-1">
                <li><strong>56-item Due Diligence Checklist</strong> across 11 key sections</li>
                <li><strong>6 Specialized Calculator and Assessment Tools</strong></li>
                <li><strong>PDF Report Generation</strong> for checklist completion</li>
                <li><strong>Export Functionality</strong> for all calculations and assessments (Text and HTML formats)</li>
                <li><strong>Real-time Progress Tracking</strong> and validation</li>
              </ul>
            </CardContent>
          </Card>

          {/* Due Diligence Checklist */}
          <Card id="checklist">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckSquare className="h-5 w-5" />
                Due Diligence Checklist
              </CardTitle>
              <CardDescription>56 essential items across 11 sections</CardDescription>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <h3 className="font-semibold mb-2">Checklist Sections</h3>
              <ol className="list-decimal list-inside space-y-1 mb-4">
                <li>Application Validation - Verify applicant eligibility and loan terms</li>
                <li>Documentation & KYC - Complete identity and financial verification</li>
                <li>Financial Review - Analyze accounts and cashflow forecasts</li>
                <li>Credit & Governance - Review credit ratings and director checks</li>
                <li>Capacity Assessment - Evaluate repayment ability and DSCR</li>
                <li>Loan Structure - Confirm loan-to-cost ratios and contributions</li>
                <li>Repayment Analysis - Assess payment schedules and stress testing</li>
                <li>Insurance & Compliance - Verify insurance coverage and regulatory compliance</li>
                <li>Recommendation Integrity - Ensure proper documentation and approvals</li>
                <li>Administrative Requirements - Complete database entries and forms</li>
                <li>Supporting Documentation - Gather business plans, CVs, and company searches</li>
              </ol>
              
              <h3 className="font-semibold mb-2">How to Use</h3>
              <ol className="list-decimal list-inside space-y-1 mb-4">
                <li>Click "Start Checklist" from the homepage</li>
                <li>Review each section in the tabulated format</li>
                <li>For each item: Select Status (Yes/No/N/A) and add Notes</li>
                <li>Track your progress with the real-time completion percentage</li>
                <li>Click "Generate PDF Report" to download a comprehensive summary</li>
              </ol>

              <div className="bg-blue-50 border border-blue-200 rounded p-4 mt-4">
                <p className="font-semibold mb-2">💡 Best Practices</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Complete items in order for a logical flow</li>
                  <li>Use the Notes field to document evidence sources</li>
                  <li>Mark items as "N/A" only when genuinely not applicable</li>
                  <li>Generate the PDF report before closing to preserve your work</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Calculator Tools */}
          <Card id="calculators">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Calculator Tools
              </CardTitle>
              <CardDescription>Financial analysis and calculation tools</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* DSCR Calculator */}
              <div>
                <h3 className="font-semibold text-lg mb-2">DSCR Calculator</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Calculate Debt Service Coverage Ratio to assess loan repayment capacity.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-2 text-sm">
                  <p><strong>Formula:</strong> DSCR = Net Operating Income ÷ Total Debt Service</p>
                  <p><strong>Inputs:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Net Operating Income (NOI) - Annual business income after operating expenses</li>
                    <li>Total Debt Service - Annual loan payments (principal + interest)</li>
                  </ul>
                  <p><strong>Rating Scale:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Excellent: ≥ 1.5</li>
                    <li>Good: 1.25-1.49</li>
                    <li>Acceptable: 1.0-1.24</li>
                    <li>Below Threshold: &lt; 1.0</li>
                  </ul>
                  <p className="text-xs italic mt-2">
                    The calculator automatically performs a -20% revenue stress test.
                  </p>
                </div>
              </div>

              {/* Loan Calculator */}
              <div>
                <h3 className="font-semibold text-lg mb-2">Loan Calculator</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Calculate monthly payments, total interest, and payment breakdown.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-2 text-sm">
                  <p><strong>Inputs:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Loan Amount (£)</li>
                    <li>Annual Interest Rate (%) - Typically BoE base rate + margin (2-8% total)</li>
                    <li>Loan Term (years, maximum 5 years for commercial loans)</li>
                  </ul>
                  <p><strong>Results:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Monthly Payment - Fixed amount due each month</li>
                    <li>Total Interest - Total interest paid over loan term</li>
                    <li>Payment Breakdown - Principal vs. interest components</li>
                  </ul>
                </div>
              </div>

              {/* Affordability Estimator */}
              <div>
                <h3 className="font-semibold text-lg mb-2">Affordability Estimator</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Assess whether a business can afford proposed loan payments.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-2 text-sm">
                  <p><strong>Inputs:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Annual Business Revenue (£)</li>
                    <li>Annual Operating Costs (£)</li>
                    <li>Proposed Monthly Loan Payment (£)</li>
                    <li>Existing Monthly Loan Payment (£) - For refinancing scenarios</li>
                  </ul>
                  <p><strong>Refinancing Logic:</strong></p>
                  <p className="ml-4 text-xs">
                    When refinancing is enabled, the existing loan payment is added back to NOI because 
                    that payment will cease once refinanced, showing true capacity to service the new loan.
                  </p>
                </div>
              </div>

              {/* Financial Ratios */}
              <div>
                <h3 className="font-semibold text-lg mb-2">Financial Ratios Calculator</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Calculate three key financial health indicators.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-3 text-sm">
                  <div>
                    <p className="font-semibold">1. Acid Test Ratio (Quick Ratio)</p>
                    <p className="text-xs">Formula: (Current Assets - Inventory) ÷ Current Liabilities</p>
                    <p className="text-xs">Good: ≥ 1.0 | Acceptable: 0.5-1.0 | Weak: &lt; 0.5</p>
                  </div>
                  <div>
                    <p className="font-semibold">2. Return on Assets (ROA)</p>
                    <p className="text-xs">Formula: Net Income ÷ Total Assets × 100%</p>
                    <p className="text-xs">Excellent: ≥ 10% | Good: 5-10% | Fair: 0-5% | Poor: &lt; 0%</p>
                  </div>
                  <div>
                    <p className="font-semibold">3. Debt to Net Worth</p>
                    <p className="text-xs">Formula: Total Debt ÷ Net Worth</p>
                    <p className="text-xs">Good: ≤ 1.0 | Acceptable: 1.0-2.0 | High Risk: &gt; 2.0</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Assessment Tools */}
          <Card id="assessments">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Assessment Tools
              </CardTitle>
              <CardDescription>Character and loan purpose evaluation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Character Assessor */}
              <div>
                <h3 className="font-semibold text-lg mb-2">Character Assessor</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Evaluate the character and integrity of business owners across 24 criteria.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-2 text-sm">
                  <p><strong>5 Assessment Categories:</strong></p>
                  <ul className="list-disc list-inside ml-4">
                    <li>Business History & Track Record (4 questions)</li>
                    <li>Financial Conduct (5 questions)</li>
                    <li>Professional Reputation (5 questions)</li>
                    <li>Personal Integrity (5 questions)</li>
                    <li>Commitment & Stability (5 questions)</li>
                  </ul>
                  <p><strong>Rating Scale:</strong> Excellent, Good, Satisfactory, Concerning, Poor</p>
                  <p><strong>Overall Score Interpretation:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs">
                    <li>80-100: STRONG - Recommend approval</li>
                    <li>65-79: ACCEPTABLE - Generally positive</li>
                    <li>50-64: MARGINAL - Additional due diligence needed</li>
                    <li>Below 50: WEAK - Recommend decline</li>
                  </ul>
                </div>
              </div>

              {/* Loan Purpose */}
              <div>
                <h3 className="font-semibold text-lg mb-2">Loan Purpose Assessment</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Comprehensively evaluate and document the intended use of loan funds.
                </p>
                <div className="bg-slate-50 rounded p-4 space-y-2 text-sm">
                  <p><strong>6 Assessment Sections:</strong></p>
                  <ol className="list-decimal list-inside ml-4">
                    <li>Basic Information - Purpose category, specific purpose, loan amount</li>
                    <li>Business Case - Current situation, problem/opportunity, proposed solution</li>
                    <li>Financial Justification - Expected revenue/costs, payback period, ROI</li>
                    <li>Implementation Plan - Timeline, milestones, suppliers/partners</li>
                    <li>Risk Assessment - Identified risks, mitigation, alternative plans</li>
                    <li>Supporting Evidence - Market research, quotes, competitor analysis</li>
                  </ol>
                  <p><strong>Viability Ratings:</strong></p>
                  <ul className="list-disc list-inside ml-4 text-xs">
                    <li>Strong Viability (≥75): Well-justified, recommend approval</li>
                    <li>Acceptable Viability (50-74): Adequately justified</li>
                    <li>Moderate Concerns (25-49): Request additional information</li>
                    <li>Weak Viability (&lt;25): Recommend decline</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exporting Results */}
          <Card id="exporting">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Exporting Results
              </CardTitle>
              <CardDescription>Download calculations and assessments</CardDescription>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none">
              <p>
                All calculator and assessment tools support exporting results in two formats:
              </p>
              
              <h3 className="font-semibold mt-4 mb-2">Export Formats</h3>
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-50 rounded p-4">
                  <p className="font-semibold mb-2">Text Format (.txt)</p>
                  <ul className="list-disc list-inside text-xs space-y-1">
                    <li>Plain text document</li>
                    <li>Easy copy-paste into any application</li>
                    <li>Professional formatting with headers</li>
                    <li>Preserves all data and calculations</li>
                  </ul>
                </div>
                <div className="bg-slate-50 rounded p-4">
                  <p className="font-semibold mb-2">HTML Format (.html)</p>
                  <ul className="list-disc list-inside text-xs space-y-1">
                    <li>Formatted document with styling</li>
                    <li>Color-coded results and ratings</li>
                    <li>Opens in Word or web browser</li>
                    <li>Maintains formatting when pasted</li>
                  </ul>
                </div>
              </div>

              <h3 className="font-semibold mb-2">How to Export</h3>
              <ol className="list-decimal list-inside space-y-1">
                <li>Complete your calculation or assessment</li>
                <li>Scroll to the "Export Results" or "Export Assessment" section</li>
                <li>Click either "Download as Text" or "Download as HTML"</li>
                <li>File downloads with date stamp in filename</li>
                <li>Open in your preferred application</li>
              </ol>

              <div className="bg-blue-50 border border-blue-200 rounded p-4 mt-4">
                <p className="font-semibold mb-2">💡 Export Best Practices</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Export immediately after completing assessments</li>
                  <li>Use HTML format for formal reports and presentations</li>
                  <li>Use Text format for quick reference or email</li>
                  <li>Include exports in loan application documentation</li>
                  <li>Archive exports for audit trail and compliance</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Best Practices */}
          <Card id="best-practices">
            <CardHeader>
              <CardTitle>Best Practices</CardTitle>
              <CardDescription>Recommended workflow and quality assurance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Workflow Recommendations</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>
                    <strong>Start with the Checklist</strong>
                    <p className="ml-6 text-xs text-muted-foreground">
                      Begin every loan assessment with the due diligence checklist. Use it as a roadmap 
                      for gathering required information.
                    </p>
                  </li>
                  <li>
                    <strong>Use Calculators for Validation</strong>
                    <p className="ml-6 text-xs text-muted-foreground">
                      Run DSCR and Affordability calculations early. Use Financial Ratios to assess 
                      overall health.
                    </p>
                  </li>
                  <li>
                    <strong>Complete Assessments Thoroughly</strong>
                    <p className="ml-6 text-xs text-muted-foreground">
                      Character Assessor should be completed after initial meetings. Loan Purpose 
                      Assessment should be done before credit committee.
                    </p>
                  </li>
                  <li>
                    <strong>Document Everything</strong>
                    <p className="ml-6 text-xs text-muted-foreground">
                      Use Notes fields extensively. Export all calculations and assessments. Generate 
                      PDF reports for permanent records.
                    </p>
                  </li>
                </ol>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Quality Assurance</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Double-check all numerical inputs for accuracy</li>
                  <li>Review exported documents before submitting</li>
                  <li>Cross-reference checklist items with calculator results</li>
                  <li>Validate DSCR calculations against financial statements</li>
                  <li>Ensure all sections are complete before generating final reports</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Compliance and Audit</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Maintain complete audit trail through exports</li>
                  <li>Archive all PDF reports and exported assessments</li>
                  <li>Document decision rationale in Notes fields</li>
                  <li>Review checklist completion before loan approval</li>
                  <li>Store all exports with loan application files</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Footer */}
          <Card className="bg-primary/5">
            <CardContent className="pt-6">
              <p className="text-center text-sm text-muted-foreground">
                <strong>DueDiligence Platform</strong> by First Enterprise Inclusive Lending
                <br />
                Document Version 1.0 | Last Updated: October 2025
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

