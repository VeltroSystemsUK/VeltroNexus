import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, UserCheck, AlertCircle, CheckCircle2, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";
import { Progress } from "@/components/ui/progress";

interface AssessmentItem {
  id: string;
  category: string;
  question: string;
  rating: string;
  comments: string;
}

const CATEGORIES = [
  "Business History & Track Record",
  "Financial Conduct",
  "Professional Reputation",
  "Personal Integrity",
  "Commitment & Stability"
];

const ASSESSMENT_QUESTIONS = [
  // Business History & Track Record
  { id: "bh1", category: "Business History & Track Record", question: "Previous business ownership experience (years and outcomes)" },
  { id: "bh2", category: "Business History & Track Record", question: "Track record of business successes and how failures were handled" },
  { id: "bh3", category: "Business History & Track Record", question: "Industry knowledge and relevant qualifications" },
  { id: "bh4", category: "Business History & Track Record", question: "Management capability and team leadership" },
  
  // Financial Conduct
  { id: "fc1", category: "Financial Conduct", question: "Personal credit history and payment behavior" },
  { id: "fc2", category: "Financial Conduct", question: "Business credit history and supplier payment record" },
  { id: "fc3", category: "Financial Conduct", question: "Tax compliance and HMRC payment history" },
  { id: "fc4", category: "Financial Conduct", question: "Previous loan/credit facility performance" },
  { id: "fc5", category: "Financial Conduct", question: "Transparency in financial dealings and disclosure" },
  
  // Professional Reputation
  { id: "pr1", category: "Professional Reputation", question: "Industry reputation and peer references" },
  { id: "pr2", category: "Professional Reputation", question: "Customer/client testimonials and satisfaction" },
  { id: "pr3", category: "Professional Reputation", question: "Regulatory compliance and licensing status" },
  { id: "pr4", category: "Professional Reputation", question: "Professional memberships and accreditations" },
  { id: "pr5", category: "Professional Reputation", question: "Online presence and reviews" },
  
  // Personal Integrity
  { id: "pi1", category: "Personal Integrity", question: "Honesty and transparency in application process" },
  { id: "pi2", category: "Personal Integrity", question: "Consistency between stated and verified information" },
  { id: "pi3", category: "Personal Integrity", question: "Willingness to provide documentation and references" },
  { id: "pi4", category: "Personal Integrity", question: "Ethical business practices and values" },
  { id: "pi5", category: "Personal Integrity", question: "Response to challenging questions and adverse information" },
  
  // Commitment & Stability
  { id: "cs1", category: "Commitment & Stability", question: "Length of time in current business/industry" },
  { id: "cs2", category: "Commitment & Stability", question: "Residential stability and community ties" },
  { id: "cs3", category: "Commitment & Stability", question: "Personal investment and financial commitment to business" },
  { id: "cs4", category: "Commitment & Stability", question: "Long-term business vision and planning" },
  { id: "cs5", category: "Commitment & Stability", question: "Family support and personal circumstances" }
];

export default function CharacterAssessor() {
  const [assessments, setAssessments] = useState<Record<string, AssessmentItem>>(
    ASSESSMENT_QUESTIONS.reduce((acc, q) => ({
      ...acc,
      [q.id]: { ...q, rating: "", comments: "" }
    }), {})
  );

  const handleRatingChange = (id: string, rating: string) => {
    setAssessments(prev => ({
      ...prev,
      [id]: { ...prev[id], rating }
    }));
  };

  const handleCommentsChange = (id: string, comments: string) => {
    setAssessments(prev => ({
      ...prev,
      [id]: { ...prev[id], comments }
    }));
  };

  const calculateScore = () => {
    const ratings = Object.values(assessments).map(a => a.rating).filter(r => r);
    if (ratings.length === 0) return 0;
    
    const scoreMap: Record<string, number> = {
      "Excellent": 5,
      "Good": 4,
      "Satisfactory": 3,
      "Concerning": 2,
      "Poor": 1
    };
    
    const totalScore = ratings.reduce((sum, rating) => sum + (scoreMap[rating] || 0), 0);
    const maxScore = ratings.length * 5;
    return Math.round((totalScore / maxScore) * 100);
  };

  const exportAsText = () => {
    const score = calculateScore();
    const completedCount = Object.values(assessments).filter(a => a.rating).length;
    const totalCount = ASSESSMENT_QUESTIONS.length;
    
    let content = `CHARACTER ASSESSMENT REPORT\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nOVERALL ASSESSMENT\n${'-'.repeat(50)}\nCompletion: ${completedCount}/${totalCount} questions (${Math.round((completedCount/totalCount)*100)}%)\nOverall Score: ${score}/100\n\n`;
    
    CATEGORIES.forEach(category => {
      const categoryItems = Object.values(assessments).filter(a => a.category === category && a.rating);
      if (categoryItems.length > 0) {
        content += `\n${category.toUpperCase()}\n${'-'.repeat(50)}\n`;
        categoryItems.forEach((item, idx) => {
          content += `\n${idx + 1}. ${item.question}\n   Rating: ${item.rating}\n`;
          if (item.comments) {
            content += `   Comments: ${item.comments}\n`;
          }
        });
      }
    });
    
    content += `\n\nRECOMMENDATION\n${'-'.repeat(50)}\n`;
    if (score >= 80) {
      content += `Score: ${score}/100 - STRONG\nRecommendation: Excellent character assessment. Proceed with confidence.\n`;
    } else if (score >= 60) {
      content += `Score: ${score}/100 - ACCEPTABLE\nRecommendation: Satisfactory character assessment. Proceed with standard conditions.\n`;
    } else if (score >= 40) {
      content += `Score: ${score}/100 - MARGINAL\nRecommendation: Some concerns identified. Consider additional due diligence.\n`;
    } else {
      content += `Score: ${score}/100 - WEAK\nRecommendation: Significant concerns. Recommend decline or substantial mitigation.\n`;
    }
    
    content += `\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `Character-Assessment-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    const score = calculateScore();
    const completedCount = Object.values(assessments).filter(a => a.rating).length;
    const totalCount = ASSESSMENT_QUESTIONS.length;
    
    let content = `<div class="section">\n  <h1>Character Assessment Report</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Overall Assessment</h2>\n  <table>\n    <tr>\n      <th>Metric</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Completion</td>\n      <td>${completedCount}/${totalCount} questions (${Math.round((completedCount/totalCount)*100)}%)</td>\n    </tr>\n    <tr>\n      <td>Overall Score</td>\n      <td><span class="highlight">${score}/100</span></td>\n    </tr>\n  </table>\n</div>\n`;
    
    CATEGORIES.forEach(category => {
      const categoryItems = Object.values(assessments).filter(a => a.category === category && a.rating);
      if (categoryItems.length > 0) {
        content += `\n<div class="section">\n  <h2>${category}</h2>\n`;
        categoryItems.forEach((item, idx) => {
          content += `  <div class="result">\n    <h3>${idx + 1}. ${item.question}</h3>\n    <p><strong>Rating:</strong> <span class="${item.rating === 'Excellent' || item.rating === 'Good' ? 'success' : item.rating === 'Poor' || item.rating === 'Concerning' ? 'error' : 'warning'}">${item.rating}</span></p>\n`;
          if (item.comments) {
            content += `    <p><strong>Comments:</strong> ${item.comments}</p>\n`;
          }
          content += `  </div>\n`;
        });
        content += `</div>\n`;
      }
    });
    
    content += `\n<div class="section">\n  <h2>Recommendation</h2>\n  <div class="result">\n`;
    if (score >= 80) {
      content += `    <p><span class="success">Score: ${score}/100 - STRONG</span></p>\n    <p>Excellent character assessment. Proceed with confidence.</p>\n`;
    } else if (score >= 60) {
      content += `    <p><span class="success">Score: ${score}/100 - ACCEPTABLE</span></p>\n    <p>Satisfactory character assessment. Proceed with standard conditions.</p>\n`;
    } else if (score >= 40) {
      content += `    <p><span class="warning">Score: ${score}/100 - MARGINAL</span></p>\n    <p>Some concerns identified. Consider additional due diligence.</p>\n`;
    } else {
      content += `    <p><span class="error">Score: ${score}/100 - WEAK</span></p>\n    <p>Significant concerns. Recommend decline or substantial mitigation.</p>\n`;
    }
    content += `  </div>\n</div>`;
    
    downloadAsHTML(content, `Character-Assessment-${new Date().toISOString().split('T')[0]}`);

  };

  const getOverallRating = (score: number) => {
    if (score >= 80) return { label: "Strong Character", color: "text-green-600", bg: "bg-green-50" };
    if (score >= 65) return { label: "Acceptable Character", color: "text-blue-600", bg: "bg-blue-50" };
    if (score >= 50) return { label: "Moderate Concerns", color: "text-yellow-600", bg: "bg-yellow-50" };
    return { label: "Significant Concerns", color: "text-red-600", bg: "bg-red-50" };
  };

  const completedCount = Object.values(assessments).filter(a => a.rating).length;
  const progress = Math.round((completedCount / ASSESSMENT_QUESTIONS.length) * 100);
  const score = calculateScore();
  const overallRating = getOverallRating(score);

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-6xl">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          
          <div className="flex items-center gap-4 mb-4">
            <img src="/first-enterprise-logo.png" alt="First Enterprise" className="h-16" />
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">Character Assessor</h1>
              <p className="text-muted-foreground text-base">
                Evaluate business owner character and integrity
              </p>
            </div>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-accent" />
              Assessment Progress
            </CardTitle>
            <CardDescription>
              {completedCount} of {ASSESSMENT_QUESTIONS.length} items assessed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="h-3 mb-2" />
            <p className="text-sm text-muted-foreground text-right">{progress}% Complete</p>
            
            {completedCount > 0 && (
              <Alert className={`mt-4 ${overallRating.bg}`}>
                <UserCheck className="h-4 w-4" />
                <AlertDescription>
                  <strong>Current Assessment: {overallRating.label}</strong> ({score}/100)
                  <br />
                  <span className="text-xs">
                    Complete all items for final assessment
                  </span>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {CATEGORIES.map((category) => {
            const categoryQuestions = ASSESSMENT_QUESTIONS.filter(q => q.category === category);
            const categoryCompleted = categoryQuestions.filter(q => assessments[q.id].rating).length;
            
            return (
              <Card key={category}>
                <CardHeader>
                  <CardTitle className="text-lg">{category}</CardTitle>
                  <CardDescription>
                    {categoryCompleted} of {categoryQuestions.length} completed
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {categoryQuestions.map((question) => (
                      <div key={question.id} className="border-b pb-4 last:border-b-0">
                        <Label className="text-base font-medium mb-3 block">
                          {question.question}
                        </Label>
                        
                        <div className="grid gap-4 md:grid-cols-2">
                          <div>
                            <Label htmlFor={`rating-${question.id}`} className="text-sm mb-2 block">
                              Rating
                            </Label>
                            <Select
                              value={assessments[question.id].rating}
                              onValueChange={(value) => handleRatingChange(question.id, value)}
                            >
                              <SelectTrigger id={`rating-${question.id}`}>
                                <SelectValue placeholder="Select rating" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Excellent">Excellent</SelectItem>
                                <SelectItem value="Good">Good</SelectItem>
                                <SelectItem value="Satisfactory">Satisfactory</SelectItem>
                                <SelectItem value="Concerning">Concerning</SelectItem>
                                <SelectItem value="Poor">Poor</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div>
                            <Label htmlFor={`comments-${question.id}`} className="text-sm mb-2 block">
                              Comments / Evidence
                            </Label>
                            <Textarea
                              id={`comments-${question.id}`}
                              placeholder="Add supporting comments or evidence..."
                              value={assessments[question.id].comments}
                              onChange={(e) => handleCommentsChange(question.id, e.target.value)}
                              rows={3}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {completedCount === ASSESSMENT_QUESTIONS.length && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Final Character Assessment</span>
                <span className={`text-3xl ${overallRating.color}`}>
                  {score}/100
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Alert className={overallRating.bg}>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>{overallRating.label}</strong>
                  <br />
                  <span className="text-sm mt-2 block">
                    {score >= 80 && "Applicant demonstrates strong character with excellent track record, financial responsibility, and professional reputation. Recommended for approval."}
                    {score >= 65 && score < 80 && "Applicant shows acceptable character with generally positive indicators. Minor concerns noted but overall suitable for lending consideration."}
                    {score >= 50 && score < 65 && "Applicant has moderate character concerns. Additional due diligence recommended. Consider enhanced monitoring or security requirements."}
                    {score < 50 && "Applicant shows significant character concerns. Recommend decline or refer to senior credit committee for review."}
                  </span>
                </AlertDescription>
              </Alert>

              <div className="mt-6 grid gap-4 md:grid-cols-5">
                {CATEGORIES.map((category) => {
                  const categoryQuestions = ASSESSMENT_QUESTIONS.filter(q => q.category === category);
                  const categoryRatings = categoryQuestions.map(q => assessments[q.id].rating).filter(r => r);
                  const scoreMap: Record<string, number> = {
                    "Excellent": 5, "Good": 4, "Satisfactory": 3, "Concerning": 2, "Poor": 1
                  };
                  const categoryScore = categoryRatings.length > 0
                    ? Math.round((categoryRatings.reduce((sum, r) => sum + (scoreMap[r] || 0), 0) / (categoryRatings.length * 5)) * 100)
                    : 0;
                  
                  return (
                    <div key={category} className="text-center p-4 border rounded">
                      <div className="text-2xl font-bold text-primary mb-1">{categoryScore}</div>
                      <div className="text-xs text-muted-foreground">{category}</div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {completedCount > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Export Assessment</CardTitle>
              <CardDescription>Download character assessment report for your records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  Download as Text
                </Button>
                <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  Download as HTML
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

