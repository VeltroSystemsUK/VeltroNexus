import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  companies, InsertCompany, Company,
  prospects, InsertProspect, Prospect,
  contacts, InsertContact, Contact,
  activities, InsertActivity, Activity,
  targets, InsertTarget, Target,
  companyFinancials, InsertCompanyFinancial, CompanyFinancial,
  calculatorResults, InsertCalculatorResult, CalculatorResult,
  dueDiligenceChecklists, InsertDueDiligenceChecklist, DueDiligenceChecklist,
  applicationSummaries, InsertApplicationSummary, ApplicationSummary,
  userSettings, InsertUserSettings, UserSettings,
  invitations, InsertInvitation, Invitation
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUser(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Company functions
export async function upsertCompany(company: InsertCompany): Promise<Company> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(companies).values(company).onDuplicateKeyUpdate({
    set: {
      companyName: company.companyName,
      companyStatus: company.companyStatus,
      companyType: company.companyType,
      addressLine1: company.addressLine1,
      addressLine2: company.addressLine2,
      locality: company.locality,
      region: company.region,
      postalCode: company.postalCode,
      country: company.country,
      rawData: company.rawData,
      updatedAt: new Date(),
    },
  });

  const [inserted] = await db.select().from(companies).where(eq(companies.companyNumber, company.companyNumber)).limit(1);
  return inserted;
}

export async function getCompanyByNumber(companyNumber: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(companies).where(eq(companies.companyNumber, companyNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Prospect functions
export async function createProspect(prospect: InsertProspect): Promise<Prospect> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(prospects).values(prospect);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(prospects).where(eq(prospects.id, insertId)).limit(1);
  return inserted;
}

export async function getProspectsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const results = await db
    .select({
      prospect: prospects,
      company: companies,
    })
    .from(prospects)
    .leftJoin(companies, eq(prospects.companyId, companies.id))
    .where(eq(prospects.userId, userId))
    .orderBy(desc(prospects.updatedAt));

  return results.map(r => ({
    ...r.prospect,
    company: r.company,
  }));
}

export async function updateProspectStage(prospectId: number, stage: Prospect["stage"]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(prospects).set({ stage, updatedAt: new Date() }).where(eq(prospects.id, prospectId));
}

// Contact functions
export async function createContact(contact: InsertContact): Promise<Contact> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(contacts).values(contact);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(contacts).where(eq(contacts.id, insertId)).limit(1);
  return inserted;
}

export async function getContactsByCompany(companyId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(contacts).where(eq(contacts.companyId, companyId)).orderBy(desc(contacts.createdAt));
}

export async function updateContact(id: number, data: Partial<InsertContact>): Promise<Contact | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(contacts).set({ ...data, updatedAt: new Date() }).where(eq(contacts.id, id));
  const [updated] = await db.select().from(contacts).where(eq(contacts.id, id)).limit(1);
  return updated || null;
}

export async function deleteContact(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(contacts).where(eq(contacts.id, id));
}

// Activity functions
export async function createActivity(activity: InsertActivity): Promise<Activity> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(activities).values(activity);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(activities).where(eq(activities.id, insertId)).limit(1);
  return inserted;
}

export async function getActivitiesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(activities).where(eq(activities.userId, userId)).orderBy(desc(activities.createdAt));
}

// Target functions
export async function createTarget(target: InsertTarget): Promise<Target> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(targets).values(target);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(targets).where(eq(targets.id, insertId)).limit(1);
  return inserted;
}

export async function getTargetsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(targets).where(eq(targets.userId, userId)).orderBy(desc(targets.year), desc(targets.month));
}


// Company Financials functions
export async function createCompanyFinancial(financial: InsertCompanyFinancial): Promise<CompanyFinancial> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(companyFinancials).values(financial);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(companyFinancials).where(eq(companyFinancials.id, insertId)).limit(1);
  return inserted;
}

export async function getFinancialsByCompany(companyId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(companyFinancials)
    .where(eq(companyFinancials.companyId, companyId))
    .orderBy(desc(companyFinancials.accountsYear));
}

export async function updateCompanyFinancial(id: number, financial: Partial<InsertCompanyFinancial>): Promise<CompanyFinancial> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(companyFinancials).set(financial).where(eq(companyFinancials.id, id));
  const [updated] = await db.select().from(companyFinancials).where(eq(companyFinancials.id, id)).limit(1);
  return updated;
}



// Update and delete prospect functions
export async function updateProspect(id: number, data: Partial<InsertProspect>): Promise<Prospect> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(prospects).set(data).where(eq(prospects.id, id));
  const [updated] = await db.select().from(prospects).where(eq(prospects.id, id)).limit(1);
  return updated;
}

export async function deleteProspect(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(prospects).where(eq(prospects.id, id));
}



// Calculator Results functions
export async function saveCalculatorResult(result: InsertCalculatorResult): Promise<CalculatorResult> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [inserted] = await db.insert(calculatorResults).values(result);
  const insertId = Number(inserted.insertId);
  const [saved] = await db.select().from(calculatorResults).where(eq(calculatorResults.id, insertId)).limit(1);
  return saved;
}

export async function getCalculatorResultsByProspect(prospectId: number, calculatorType?: string) {
  const db = await getDb();
  if (!db) return [];

  if (calculatorType) {
    return await db
      .select()
      .from(calculatorResults)
      .where(eq(calculatorResults.prospectId, prospectId))
      .orderBy(desc(calculatorResults.createdAt));
  }
  
  return await db
    .select()
    .from(calculatorResults)
    .where(eq(calculatorResults.prospectId, prospectId))
    .orderBy(desc(calculatorResults.createdAt));
}

// Due Diligence Checklist functions
export async function saveDueDiligenceChecklist(checklist: InsertDueDiligenceChecklist): Promise<DueDiligenceChecklist> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(dueDiligenceChecklists)
    .where(eq(dueDiligenceChecklists.prospectId, checklist.prospectId))
    .limit(1);

  if (existing.length > 0) {
    // Update existing
    await db
      .update(dueDiligenceChecklists)
      .set({
        checklistData: checklist.checklistData,
        progress: checklist.progress,
        status: checklist.status,
        completedAt: checklist.completedAt,
        updatedAt: new Date(),
      })
      .where(eq(dueDiligenceChecklists.id, existing[0].id));
    
    const [updated] = await db
      .select()
      .from(dueDiligenceChecklists)
      .where(eq(dueDiligenceChecklists.id, existing[0].id))
      .limit(1);
    return updated;
  } else {
    // Insert new
    const [inserted] = await db.insert(dueDiligenceChecklists).values(checklist);
    const insertId = Number(inserted.insertId);
    const [saved] = await db
      .select()
      .from(dueDiligenceChecklists)
      .where(eq(dueDiligenceChecklists.id, insertId))
      .limit(1);
    return saved;
  }
}

export async function getDueDiligenceChecklistByProspect(prospectId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(dueDiligenceChecklists)
    .where(eq(dueDiligenceChecklists.prospectId, prospectId))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}


export async function saveApplicationSummary(summary: InsertApplicationSummary) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if summary already exists for this prospect
  const existing = await db
    .select()
    .from(applicationSummaries)
    .where(eq(applicationSummaries.prospectId, summary.prospectId))
    .limit(1);

  if (existing.length > 0) {
    // Update existing
    await db
      .update(applicationSummaries)
      .set({
        background: summary.background,
        campari: summary.campari,
        swot: summary.swot,
        recommendation: summary.recommendation,
        updatedAt: new Date(),
      })
      .where(eq(applicationSummaries.id, existing[0].id));
    
    const [updated] = await db
      .select()
      .from(applicationSummaries)
      .where(eq(applicationSummaries.id, existing[0].id))
      .limit(1);
    return updated;
  } else {
    // Insert new
    const [inserted] = await db.insert(applicationSummaries).values(summary);
    const insertId = Number(inserted.insertId);
    const [saved] = await db
      .select()
      .from(applicationSummaries)
      .where(eq(applicationSummaries.id, insertId))
      .limit(1);
    return saved;
  }
}

export async function getApplicationSummaryByProspect(prospectId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(applicationSummaries)
    .where(eq(applicationSummaries.prospectId, prospectId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}



// ============================================================================
// User Settings
// ============================================================================

export async function getUserSettings(userId: number): Promise<UserSettings | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function upsertUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    // Check if settings exist
    const existing = await getUserSettings(userId);
    
    if (existing) {
      // Update existing settings
      await db
        .update(userSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(userSettings.userId, userId));
      
      return await getUserSettings(userId);
    } else {
      // Insert new settings
      await db.insert(userSettings).values({
        userId,
        ...settings,
      });
      
      return await getUserSettings(userId);
    }
  } catch (error) {
    console.error("[Database] Failed to upsert user settings:", error);
    return null;
  }
}

export async function getOrCreateUserSettings(userId: number): Promise<UserSettings | null> {
  const db = await getDb();
  if (!db) return null;

  let settings = await getUserSettings(userId);
  
  if (!settings) {
    // Create default settings
    settings = await upsertUserSettings(userId, {});
  }
  
  return settings;
}



// ============================================================================
// User Management Functions
// ============================================================================

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "manager" | "admin") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(users).set({ role, updatedAt: new Date() }).where(eq(users.id, userId));
  const [updated] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return updated;
}

export async function updateUserStatus(userId: number, status: "active" | "inactive") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(users).set({ status, updatedAt: new Date() }).where(eq(users.id, userId));
  const [updated] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return updated;
}

// ============================================================================
// Invitation Functions
// ============================================================================

export async function createInvitation(data: InsertInvitation): Promise<Invitation> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(invitations).values(data);
  const insertId = Number(result[0].insertId);
  const [inserted] = await db.select().from(invitations).where(eq(invitations.id, insertId)).limit(1);
  return inserted;
}

export async function getInvitationByCode(inviteCode: string): Promise<Invitation | null> {
  const db = await getDb();
  if (!db) return null;

  const [invitation] = await db
    .select()
    .from(invitations)
    .where(eq(invitations.inviteCode, inviteCode))
    .limit(1);
  
  return invitation || null;
}

export async function getAllInvitations() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(invitations).orderBy(desc(invitations.createdAt));
}

export async function updateInvitationStatus(
  id: number,
  status: "pending" | "accepted" | "expired",
  acceptedBy?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (status === "accepted" && acceptedBy) {
    updateData.acceptedAt = new Date();
    updateData.acceptedBy = acceptedBy;
  }

  await db.update(invitations).set(updateData).where(eq(invitations.id, id));
  const [updated] = await db.select().from(invitations).where(eq(invitations.id, id)).limit(1);
  return updated;
}

export async function deleteInvitation(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(invitations).where(eq(invitations.id, id));
}

