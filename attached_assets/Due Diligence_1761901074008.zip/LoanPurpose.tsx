import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Target, AlertCircle, CheckCircle2, TrendingUp, Download } from "lucide-react";
import { downloadAsText, downloadAsHTML } from "@/lib/exportUtils";
import { Link } from "wouter";
import { Progress } from "@/components/ui/progress";

interface LoanPurposeData {
  // Basic Information
  purposeCategory: string;
  specificPurpose: string;
  loanAmount: string;
  
  // Business Case
  currentSituation: string;
  problemOpportunity: string;
  proposedSolution: string;
  
  // Financial Justification
  expectedRevenue: string;
  expectedCosts: string;
  paybackPeriod: string;
  
  // Implementation
  timeline: string;
  keyMilestones: string;
  suppliers: string;
  
  // Risk Assessment
  risks: string;
  mitigation: string;
  alternativePlans: string;
  
  // Supporting Evidence
  marketResearch: string;
  quotes: string;
  competitorAnalysis: string;
}

const PURPOSE_CATEGORIES = [
  { value: "working_capital", label: "Working Capital", description: "Day-to-day operational expenses" },
  { value: "equipment", label: "Equipment Purchase", description: "Machinery, vehicles, or tools" },
  { value: "expansion", label: "Business Expansion", description: "New locations, markets, or products" },
  { value: "refurbishment", label: "Refurbishment/Renovation", description: "Premises improvement or modernization" },
  { value: "stock", label: "Stock/Inventory", description: "Purchase of goods for resale" },
  { value: "refinancing", label: "Refinancing", description: "Consolidate or replace existing debt" },
  { value: "acquisition", label: "Business Acquisition", description: "Purchase of another business" },
  { value: "technology", label: "Technology/IT", description: "Software, systems, or digital infrastructure" },
  { value: "marketing", label: "Marketing/Sales", description: "Promotional campaigns or sales initiatives" },
  { value: "other", label: "Other", description: "Specify custom purpose" }
];

export default function LoanPurpose() {
  const [formData, setFormData] = useState<LoanPurposeData>({
    purposeCategory: "",
    specificPurpose: "",
    loanAmount: "",
    currentSituation: "",
    problemOpportunity: "",
    proposedSolution: "",
    expectedRevenue: "",
    expectedCosts: "",
    paybackPeriod: "",
    timeline: "",
    keyMilestones: "",
    suppliers: "",
    risks: "",
    mitigation: "",
    alternativePlans: "",
    marketResearch: "",
    quotes: "",
    competitorAnalysis: ""
  });

  const handleChange = (field: keyof LoanPurposeData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateCompletion = () => {
    const fields = Object.values(formData).filter(v => v.trim() !== "");
    return Math.round((fields.length / Object.keys(formData).length) * 100);
  };

  const calculateROI = () => {
    const revenue = parseFloat(formData.expectedRevenue) || 0;
    const costs = parseFloat(formData.expectedCosts) || 0;
    const loanAmount = parseFloat(formData.loanAmount) || 0;
    
    if (loanAmount === 0) return "0";
    
    const netBenefit = revenue - costs;
    return ((netBenefit / loanAmount) * 100).toFixed(1);
  };

  const exportAsText = () => {
    const completion = calculateCompletion();
    const roi = calculateROI();
    const viability = getViabilityRating();
    const category = PURPOSE_CATEGORIES.find(c => c.value === formData.purposeCategory);
    
    let content = `LOAN PURPOSE ASSESSMENT\n${'='.repeat(50)}\n\nGenerated: ${new Date().toLocaleString()}\n\nBASIC INFORMATION\n${'-'.repeat(50)}\nPurpose Category: ${category?.label || 'Not specified'}\nSpecific Purpose: ${formData.specificPurpose || 'Not specified'}\nLoan Amount: £${parseFloat(formData.loanAmount || '0').toLocaleString()}\n\nBUSINESS CASE\n${'-'.repeat(50)}\nCurrent Situation:\n${formData.currentSituation || 'Not provided'}\n\nProblem/Opportunity:\n${formData.problemOpportunity || 'Not provided'}\n\nProposed Solution:\n${formData.proposedSolution || 'Not provided'}\n\nFINANCIAL JUSTIFICATION\n${'-'.repeat(50)}\nExpected Revenue/Benefit: £${parseFloat(formData.expectedRevenue || '0').toLocaleString()}\nExpected Costs: £${parseFloat(formData.expectedCosts || '0').toLocaleString()}\nPayback Period: ${formData.paybackPeriod || 'Not specified'}\nEstimated ROI: ${roi}%\n\nIMPLEMENTATION PLAN\n${'-'.repeat(50)}\nTimeline:\n${formData.timeline || 'Not provided'}\n\nKey Milestones:\n${formData.keyMilestones || 'Not provided'}\n\nSuppliers/Partners:\n${formData.suppliers || 'Not provided'}\n\nRISK ASSESSMENT\n${'-'.repeat(50)}\nIdentified Risks:\n${formData.risks || 'Not provided'}\n\nMitigation Strategies:\n${formData.mitigation || 'Not provided'}\n\nAlternative Plans:\n${formData.alternativePlans || 'Not provided'}\n\nSUPPORTING EVIDENCE\n${'-'.repeat(50)}\nMarket Research:\n${formData.marketResearch || 'Not provided'}\n\nQuotes/Estimates:\n${formData.quotes || 'Not provided'}\n\nCompetitor Analysis:\n${formData.competitorAnalysis || 'Not provided'}\n\nASSESSMENT SUMMARY\n${'-'.repeat(50)}\nCompletion: ${completion}%\nViability Rating: ${viability.label}\nRecommendation: ${viability.recommendation}\n\n${'='.repeat(50)}\nFirst Enterprise Inclusive Lending\nDueDiligence Platform`;
    downloadAsText(content, `Loan-Purpose-Assessment-${new Date().toISOString().split('T')[0]}`);
  };

  const exportAsHTML = () => {
    const completion = calculateCompletion();
    const roi = calculateROI();
    const viability = getViabilityRating();
    const category = PURPOSE_CATEGORIES.find(c => c.value === formData.purposeCategory);
    
    const content = `<div class="section">\n  <h1>Loan Purpose Assessment</h1>\n  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>\n</div>\n\n<div class="section">\n  <h2>Basic Information</h2>\n  <table>\n    <tr>\n      <th>Field</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Purpose Category</td>\n      <td>${category?.label || 'Not specified'}</td>\n    </tr>\n    <tr>\n      <td>Specific Purpose</td>\n      <td>${formData.specificPurpose || 'Not specified'}</td>\n    </tr>\n    <tr>\n      <td>Loan Amount</td>\n      <td>£${parseFloat(formData.loanAmount || '0').toLocaleString()}</td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Business Case</h2>\n  <h3>Current Situation</h3>\n  <p>${formData.currentSituation || 'Not provided'}</p>\n  <h3>Problem/Opportunity</h3>\n  <p>${formData.problemOpportunity || 'Not provided'}</p>\n  <h3>Proposed Solution</h3>\n  <p>${formData.proposedSolution || 'Not provided'}</p>\n</div>\n\n<div class="section">\n  <h2>Financial Justification</h2>\n  <table>\n    <tr>\n      <th>Metric</th>\n      <th>Value</th>\n    </tr>\n    <tr>\n      <td>Expected Revenue/Benefit</td>\n      <td>£${parseFloat(formData.expectedRevenue || '0').toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Expected Costs</td>\n      <td>£${parseFloat(formData.expectedCosts || '0').toLocaleString()}</td>\n    </tr>\n    <tr>\n      <td>Payback Period</td>\n      <td>${formData.paybackPeriod || 'Not specified'}</td>\n    </tr>\n    <tr>\n      <td>Estimated ROI</td>\n      <td><span class="highlight">${roi}%</span></td>\n    </tr>\n  </table>\n</div>\n\n<div class="section">\n  <h2>Implementation Plan</h2>\n  <h3>Timeline</h3>\n  <p>${formData.timeline || 'Not provided'}</p>\n  <h3>Key Milestones</h3>\n  <p>${formData.keyMilestones || 'Not provided'}</p>\n  <h3>Suppliers/Partners</h3>\n  <p>${formData.suppliers || 'Not provided'}</p>\n</div>\n\n<div class="section">\n  <h2>Risk Assessment</h2>\n  <h3>Identified Risks</h3>\n  <p>${formData.risks || 'Not provided'}</p>\n  <h3>Mitigation Strategies</h3>\n  <p>${formData.mitigation || 'Not provided'}</p>\n  <h3>Alternative Plans</h3>\n  <p>${formData.alternativePlans || 'Not provided'}</p>\n</div>\n\n<div class="section">\n  <h2>Supporting Evidence</h2>\n  <h3>Market Research</h3>\n  <p>${formData.marketResearch || 'Not provided'}</p>\n  <h3>Quotes/Estimates</h3>\n  <p>${formData.quotes || 'Not provided'}</p>\n  <h3>Competitor Analysis</h3>\n  <p>${formData.competitorAnalysis || 'Not provided'}</p>\n</div>\n\n<div class="section">\n  <h2>Assessment Summary</h2>\n  <div class="result">\n    <p><strong>Completion:</strong> ${completion}%</p>\n    <p><strong>Viability Rating:</strong> <span class="${viability.color.replace('text-', '')}">${viability.label}</span></p>\n    <p><strong>Recommendation:</strong> ${viability.recommendation}</p>\n  </div>\n</div>`;
    downloadAsHTML(content, `Loan-Purpose-Assessment-${new Date().toISOString().split('T')[0]}`);
  };

  const getViabilityRating = () => {
    const roi = parseFloat(calculateROI());
    const hasBusinessCase = formData.currentSituation && formData.problemOpportunity && formData.proposedSolution;
    const hasFinancials = formData.expectedRevenue && formData.expectedCosts && formData.paybackPeriod;
    const hasRiskMitigation = formData.risks && formData.mitigation;
    
    let score = 0;
    if (roi > 20) score += 30;
    else if (roi > 10) score += 20;
    else if (roi > 0) score += 10;
    
    if (hasBusinessCase) score += 25;
    if (hasFinancials) score += 25;
    if (hasRiskMitigation) score += 20;
    
    if (score >= 75) return { label: "Strong Viability", color: "text-green-600", bg: "bg-green-50", recommendation: "Loan purpose is well-justified with strong business case and financial projections. Recommend approval." };
    if (score >= 50) return { label: "Acceptable Viability", color: "text-blue-600", bg: "bg-blue-50", recommendation: "Loan purpose is adequately justified. Proceed with standard due diligence." };
    if (score >= 25) return { label: "Moderate Concerns", color: "text-yellow-600", bg: "bg-yellow-50", recommendation: "Some gaps in business case or financials. Request additional information before proceeding." };
    return { label: "Weak Viability", color: "text-red-600", bg: "bg-red-50", recommendation: "Insufficient justification for loan purpose. Recommend decline or substantial revision." };
  };

  const completion = calculateCompletion();
  const roi = calculateROI();
  const viability = getViabilityRating();

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-6xl">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          
          <div className="flex items-center gap-4 mb-4">
            <img src="/first-enterprise-logo.png" alt="First Enterprise" className="h-16" />
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">Loan Purpose Assessment</h1>
              <p className="text-muted-foreground text-base">
                Document and evaluate loan purpose, business case, and viability
              </p>
            </div>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-accent" />
              Assessment Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={completion} className="h-3 mb-2" />
            <p className="text-sm text-muted-foreground text-right">{completion}% Complete</p>
            
            {completion > 50 && (
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Alert className="bg-blue-50">
                  <TrendingUp className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Expected ROI:</strong> {roi}%
                    <br />
                    <span className="text-xs">Based on revenue vs. loan amount</span>
                  </AlertDescription>
                </Alert>
                
                <Alert className={viability.bg}>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Viability:</strong> {viability.label}
                    <br />
                    <span className="text-xs">Overall assessment rating</span>
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>Define the loan purpose and amount</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="purposeCategory">Loan Purpose Category</Label>
                <Select
                  value={formData.purposeCategory}
                  onValueChange={(value) => handleChange("purposeCategory", value)}
                >
                  <SelectTrigger id="purposeCategory">
                    <SelectValue placeholder="Select purpose category" />
                  </SelectTrigger>
                  <SelectContent>
                    {PURPOSE_CATEGORIES.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        <div>
                          <div className="font-medium">{cat.label}</div>
                          <div className="text-xs text-muted-foreground">{cat.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="specificPurpose">Specific Purpose (Detailed Description)</Label>
                <Textarea
                  id="specificPurpose"
                  placeholder="Provide detailed description of exactly what the loan will be used for..."
                  value={formData.specificPurpose}
                  onChange={(e) => handleChange("specificPurpose", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="loanAmount">Loan Amount Requested (£)</Label>
                <Input
                  id="loanAmount"
                  type="number"
                  placeholder="e.g., 50000"
                  value={formData.loanAmount}
                  onChange={(e) => handleChange("loanAmount", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Business Case */}
          <Card>
            <CardHeader>
              <CardTitle>Business Case</CardTitle>
              <CardDescription>Explain the rationale and context</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="currentSituation">Current Situation</Label>
                <Textarea
                  id="currentSituation"
                  placeholder="Describe your current business situation and operations..."
                  value={formData.currentSituation}
                  onChange={(e) => handleChange("currentSituation", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="problemOpportunity">Problem or Opportunity</Label>
                <Textarea
                  id="problemOpportunity"
                  placeholder="What problem are you solving or opportunity are you pursuing?"
                  value={formData.problemOpportunity}
                  onChange={(e) => handleChange("problemOpportunity", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="proposedSolution">Proposed Solution</Label>
                <Textarea
                  id="proposedSolution"
                  placeholder="How will the loan address this problem/opportunity?"
                  value={formData.proposedSolution}
                  onChange={(e) => handleChange("proposedSolution", e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Financial Justification */}
          <Card>
            <CardHeader>
              <CardTitle>Financial Justification</CardTitle>
              <CardDescription>Expected financial impact and returns</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="expectedRevenue">Expected Additional Revenue (£/year)</Label>
                  <Input
                    id="expectedRevenue"
                    type="number"
                    placeholder="e.g., 75000"
                    value={formData.expectedRevenue}
                    onChange={(e) => handleChange("expectedRevenue", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="expectedCosts">Expected Additional Costs (£/year)</Label>
                  <Input
                    id="expectedCosts"
                    type="number"
                    placeholder="e.g., 25000"
                    value={formData.expectedCosts}
                    onChange={(e) => handleChange("expectedCosts", e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="paybackPeriod">Expected Payback Period</Label>
                <Input
                  id="paybackPeriod"
                  placeholder="e.g., 3 years"
                  value={formData.paybackPeriod}
                  onChange={(e) => handleChange("paybackPeriod", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Implementation Plan */}
          <Card>
            <CardHeader>
              <CardTitle>Implementation Plan</CardTitle>
              <CardDescription>Timeline and execution details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="timeline">Implementation Timeline</Label>
                <Textarea
                  id="timeline"
                  placeholder="Outline the timeline for implementing this loan purpose..."
                  value={formData.timeline}
                  onChange={(e) => handleChange("timeline", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="keyMilestones">Key Milestones</Label>
                <Textarea
                  id="keyMilestones"
                  placeholder="List major milestones and deliverables..."
                  value={formData.keyMilestones}
                  onChange={(e) => handleChange("keyMilestones", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="suppliers">Suppliers/Vendors</Label>
                <Textarea
                  id="suppliers"
                  placeholder="List key suppliers, vendors, or contractors involved..."
                  value={formData.suppliers}
                  onChange={(e) => handleChange("suppliers", e.target.value)}
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          {/* Risk Assessment */}
          <Card>
            <CardHeader>
              <CardTitle>Risk Assessment</CardTitle>
              <CardDescription>Identify and mitigate potential risks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="risks">Potential Risks</Label>
                <Textarea
                  id="risks"
                  placeholder="Identify key risks that could affect this loan purpose..."
                  value={formData.risks}
                  onChange={(e) => handleChange("risks", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="mitigation">Risk Mitigation Strategies</Label>
                <Textarea
                  id="mitigation"
                  placeholder="How will you mitigate or manage these risks?"
                  value={formData.mitigation}
                  onChange={(e) => handleChange("mitigation", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="alternativePlans">Alternative Plans</Label>
                <Textarea
                  id="alternativePlans"
                  placeholder="What are your contingency plans if things don't go as expected?"
                  value={formData.alternativePlans}
                  onChange={(e) => handleChange("alternativePlans", e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Supporting Evidence */}
          <Card>
            <CardHeader>
              <CardTitle>Supporting Evidence</CardTitle>
              <CardDescription>Documentation and research supporting this purpose</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="marketResearch">Market Research</Label>
                <Textarea
                  id="marketResearch"
                  placeholder="Summarize market research supporting this loan purpose..."
                  value={formData.marketResearch}
                  onChange={(e) => handleChange("marketResearch", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="quotes">Quotes/Estimates</Label>
                <Textarea
                  id="quotes"
                  placeholder="List supplier quotes or cost estimates obtained..."
                  value={formData.quotes}
                  onChange={(e) => handleChange("quotes", e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="competitorAnalysis">Competitor Analysis</Label>
                <Textarea
                  id="competitorAnalysis"
                  placeholder="How do competitors approach similar initiatives?"
                  value={formData.competitorAnalysis}
                  onChange={(e) => handleChange("competitorAnalysis", e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Summary */}
          {completion >= 80 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Loan Purpose Assessment Summary</span>
                  <span className={`text-2xl ${viability.color}`}>{viability.label}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Alert className={viability.bg}>
                  <Target className="h-4 w-4" />
                  <AlertDescription>
                    <div className="space-y-2">
                      <div>
                        <strong>Purpose:</strong> {PURPOSE_CATEGORIES.find(c => c.value === formData.purposeCategory)?.label || "Not specified"}
                      </div>
                      <div>
                        <strong>Loan Amount:</strong> £{parseFloat(formData.loanAmount || "0").toLocaleString()}
                      </div>
                      <div>
                        <strong>Expected ROI:</strong> {roi}%
                      </div>
                      <div>
                        <strong>Payback Period:</strong> {formData.paybackPeriod || "Not specified"}
                      </div>
                      <div className="mt-4 pt-4 border-t">
                        <strong>Recommendation:</strong>
                        <br />
                        {viability.label === "Strong Viability" && "Loan purpose is well-justified with strong business case, clear financial benefits, and comprehensive risk mitigation. Recommend approval."}
                        {viability.label === "Acceptable Viability" && "Loan purpose is acceptable with reasonable business case. Some areas could be strengthened but overall suitable for consideration."}
                        {viability.label === "Moderate Concerns" && "Loan purpose has moderate concerns. Additional information or clarification recommended before proceeding."}
                        {viability.label === "Weak Viability" && "Loan purpose shows weak viability. Significant concerns about business case, financial justification, or risk management. Recommend decline or major revisions."}
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}

          {completion > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Export Assessment</CardTitle>
                <CardDescription>Download loan purpose assessment for your records</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button onClick={exportAsText} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as Text
                  </Button>
                  <Button onClick={exportAsHTML} variant="outline" className="flex-1 gap-2">
                    <Download className="h-4 w-4" />
                    Download as HTML
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

